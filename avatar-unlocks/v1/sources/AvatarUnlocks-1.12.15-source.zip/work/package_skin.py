"""Assemble the independently updated AvatarUnlocks catalog from editable modules."""
import base64
import configparser
import json
from pathlib import Path
import re

UNLOCK = Path(__file__).resolve().parents[1] / "AvatarUnlocks"


def walk_display_atlas():
    from walk_display import build_display
    return build_display(UNLOCK)

def gallery_script():
    text = (UNLOCK / "gallery.lua").read_text(encoding="utf-8")
    assert text.count("-- @pack-buttons") == 1
    return text.replace("-- @pack-buttons", (UNLOCK / "buttons.lua").read_text(encoding="utf-8"))

def unlock_engine(walk_display=None):
    previews = json.loads((UNLOCK / "gallery.json").read_text(encoding="utf-8"))
    rows = []
    seen = set()
    from PIL import Image
    slots = set()
    card_only = {}
    with Image.open(UNLOCK / "gallery.png") as image:
        assert image.width == 576 and image.height % 64 == 0
        capacity = image.height // 64 * 9
    for kind in ("outfit", "pet", "pokemon"):
        for item_id, label, *position in previews[kind]:
            slot = position[0] if position else len(rows)
            assert len(position) <= 2 and type(slot) is int and 0 <= slot < capacity
            dex_field = ""
            if len(position) == 2:
                number = position[1]
                assert kind == "pokemon" and type(number) is int and 152 <= number <= 251
                card_only[item_id] = number
                dex_field = f", dex={number}"
            assert slot not in slots and not 27 <= slot <= 35, "overlapping gallery art"
            slots.add(slot)
            assert re.fullmatch(r"[a-z0-9_-]+", item_id) and item_id not in seen
            seen.add(item_id)
            rows.append(f'    {{id="{item_id}", kind="{kind}", name={json.dumps(label, ensure_ascii=False)}, icon={slot}{dex_field}}},')
    def encoded_image(data):
        return base64.b64encode(data).decode("ascii")

    atlas = encoded_image((UNLOCK / "gallery.png").read_bytes())
    block = "M.gallery = {\n" + "\n".join(rows) + '\n}\nM.atlas="' + atlas + '"'
    walk_rows = json.loads((UNLOCK / "walk-rows.json").read_text(encoding="utf-8"))
    density, walk_atlas, row_densities, sequences = walk_display or walk_display_atlas()
    identifiers, crops = {}, []
    for index, entry in enumerate(walk_rows):
        # A plain ID from an earlier atlas uses its complete 32px frame.
        item = {"id": entry} if isinstance(entry, str) else entry
        ident = item["id"]
        x, y, w, h = item.get("crop", [0, 0, 32, 32])
        assert re.fullmatch(r"[a-z0-9_-]+", ident) and ident not in identifiers
        assert all(type(n) is int for n in (x, y, w, h))
        assert x >= 0 and y >= 0 and w > 0 and h > 0 and (ident in sequences or (x + w <= 32 and y + h <= 32))
        identifiers[ident] = index
        reference_height = item.get("referenceHeight", h)
        assert type(reference_height) is int and reference_height >= 1 and (ident in sequences or reference_height <= 32)
        motion = ""
        if ident in sequences:
            strip_y, durations = sequences[ident]
            ends = []
            total = 0
            for duration in durations:
                total += duration
                ends.append(str(total))
            motion = f",{strip_y},{total},{{{','.join(ends)}}}"
        crops.append(f"w({x},{y},{w},{h},{reference_height},{row_densities[index]}{motion})")
    block += "\nM.walkRows = {" + ",".join(f'["{ident}"]={i}' for ident, i in identifiers.items()) + "}"
    block += "\ndo local function w(x,y,a,b,r,d,s,c,e) return {x=x,y=y,w=a,h=b,referenceHeight=r,density=d,stripY=s,cycle=c,ends=e} end\nM.walkCrops = {" + ",".join(crops) + "}\nend"
    block += f"\nM.walkDensity={density}"
    block += '\nM.walkAtlas="' + encoded_image(walk_atlas) + '"'
    hoodie = UNLOCK / "outfits" / "formday-buddy" / "hoodie"
    poses = sorted(hoodie.rglob("*.png"))
    assert len(poses) == 18, "Incomplete hoodie artwork"
    block += "\nM.hoodieFrames = {\n"
    for pose in poses:
        key = pose.relative_to(hoodie).with_suffix("").as_posix()
        block += f'  ["{key}"]="{encoded_image(pose.read_bytes())}",\n'
    block += "}\n"
    from gallery_layout import gallery_layout
    def positions(text, names=None):
        config = configparser.ConfigParser(interpolation=None)
        config.read_string(text)
        return {name: [config.getint(name, "X", fallback=10), config.getint(name, "Y")]
                for name in (names or config.sections())}

    panel_names = ("UnlockPanelCard", "UnlockPanelTitle", "UnlockPanelClose", "UnlockPanelCurrent",
                   "UnlockPanelLatest", "UnlockPanelState", "UnlockInstallButton", "UnlockRetryButton")
    content = {"families": json.loads((UNLOCK / "pokedex.json").read_text(encoding="utf-8")),
               "sizes": json.loads((UNLOCK / "pokemon-sizes.json").read_text(encoding="utf-8")),
               "galleryPositions": positions(gallery_layout("")),
               "panelPositions": positions((UNLOCK / "panel.inc").read_text(encoding="utf-8"), panel_names)}
    pokemon = {row[0] for row in previews["pokemon"]}
    numbers, species_ids = set(), set()
    species_numbers = {}
    for family in content["families"].values():
        for number, uid, *_ in family:
            assert uid in pokemon and uid not in species_ids and number not in numbers, "missing or duplicate species card"
            species_ids.add(uid)
            numbers.add(number)
            species_numbers[uid] = number
    # Card registration and level-editor eligibility stay unchanged when linking a family.
    assert len(set(card_only.values())) == len(card_only), "duplicate standalone card number"
    for uid, number in card_only.items():
        if uid in species_numbers:
            assert species_numbers[uid] == number, "conflicting number for linked card"
        else:
            assert number not in numbers, "duplicate National Dex number"
    assert species_ids | card_only.keys() == pokemon, "species card without a dex entry"
    assert set(identifiers) <= pokemon, "walking sprite without a species card"
    def lua_string(text):
        delimiter = "="
        while "]" + delimiter + "]" in text:
            delimiter += "="
        return "[" + delimiter + "[" + text + "]" + delimiter + "]"

    search_script = base64.b64encode((UNLOCK / "search.ps1").read_bytes()).decode("ascii")
    block += '\nM.searchScript="' + search_script + '"'
    block += "\nM.contentJson=" + lua_string(json.dumps(content, ensure_ascii=False, separators=(",", ":")))
    stones = json.loads((UNLOCK / "stones.json").read_text(encoding="utf-8"))
    targets = {}
    block += "\nM.stoneOrder={}\nM.stoneNames={}\nM.evolutions={}\n"
    for i, stone in enumerate(stones, 1):
        ident, name = stone["id"], json.dumps(stone["name"], ensure_ascii=False)
        assert re.fullmatch(r"[a-z]+", ident)
        block += f'M.stoneOrder[{i}]="{ident}"\nM.stoneNames.{ident}={name}\n'
        for target in stone["targets"]:
            assert target not in targets
            targets[target] = ident
    routes = []
    edges = set()
    for family_id, family in content["families"].items():
        members = {row[0]: row for row in family}
        ancestry = {}
        for number, ident, _, *parent in family:
            depth = 0
            if parent:
                previous, parent_depth = ancestry[parent[0]]
                depth = parent_depth + 1
                block += f'M.evolutions["{ident}"]={{parent="{previous}",stone="{targets[ident]}",cost={depth}}}\n'
                routes.append(dict(family=family_id, parent=previous, id=ident, edge=previous+"/"+ident,
                                   parentName=members[parent[0]][2], name=members[number][2], parentDex=parent[0],
                                   dex=number, stage=depth, stone=next(s["name"] for s in stones if s["id"]==targets[ident])))
                edges.add(ident)
            ancestry[number] = (ident, depth)
    assert edges == set(targets)
    routes.sort(key=lambda r: r["dex"])
    block += "\nM.costRoutes=" + lua_string(json.dumps(routes, ensure_ascii=False, separators=(",", ":"))) + "\n"
    block += "\nM.costScript=" + lua_string((UNLOCK / "evolution-editor.ps1").read_text(encoding="utf-8-sig")) + "\n"
    block += (UNLOCK / "special-shop.lua").read_text(encoding="utf-8") + "\n"
    block += (UNLOCK / "family-rules.lua").read_text(encoding="utf-8") + "\n"
    block += (UNLOCK / "wallet.lua").read_text(encoding="utf-8") + "\n"
    rules = json.loads((UNLOCK / "avatar-rewards.json").read_text(encoding="utf-8"))
    defaults={item["id"]:item["level"] for item in rules["formday-buddy"]}
    numbers={row[1]:row[0] for family in content["families"].values() for row in family}
    level_items=[]
    for kind in ("pokemon","pet","outfit"):
        for uid,label,*_ in previews[kind]:
            if kind=="pokemon" and (uid in targets or uid in card_only):
                continue
            level_items.append({"id":uid,"name":label,"kind":kind,"dex":numbers.get(uid),
                                "level":defaults.get(uid),"cardOnly":kind!="pokemon" and uid not in defaults})
    level_items.sort(key=lambda i:i["dex"] or 9999)
    block += "\nM.levelItems=" + lua_string(json.dumps(level_items,ensure_ascii=False,separators=(",",":"))) + "\n"
    block += "\nM.avatarRewards = {\n"
    for avatar, items in rules.items():
        assert re.fullmatch(r"[a-z0-9_-]{1,48}", avatar)
        ids = set()
        block += '  ["' + avatar + '"] = {\n'
        for item in items:
            ident, kind, level = item["id"], item["kind"], item["level"]
            assert re.fullmatch(r"[a-z0-9_-]{1,48}", ident) and ident not in ids
            assert kind in ("outfit", "pet", "pokemon") and type(level) == int and level >= 1
            ids.add(ident)
            block += f'    {{id="{ident}",kind="{kind}",level={level}}},\n'
        block += "  },\n"
    block += "}\nfunction M.createGallery()\n" + gallery_script() + "\nend"
    block += "\nfunction M.createFollower()\n" + (UNLOCK / "follower.lua").read_text(encoding="utf-8") + "\nend"
    pet_dir = UNLOCK / "pets"
    child_template = (pet_dir / "window.lua").read_text(encoding="utf-8")
    block += "\nM.pets={}\n"
    for pet_id, stem, special in (("kirby", "kirby", "inhale"), ("octopus", "munmun", "ink")):
        motion = json.loads((pet_dir / (stem + ".json")).read_text(encoding="utf-8"))
        assert (motion["width"], motion["height"], motion["ground"], motion["columns"]) == (84, 86, 82, 12)
        assert special in motion["clips"]
        clips = ",".join('["%s"]={start=%d,ms={%s}}' % (name, clip["start"], ",".join(map(str, clip["ms"])))
                         for name, clip in motion["clips"].items())
        width = 140 if special == "ink" else 84
        header = (f'local petId,special,windowWidth="{pet_id}","{special}",{width}\n'
                  + 'local clips={' + clips + '}')
        child = child_template.replace("-- @pack-pet-clips", header)
        atlas = encoded_image((pet_dir / (stem + ".png")).read_bytes())
        block += f'M.pets.{pet_id}={{width={width},atlas="{atlas}",window=' + lua_string(child) + '}\n'
        if special == "ink":
            effect = motion["effects"]["ink"]
            assert (effect["width"], effect["height"], effect["columns"], effect["offset"]) == (168, 86, 6, [0, 0])
            block += f'M.pets.{pet_id}.ink="' + encoded_image((pet_dir / effect["file"]).read_bytes()) + '"\n'
    block += "\nM.petIni=" + lua_string((UNLOCK / "pets/window.ini").read_text(encoding="utf-8"))
    block += "\nfunction M.createRoam()\n" + (UNLOCK / "roam-manager.lua").read_text(encoding="utf-8") + "\nend"
    block += "\nfunction M.createPet()\n" + (UNLOCK / "pet.lua").read_text(encoding="utf-8") + "\nend"
    src = (UNLOCK / "engine.lua").read_text(encoding="utf-8")
    assert src.count("-- @pack-runtime") == 1
    runtime = (UNLOCK / "runtime.lua").read_text(encoding="utf-8").replace("-- @pack-evolution-client", (UNLOCK / "evolution-client.lua").read_text(encoding="utf-8"))
    src = src.replace("-- @pack-runtime", runtime)
    assert src.count("-- @pack-gallery") == 1
    from compact_lua import compact
    return compact(src.replace("-- @pack-gallery", block)).encode("utf-8")
