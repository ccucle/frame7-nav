# 읽기 전용 사전 조사 기록

기준 커밋: 43ea274b6929edb80e298b9b01c8224d6873facc.
공개 도감1.12.14 소스 ZIP과 작업 파일424개 일치(루트 설명 파일 별도).
이 기록은 수정 전에 Work 대화에 보고한 내용을 보존한 것이다.

## 공식 피드와 설치본 구분

- [Buddy 피드](https://raw.githubusercontent.com/ccucle/frame7-nav/formday-buddy-updates/buddy/feed.txt): 0.6.31. ZIP956,200 bytes/95개 파일. SHA256 6b8dd5d1e11e9b16afdd07a46040f171010250e92c05fc8e952f74b32ccee56f.
- [해금도감 피드](https://raw.githubusercontent.com/ccucle/frame7-nav/formday-buddy-updates/avatar-unlocks/v1/feed.txt): 1.12.14. Lua2,094,705 bytes. SHA256 51dc894437891c9d823abb5d2d8f94204e7196eeb88888f2aa6ecc8391ab0f0f.
- 공개 소스 ZIP3,226,407 bytes/SHA256 54cc8eb8b350ef09c29610201cc67238bc508fe9809083ca4af73ab0a46a7c6e.
- 최초 조사에서 두 피드를 기존 공개키로 검증했다. 후보 완성 뒤 재조회도 같은 버전/해시. 정확한 마지막 조회 시각은 release/rc1/feed-recheck.json 참조.
- 프로젝트 호스트는0.6.30. 공식0.6.31과 95개 중 Skin.inc/build.txt만 달라 공식 종료 버튼의 공통 설정 이동을 후보에 먼저 보존했다.
- 실제 설치는 A0.6.30/B0.6.29, 공유 도감 active1.12.12. 공식 배포 기준과 구분했으며 수정하지 않았다.
- 실제 운영 Data에서 일반 지갑 사건78개/.owned82개, Geo 사건0개 확인. 내용과 식별자는 복사하지 않았다.

## Notion 현행 문서

[통합 목차](https://app.notion.com/p/422b1c033c1c807c99acf449a7003144)에서01 통합 헌장과13 제작팀 공통 운영 지침을 먼저 읽었다.
00~15 현행 문서, 관련 팀별 인계·최신 변경 기록, 지오 문서, 1/2세대 체크리스트 및2세대 진화 문서를 확인했다. 아카이브/오래된 버전 표시는 현재 공식 코드와 구분했다.

- [00 현행 문서](https://app.notion.com/p/425b1c033c1c81e596d3c7a4594cce7f)
- [01 현행 문서](https://app.notion.com/p/425b1c033c1c8124b934e7f39ba9fe1a)
- [02 현행 문서](https://app.notion.com/p/425b1c033c1c813394e5fef07d900a95)
- [03 현행 문서](https://app.notion.com/p/425b1c033c1c81b8bb92d888a976d7c1)
- [04 현행 문서](https://app.notion.com/p/425b1c033c1c818b854adcc1af1a4a73)
- [05 현행 문서](https://app.notion.com/p/425b1c033c1c8102ae06f8a102207674)
- [06 현행 문서](https://app.notion.com/p/425b1c033c1c81aca75dd12bf374d6e3)
- [07 현행 문서](https://app.notion.com/p/425b1c033c1c814fbe1ad814d41f9d1c)
- [08 현행 문서](https://app.notion.com/p/425b1c033c1c81cd9480f926619df6e5)
- [09 현행 문서](https://app.notion.com/p/425b1c033c1c814db26dfc614d178c6a)
- [10 현행 문서](https://app.notion.com/p/425b1c033c1c810da556d56481630223)
- [11 현행 문서](https://app.notion.com/p/425b1c033c1c8164853ad6bc15ffc305)
- [12 현행 문서](https://app.notion.com/p/425b1c033c1c8134b929c4d6b093b078)
- [13 현행 문서](https://app.notion.com/p/425b1c033c1c81a8b746e1b8ad70a694)
- [14 현행 문서](https://app.notion.com/p/425b1c033c1c817f9178fc0d4edbde81)
- [15 현행 문서](https://app.notion.com/p/425b1c033c1c8109a8b7ffab1605db7c)

## 차이와 변경 경계

06 최신 세대 계획은 이전 세대151/151, 이후100/100, 레벨20~35, 조상/아기7종 예외 등을 다룬다. 이후 사용자 정정이 우선하여 이번 특별5종은 모든 아바타의 공통 예외(필수146)다.

공개1.12.14에는 세대 표시 필터만 있다. 별도 FormdayPet-Integrated 작업본(표시1.12.13)에 실제 advanceGeneration/canAcquire/requiredGeneration/generationEnds가 있었다. 표시 버전만 보고 공식 기준으로 삼지 않았으며 미배포 코드 묶음을 가져오지 않았다. 그쪽 Geo 연결부는 공개본과 같아 향후 세대 판정 통합을 별도 검증해야 한다.

공통 가족 feed는 진화 비용 schema1/rev3(첫 단계5/둘째10/override8), 해금 레벨 schema1/rev3(항목4), powder schema1/rev1(비율5)로 확인했다. 이 데이터와 편집기는 유지한다.

Buddy 사건식 지갑과 Geo owner 기반 전체 상태 지갑을 공통 규칙 아래 얇은 저장 연결부로 연결한다. 카드·구매·레벨 제외·필수 집계 예외는 한 모듈에서 결정한다.
변경할 곳은 공통 구매 정책/UI/지급 조건, 기존 지갑 연결부/호스트 호환 계약, 패키징·검증이다.
기존 보유, 다른 종의 자산/레벨/지급, 돌 제작·진화·소환, 지오 적립 원천을 유지한다. 독립 게임 모듈/배틀/야생포획/포켓볼/게임 연결과 공식 배포는 범위 밖이다.

## 후속 검수 연결

동일 Windows 환경 ID:
ccarenv_b64_Y2NhcmVudl82YWJlMTE1MDJkNzA4MTkxODQyYWJhOGUwMjljZjM4MA

화면 제어 GetCursorPos 0x80070005로 실제 포인터 검수는 보류됐다. 컴퓨터 실행 연결 자체는 유지됐다. 동일 환경의 화면 접근이 회복되면 기존 QA 자료를 확인한 후 UI 검수를 이어간다. 클라우드/다른 PC로 옮기지 않는다.
