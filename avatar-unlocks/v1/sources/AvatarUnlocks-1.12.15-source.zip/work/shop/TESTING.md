# 로컬 검증 재현

지정 Windows 작업 폴더에서 실행한다. 클라우드/원격 개발 컨테이너로 이동하지 않는다.
work/tests/run_shop.py는 지정 경로와 Windows를 검사하고, 매 실행 새 work/shop/qa/run-* 폴더를 만든다.
Lua5.1/5.3은 프로젝트 내부 work/test-deps의 lupa2.8로 실행했다. 패키징에는 로컬 Python의 Pillow를 사용한다.
소스 ZIP에는 공개 기준 엔진/원장 연결부의 읽기 전용 시험 기준(work/shop/baseline)이 포함된다. 실제 사용자 자료와 테스트 실행 바이너리는 포함하지 않는다.

PowerShell:
    & 'C:\Users\ccucl\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -B work/tests/run_shop.py

새 패키지 폴더:
    & 'C:\Users\ccucl\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -B work/build_review.py work/shop/release/새후보이름

빌드는 같은 도감을 Buddy ZIP에 내장한다. 두 후보를 분리 배포하거나 서명 검증을 생략해 실제 설치하지 않는다.
REVIEW.md의 남은 GUI/서명/롤백 검수 항목을 완료해야 한다.
