"""Remove comments/indentation without changing strings or embedded scripts."""
import re
TOKENS = re.compile(r"""(?P<comment>--(?:\[(?P<ceq>=*)\[.*?\](?P=ceq)\]|[^\r\n]*))|(?P<long>\[(?P<eq>=*)\[.*?\](?P=eq)\])|(?P<quote>"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')""", re.S)
def compact(source):
    header, body = source.split("\n", 1)
    assert header.startswith("-- avatar-unlocks/v1 ")
    result, start = [header, "\n"], 0
    def plain(text):
        return re.sub(r"(?m)^[ \t]+|[ \t]+$", "", text)
    for match in TOKENS.finditer(body):
        result.append(plain(body[start:match.start()]))
        result.append(" " if match.lastgroup == "comment" else match.group())
        start = match.end()
    result.append(plain(body[start:]))
    return "".join(result)
