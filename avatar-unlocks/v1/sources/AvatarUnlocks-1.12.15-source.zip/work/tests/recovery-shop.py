"""Exercise the existing updater entry point and immutable-wallet forward recovery on Windows."""
import os,sys,subprocess,shutil,re,hashlib,json,time,threading,http.server,functools
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
assert os.name=="nt" and ROOT==Path(r"C:\Users\ccucl\Projects\Geo-UnlockDex-Shop")
sys.path[:0]=[str(ROOT/"work/test-deps"),str(ROOT/"work/tests")]
from lupa.lua51 import LuaRuntime
from lupa.lua53 import LuaRuntime as Lua53
from check_profile_routing import prepare,setup_case
OUT=ROOT/"work/shop/qa"/("recovery-"+str(time.time_ns()))
RES=ROOT/"DesktopSkin/@Resources"
RC=ROOT/"work/shop/release/rc1"
PUB=ROOT/"work/shop/release/publish-1"
PS=r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
OUT.mkdir()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(RC/"AvatarUnlocks-review.lua")=="dbdb30a5315e8918c428c96dee674fc8b940fe98ce355bccbca32fd4f6d60250"
assert digest(RC/"FormdayBuddy-review.zip")=="af048b43cac301af574362b21a93d366c0f7b306dda757d4df56e4ccd1fdb225"
def powershell(code,cwd):
 r=subprocess.run([PS,"-NoLogo","-NoProfile","-NonInteractive","-Command",code],cwd=cwd,capture_output=True)
 if r.returncode:raise AssertionError(r.stderr.decode(errors="replace"))
 return r.stdout.decode(errors="replace").strip()
def q(path):return "'"+str(path).replace("'","''")+"'"
def snapshot(folder):return {p.name:(digest(p),p.stat().st_mtime_ns) for p in folder.iterdir() if p.is_file()}
# Seed only synthetic profiles and retain every existing record through downgrade/recovery.
data=OUT/"data";data.mkdir()
lua=LuaRuntime();lua.globals().base=str(data)+"/"
lua.globals().catalog=str(RC/"AvatarUnlocks-review.lua")
lua.globals().oldcatalog=str(ROOT/"work/shop/baseline/catalog.lua")
lua.execute("""
M=assert(loadfile(catalog))();M.specialShopEnabled=true
s=M.connect(base,"formday-buddy","owner",{})
assert(s:earn(30000));assert(s:craft("leaf"));assert(s:purchase("zapdos"));assert(s:purchase("mew"))
assert(s.wallet.powder==99970 and s:owns("mew"))
other=M.connect(base,"formday-geo","owner",{});assert(other:earn(10))
""")
before=snapshot(data)
lua.execute("""
old=assert(loadfile(oldcatalog))();broken=old.connect(base,"formday-buddy","owner",{})
assert(broken.wallet.error=="invalid receipt")
assert(not broken:earn(31000) and not broken:craft("leaf"))
""")
assert snapshot(data)==before
print("PASS old reader fails closed without changing any record")
# Exact deployed host updater, with transport replaced only by local fixture bytes.
host=OUT/"host";up=host/"@Resources/Updater";up.mkdir(parents=True)
live=Path(r"C:\Users\ccucl\RainmeterSkins\FormdayBuddy\@Resources\Updater")
client=(live/"client.inc").read_bytes().decode("utf-16")
commands={}
for part in re.split(r"(?m)^\[",client):
 if not part.strip():continue
 name=part.splitlines()[0].rstrip("]")
 lines=[l for l in part.splitlines() if l.startswith("Parameter=")]
 if name in ["VerifyFeed","InstallBundle"]:
  commands[name]=lines[0].split('-Command "',1)[1][:-1]
assert "[!CommandMeasure UpdateService ClickUpdate()]" in (RES/"Skin.inc").read_bytes().decode("utf-16")
shutil.copyfile(live/"publisher.xml",up/"publisher.xml")
outputs={};queue=[];activated=[];vars={"@":str(host/"@Resources")+"/","ReleaseSlot":"A","BuddyVersion":"0.6.31","CURRENTCONFIG":"Recovery-QA"}
u=LuaRuntime()
def bang(self,cmd,*args):
 if cmd=="!SetVariable":vars[args[0]]=args[1]
 if cmd=="!CommandMeasure" and args[1]=="Run":queue.append(args[0])
 if cmd=="!ActivateConfig":activated.append(args)
def getmeasure(self,name):return u.table_from({"GetStringValue":lambda *_:outputs.get(name,"")})
u.globals().SKIN=u.table_from({"GetVariable":lambda _,n:vars.get(n),"Bang":bang,"GetMeasure":getmeasure})
# Normalize Windows separators only inside the isolated test host path.
u.execute((live/"update.lua").read_text(encoding="utf-8"))
u.globals().Initialize();u.globals().ClickUpdate()
steps=[]
while queue:
 name=queue.pop(0);steps.append(name)
 if name=="FetchFeed":
  shutil.copyfile(PUB/"buddy/feed.txt",up/"feed.tmp");u.globals().FeedFetched()
 elif name=="VerifyFeed":
  outputs[name]=powershell(commands[name],up);assert outputs[name].startswith("OK 0.6.32|");u.globals().FeedVerified()
 elif name=="FetchBundle":
  shutil.copyfile(RC/"FormdayBuddy-review.zip",up/"incoming.zip");u.globals().BundleFetched()
 elif name=="InstallBundle":
  code=commands[name]
  for key,value in vars.items():code=code.replace("#"+key+"#",str(value))
  assert (up/"../B").resolve().is_relative_to(OUT)
  outputs[name]=powershell(code,up);assert outputs[name]=="READY";u.globals().BundleInstalled()
 else:raise AssertionError(name)
assert activated==[("Recovery-QA","FormdayB.ini")]
assert digest(host/"@Resources/B/unlock-engine.lua")==digest(RC/"AvatarUnlocks-review.lua")
assert snapshot(data)==before
print("PASS ClickUpdate -> actual existing signature verifier -> extraction -> B activation; data unchanged")
# Actual catalog installer with a loopback-only transport, authentic candidate signature and original public key.
web=OUT/"transport";(web/"releases").mkdir(parents=True)
shutil.copyfile(PUB/"avatar-unlocks/v1/feed.txt",web/"feed.txt")
shutil.copyfile(RC/"AvatarUnlocks-review.lua",web/"releases/1.12.15.lua")
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(("127.0.0.1",0),functools.partial(Quiet,directory=str(web)))
threading.Thread(target=server.serve_forever,daemon=True).start()
cache=OUT/"catalog-cache";cache.mkdir()
shutil.copyfile(ROOT/"work/shop/baseline/catalog.lua",cache/"1.12.14.lua")
(cache/"active.txt").write_text("1.12.14")
code=(ROOT/"AvatarUnlocks/update.ps1").read_text(encoding="utf-8-sig")
invoke=f"\nUpdate-AvatarUnlocks -Mode Install -Root {q(cache)} -Base 'http://127.0.0.1:{server.server_port}' -Key ([IO.File]::ReadAllText({q(ROOT/'AvatarUnlocks/publisher.xml')})) -Bundled '1.12.14'"
try:
 result=powershell(code+invoke,OUT);assert result=="INSTALLED 1.12.15",result
 assert digest(cache/"1.12.15.lua")==digest(RC/"AvatarUnlocks-review.lua")
 assert (cache/"active.txt").read_text()=="1.12.15"
 # A mismatched signed feed is rejected with the active pointer/installed file unchanged.
 valid=(web/"feed.txt").read_bytes();(web/"feed.txt").write_bytes(valid.replace(b"1.12.15",b"1.12.16",1))
 state=snapshot(cache)
 try:powershell(code+invoke,OUT);raise AssertionError("bad signature accepted")
 except AssertionError as err:assert "bad signature accepted" not in str(err)
 assert snapshot(cache)==state
finally:server.shutdown();server.server_close()
lua.globals().recovered=str(cache/"1.12.15.lua")
lua.execute("""
fresh=assert(loadfile(recovered))();fresh.specialShopEnabled=true
s2=fresh.connect(base,"formday-buddy","owner",{})
assert(not s2.wallet.error and s2.wallet.powder==99970 and s2:owns("zapdos") and s2:owns("mew"))
assert(not s2:purchase("mew"));assert(s2.wallet.powder==99970)
assert(s2.wallet.stones.leaf==1)
""")
assert snapshot(data)==before
# Resume subsequent accrual/crafting, then another independent restart without rewriting old events.
lua.execute('assert(s2:earn(30001));assert(s2:craft("leaf"));assert(s2.wallet.powder==99945)')
for name,record in before.items():assert snapshot(data)[name]==record
lua.execute('again=fresh.connect(base,"formday-buddy","owner",{});assert(again.wallet.powder==99945 and again:owns("mew") and again.wallet.stones.leaf==2)')
print("PASS signed catalog install; failed signature preserved active version; forward recovery/restart/duplicate/continued earning and crafting")
summary={"candidate_catalog_sha256":digest(RC/"AvatarUnlocks-review.lua"),"candidate_host_sha256":digest(RC/"FormdayBuddy-review.zip"),"host_entry_steps":steps,"signature_verified_with_original_keys":True,"immutable_records_before":len(before),"old_reader_failed_closed":True,"forward_recovery":True,"gui_pointer_test":False,"local_transport_only":True}
(OUT/"result.json").write_text(json.dumps(summary,indent=2))
print("Evidence:",OUT)
