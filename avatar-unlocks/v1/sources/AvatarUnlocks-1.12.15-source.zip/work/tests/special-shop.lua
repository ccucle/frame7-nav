-- All writes go to the disposable local directory passed by the Python runner.
local catalog,base,resources,baseline=unpack(arg)
local M=assert(loadfile(catalog))()
local J=dofile(resources.."json.lua")
local G=dofile(resources.."geo-state.lua")
local function write(p,s) local f=assert(io.open(p,"wb"));assert(f:write(s));assert(f:close()) end
local function bytes(p) local f=io.open(p,"rb");if not f then return nil end;local s=f:read("*a");f:close();return s end
local function eq(a,b,msg) assert(a==b,(msg or "value")..": "..tostring(a).." ~= "..tostring(b)) end
local function session(avatar,profile) return M.connect(base,avatar,profile,{}) end
local prices={articuno=20000,zapdos=20000,moltres=20000,mew=30000,mewtwo=40000}
local n=0;for id,price in pairs(M.specialPrices) do eq(price,prices[id]);n=n+1 end;eq(n,5)
local content=J.decode(M.contentJson);local required=0
for _,family in pairs(content.families) do for _,row in ipairs(family) do
 if row[1]<=151 and M.requiredForGeneration(row[2]) then required=required+1 end
end end
eq(required,146);assert(M.requiredForGeneration("lugia") and M.requiredForGeneration("celebi"))
-- Old host: both policy activation and purchasing are off together.
local legacy=session("future-avatar","legacy")
eq(select(2,legacy:purchaseStatus("mew")),"update");assert(not legacy:purchase("mew"));assert(M.levelRewardAllowed("mew"))
M.specialShopEnabled=true
local buddy=session("formday-buddy","one")
assert(buddy:earn(30000));eq(buddy.wallet.powder,150000)
assert(buddy:craft("leaf"));eq(buddy.wallet.powder,149970)
for _,id in ipairs({"articuno","zapdos","moltres","mew","mewtwo"}) do
 local before=buddy.wallet.powder
 assert(buddy:purchase(id));eq(buddy.wallet.powder,before-prices[id]);assert(buddy:owns(id))
 local seq=buddy.wallet.sequence;assert(not buddy:purchase(id));eq(buddy.wallet.sequence,seq)
end
eq(buddy.wallet.powder,19970);eq(buddy.wallet.stones.leaf,1)
local restarted=session("formday-buddy","one");eq(restarted.wallet.powder,19970);assert(restarted:owns("mew"))
assert(restarted:togglePokemon("mew"));assert(session("formday-buddy","one"):pokemonOut("mew"))
local low=session("formday-buddy","low");assert(low:earn(3999));eq(select(2,low:purchase("zapdos")),"low");eq(low.wallet.powder,19995)
assert(low:earn(4000));assert(low:purchase("zapdos"));eq(low.wallet.powder,0)
assert(not low:purchase("lugia"))
-- Pre-existing owned files are never charged or rewritten.
write(base.."unlock~formday-buddy~held~mew.owned","mew\n")
local held=session("formday-buddy","held");assert(held:earn(8000));assert(not held:purchase("mew"));eq(held.wallet.powder,40000)
eq(bytes(base.."unlock~formday-buddy~held~mew.owned"),"mew\n")
-- New avatar uses exactly the same policy and its own ordinary ledger.
local extra={};for id in pairs(prices) do extra[#extra+1]={id=id,kind="pokemon",level=1} end
extra[#extra+1]={id="ditto",kind="pokemon",level=1}
local third=M.connect(base,"synthetic-new","one",extra)
assert(third:earn(6000));third:sync(999);assert(third:owns("ditto"))
for id in pairs(prices) do assert(not third:owns(id)) end
assert(third:purchase("mew"));eq(third.wallet.powder,0);eq(session("formday-buddy","one").wallet.powder,19970)
-- Only five automatic rewards are removed; all original rewards still match the baseline.
local old=assert(loadfile(baseline.."catalog.lua"))()
for _,avatar in ipairs({"formday-buddy","formday-geo"}) do
 local oldSession=old.connect(base,avatar,"old-rewards",{})
 local newSession=session(avatar,"new-rewards")
 oldSession:sync(999);newSession:sync(999)
 for _,item in ipairs(old.catalogFor(avatar,{})) do
  if not prices[item.id] then eq(newSession:owns(item.id),oldSession:owns(item.id),avatar.." "..item.id)
  else assert(not newSession:owns(item.id)) end
 end
end
-- Existing X/C/E replay is byte-for-byte preserved.
local prefix=base.."unlock~formday-buddy~old-wallet~wallet-"
local records={"X 100\n","C leaf\n","E exeggutor leaf 1\n","X 101 7\n"}
for i,r in ipairs(records) do write(prefix..string.format("%09d.txn",i),r) end
local compat=session("formday-buddy","old-wallet");eq(compat.wallet.powder,477);assert(compat:owns("exeggutor"))
for i,r in ipairs(records) do eq(bytes(prefix..string.format("%09d.txn",i)),r) end
-- Old Buddy reader fails closed at the new event; supported host must ship the new reader.
local oldRead=old.connect(base,"formday-buddy","one",{})
eq(oldRead.wallet.error,"invalid receipt");assert(not oldRead:earn(99999));assert(not oldRead:craft("leaf"))
-- Failed open/write/close/rename must not charge or grant.
for _,fault in ipairs({"open","write","close","rename"}) do
 local s=session("formday-buddy",fault);assert(s:earn(6000));local nativeOpen,nativeRename=io.open,os.rename
 io.open=function(path,mode)
  if mode=="wb" and path:match("%.wallet$") then
   if fault=="open" then return nil end
   local f=assert(nativeOpen(path,mode))
   if fault=="write" then return {write=function() return nil end,close=function() return f:close() end} end
   if fault=="close" then return {write=function(_,r)return f:write(r) end,close=function() f:close();return nil end} end
   return f
  end
  return nativeOpen(path,mode)
 end
 if fault=="rename" then os.rename=function() return nil end end
 assert(not s:purchase("mew"));eq(s.wallet.powder,30000);assert(not s:owns("mew"))
 io.open,os.rename=nativeOpen,nativeRename
 eq(session("formday-buddy",fault).wallet.powder,30000)
end
-- Two stale sessions race for the same ordinal. The losing purchase re-evaluates ownership.
local a=session("formday-buddy","race");assert(a:earn(8000));local b=session("formday-buddy","race")
local rename=os.rename;local once=false
os.rename=function(src,dst)
 if not once and dst:match("wallet%-%d+%.txn$") then once=true;assert(b:purchase("mew")) end
 return rename(src,dst)
end
assert(not a:purchase("mew"));os.rename=rename;eq(a.wallet.powder,10000);eq(a.wallet.sequence,2)
-- Geo full snapshots use the same callback; the old Geo reader also understands the result.
local geoPath=base.."geo/"
local seed={format=2,avatar="formday-geo",owner="synthetic-owner",connection="connected",revision=1,fetched_at=os.time(),balance={base_xp=90,earned_count=0,total_xp=90,powder=140000,level=4,xp_into_level=0,stones={leaf=12},forms={bulbasaur=true}}}
local w=G.wallet(geoPath,J);local row,status=w.ingest(seed,geoPath,M.powderAward);eq(status,"committed")
local gs={wallet=row,owns=function(self,id)return self.wallet.forms[id]==true end}
function gs:commitPurchase(plan) local after,reason=w.purchase(plan);self.wallet=after;return reason=="committed",reason end
M.attachShop(gs)
for _,id in ipairs({"articuno","zapdos","moltres","mew","mewtwo"}) do assert(gs:purchase(id)) end
eq(gs.wallet.powder,10000);eq(gs.wallet.stones.leaf,12);assert(gs:owns("bulbasaur"))
local seq=gs.wallet.sequence;assert(not gs:purchase("mew"));eq(gs.wallet.sequence,seq)
local oldGeo=dofile(baseline.."geo-state.lua").wallet(geoPath,J).read();eq(oldGeo.powder,10000);assert(oldGeo.forms.mew and oldGeo.forms.mewtwo)
local after,why=w.craft("leaf");eq(why,"committed");eq(after.powder,9970)
after,why=w.evolve("ivysaur",{parent="bulbasaur",stone="leaf",cost=5},function(id)return after.forms[id] end);eq(why,"committed");assert(after.forms.ivysaur)

-- A close/rename failure, conflict, and an oversized new snapshot preserve the last state.
local prior=w.read();local priorPowder=prior.powder;local priorSeq=prior.sequence
local nativeRename=os.rename;os.rename=function()return nil end
local failed,result=w.purchase(function()return {id="test-uncommitted",cost=10} end)
os.rename=nativeRename;eq(result,"write");eq(failed.sequence,priorSeq);eq(w.read().powder,priorPowder)
local nativeOpen=io.open
io.open=function(path,mode)
 local f=nativeOpen(path,mode)
 if f and mode=="wb" and path:match("%.tmp$") then return {write=function(_,s)return f:write(s) end,close=function()f:close();return nil end} end
 return f
end
failed,result=w.purchase(function()return {id="test-uncommitted",cost=10} end)
io.open=nativeOpen;eq(result,"write");eq(w.read().powder,priorPowder)
-- The opaque metadata is preserved; reject a result beyond the existing 64 KiB reader limit.
prior.futureMetadata="keep"
after,result=w.purchase(function()return {id="test-metadata",cost=1} end)
eq(result,"committed");eq(after.futureMetadata,"keep")
after.futureMetadata=string.rep("z",65536)
failed,result=w.purchase(function()return {id="test-too-large",cost=1} end)
eq(result,"write");assert(not failed.forms["test-too-large"])
after.futureMetadata="keep"
seed.owner="foreign";local denied,why=w.ingest(seed,geoPath,M.powderAward);assert(not denied);eq(why,"unavailable")
eq(session("formday-buddy","one").wallet.powder,19970)
print("PASS shared policy, 146 prerequisites, old rewards/wallets, five prices, restart, duplicate, insufficient, independent profiles, failures, racing commit, Geo old reader, craft/evolve/summon")
