"""Local Windows-only, isolated shop + existing regression suites (requires lupa/Pillow)."""
import os, sys, time, json, contextlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
assert os.name=="nt" and ROOT==Path(r"C:\Users\ccucl\Projects\Geo-UnlockDex-Shop")
sys.path[:0]=[str(ROOT/"work"),str(ROOT/"work/test-deps"),str(ROOT/"work/tests")]
from package_skin import unlock_engine
from lupa.lua51 import LuaRuntime as Lua51
from lupa.lua53 import LuaRuntime as Lua53
import check_profile_routing as routing
OUT=ROOT/"work/shop/qa"/("run-"+str(time.time_ns()))
OUT.mkdir(parents=True)
CATALOG=OUT/"catalog.lua"
CATALOG.write_bytes(unlock_engine())
assert CATALOG.stat().st_size<=2097152

def run(script,args,runtime=Lua51):
    lua=runtime()
    lua.globals().arg=lua.table_from([str(x) for x in args])
    # A failed assertion must raise in Python, never terminate the runner silently.
    lua.execute('os.exit=function(code) error("exit "..tostring(code)) end')
    lua.execute(Path(script).read_text(encoding="utf-8"))

wallet=OUT/"wallet"
(wallet/"geo").mkdir(parents=True)
run(ROOT/"work/tests/special-shop.lua",[CATALOG,str(wallet)+"/",str(ROOT/"DesktopSkin/@Resources")+"/",str(ROOT/"work/shop/baseline")+"/"])
for name in ("family-rules","family-cache-gallery","pokemon-generations"):
    run(ROOT/"work/tests"/(name+".lua"),[CATALOG,ROOT/"DesktopSkin/@Resources/json.lua"])
run(ROOT/"work/tests/family-sync-launch.lua",[CATALOG,"quiet"],Lua53)
route=OUT/"routing"
route.mkdir()
engine=routing.prepare(route,ROOT/"DesktopSkin/@Resources",CATALOG)
(route/"res/unlock-engine.lua").write_bytes(CATALOG.read_bytes())
oldcwd=Path.cwd()
try:
    os.chdir(route)
    def case(name,mode):
        run(ROOT/"work/tests/profile-routing.lua",[route,name,"formday-buddy","4",mode,"1.12.15"],Lua53)
    for name in routing.CASES:
        routing.setup_case(route/name,engine,"1.12.15")
        if name=="foreign-restart": case(name,"offline")
        case(name,name)
        if name=="switch":
            before=routing.records(route/name/"data")
            case(name,"restart")
            assert before==routing.records(route/name/"data")
    routing.setup_case(route/"shop",engine,"1.12.15")
    seed=json.loads((route/"shop/sync/geo-live.json").read_text())
    seed["balance"]["powder"]=30000
    (route/"shop/sync/geo-live.json").write_text(json.dumps(seed))
    run(ROOT/"work/tests/shop-host.lua",[route,"shop","formday-buddy","4","shop","1.12.15"],Lua53)
    routing.setup_case(route/"reader-guard",engine,"1.12.15")
    guard=route/"reader-guard/cache/FormdayAvatar/Unlocks/v1"
    older=(ROOT/"work/shop/baseline/catalog.lua").read_bytes().replace(b"1.12.14",b"1.12.16")
    (guard/"1.12.16.lua").write_bytes(older)
    (guard/"active.txt").write_text("1.12.16")
    run(ROOT/"work/tests/profile-routing.lua",[route,"reader-guard","formday-buddy","4","switch","1.12.15"],Lua53)
finally:
    os.chdir(oldcwd)
print("PASS all suites; artifacts:",OUT,flush=True)
