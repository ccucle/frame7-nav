-- Lightweight 10 Hz, bounded desktop movement.
local values,atlas,x,y,lastX,lastY,dx,dy,left,pause,distance,lastCrop,dir
local token,hovered,settle=nil,false,0
local privatePath
local menuOpen=false
local menuW,menuH=120,60
local dirs={{-1,0},{1,0},{0,1},{0,-1},{1,1},{-1,1},{1,-1},{-1,-1}}
local function var(n) return tonumber(SKIN:ReplaceVariables("#"..n.."#")) or 0 end
local function bounds()
 local l,t=var("WORKAREAX"),var("WORKAREAY")
 return l,t,math.max(l,l+var("WORKAREAWIDTH")-values[3]),math.max(t,t+var("WORKAREAHEIGHT")-values[4])
end
local function move(l,t,r,b)
 x,y=math.max(l,math.min(x,r)),math.max(t,math.min(y,b))
 local px,py=math.floor(x+0.5),math.floor(y+0.5)
 if px~=lastX or py~=lastY then SKIN:Bang("!Move",px,py);lastX,lastY=px,py end
end
local function paint(walking)
 local row,bx,by,w,h,d,g,strip,cycle=unpack(values,5,13)
 local n=walking and distance%cycle or 0
 local cx,cy
 if strip>=0 then
  local f=0
  while values[14+f] and n>=values[14+f] do f=f+1 end
  cx,cy=f*w*d,strip+(dir>0 and h*d or 0)
 else
  local f=math.floor(n/4)
  cx=math.floor(row/8)*128*g+(f*32+bx)*d
  cy=(row%8)*64*g+((dir>0 and 32 or 0)+by)*d
 end
 local crop=table.concat({cx,cy,w*d,h*d},",")
 if crop~=lastCrop then
  SKIN:Bang("!SetOption","Sprite","ImageCrop",crop); SKIN:Bang("!UpdateMeter","Sprite");lastCrop=crop
 end
end
function Hover(active)
 hovered=active==1
 if not hovered then settle=4 end
end
function RequestReturn()
 if not token then return end
 local f=io.open(privatePath.."return."..token..".txt","wb");if not f then return end
 f:write("return\n");f:close()
end
local function position(name,px,py)
 SKIN:Bang("!SetOption",name,"X",px)
 SKIN:Bang("!SetOption",name,"Y",py)
end
function CloseChoice()
 if not menuOpen then return end
 menuOpen=false
 SKIN:Bang("!HideMeterGroup","PokemonChoice")
 position("Sprite",0,0)
 SKIN:Bang("!UpdateMeter","Sprite")
 SKIN:Bang("!Redraw")
 SKIN:Bang("!Draggable",1)
 lastX,lastY=nil,nil
 move(bounds());settle=5
end
function ConfirmReturn()
 if not menuOpen then return end
 CloseChoice();RequestReturn()
end
function OpenChoice(mx,my)
 if not values or not token then return end
 if menuOpen then CloseChoice();return end
 local l,t,r,b=bounds()
 x,y=var("CURRENTCONFIGX"),var("CURRENTCONFIGY")
 local w,h=values[3],values[4]
 local right,bottom=r+w,b+h
 mx=tonumber(mx) or w/2;my=tonumber(my) or h/2
 local ax,ay=x+mx,y+my
 local px=math.max(x+w+2,ax+4)
 if px+menuW>right then px=math.min(x-menuW-2,ax-menuW-4) end
 px=math.max(l,math.min(px,math.max(l,right-menuW)))
 local py=math.max(t,math.min(ay+2,math.max(t,bottom-menuH)))
 local nx,ny=math.min(x,px),math.min(y,py)
 menuOpen=true
 SKIN:Bang("!Draggable",0)
 position("Sprite",x-nx,y-ny)
 position("ChoicePanel",px-nx,py-ny)
 position("ChoiceReturn",px-nx+4,py-ny+4)
 position("ChoiceClose",px-nx+4,py-ny+31)
 SKIN:Bang("!ShowMeterGroup","PokemonChoice")
 SKIN:Bang("!Move",nx,ny)
 SKIN:Bang("!UpdateMeter","Sprite")
 SKIN:Bang("!UpdateMeterGroup","PokemonChoice")
 SKIN:Bang("!Redraw")
end
function Initialize()
 privatePath=SKIN:GetVariable("CURRENTPATH")
 local f=io.open(privatePath.."state.txt","rb");if not f then return end
 local line=f:read("*l");atlas=f:read("*l");local key=f:read("*l");f:close()
 if key and key:match("^[0-9][0-9%-]+$") then token=key end
 if not line or not atlas or not atlas:match("unlock%-walk%-%d+%.%d+%.%d+%.png$") then return end
 values={};for n in line:gmatch("[^,]+") do local v=tonumber(n);if not v then values=nil;return end;values[#values+1]=v end
 if #values<13 or values[3]<1 or values[4]<1 or values[13]<1 then values=nil;return end
 math.randomseed(os.time()+values[5]*79+values[2])
 x,y,dx,dy,left,pause,distance,dir=values[1],values[2],0,0,0,4+values[5]%11,0,1
 SKIN:Bang("!SetOption","Sprite","ImageName",atlas)
 SKIN:Bang("!SetOption","Sprite","W",values[3]);SKIN:Bang("!SetOption","Sprite","H",values[4])
 move(bounds());paint(false)
end
function Update()
 if not values or menuOpen then return 0 end
 local l,t,r,b=bounds()
 if token then
  local gx,gy=tonumber(SKIN:ReplaceVariables("#CURRENTCONFIGX#")),tonumber(SKIN:ReplaceVariables("#CURRENTCONFIGY#"))
  if gx and gy and (gx~=lastX or gy~=lastY) then
   x,y,lastX,lastY=gx,gy,gx,gy;settle=4
  end
  if hovered or settle>0 then
   if settle>0 then settle=settle-1 end
   paint(false);return 0
  end
 end
 if pause>0 then pause=pause-1;paint(false);return 0 end
 if left<=0 then
  local d=dirs[math.random(#dirs)]
  dx,dy=d[1],d[2];if dx~=0 then dir=dx end
  left=math.random(12,40)
 end
 local speed=3 -- 1 px / 50 ms for Buddy, 1.5x at 100 ms here
 if dx~=0 and dy~=0 then speed=speed/math.sqrt(2) end
 local ox,oy=x,y;x,y=x+dx*speed,y+dy*speed
 move(l,t,r,b)
 distance=distance+math.sqrt((x-ox)^2+(y-oy)^2)
 left=left-1
 if left<=0 or (x==ox and y==oy) then left=0;pause=math.random(5,16) end
 paint(left>0)
 return 0
end
