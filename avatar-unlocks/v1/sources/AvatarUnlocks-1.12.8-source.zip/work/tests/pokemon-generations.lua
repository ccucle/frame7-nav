-- Test the gallery against an assembled catalog and the host JSON decoder.
local M=assert(loadfile(arg[1]))()
local content=assert(loadfile(arg[2]))().decode(M.contentJson)
local options,shown={},{}
unpack=unpack or table.unpack
SKIN={
    GetVariable=function() return "formday-buddy" end,
    Bang=function(_,command,name,key,value)
        if command=="!SetOption" then
            options[name]=options[name] or {}
            options[name][key]=value
        elseif command=="!ShowMeter" or command=="!HideMeter" then
            shown[name]=command=="!ShowMeter"
        end
    end
}
M.imageFile=function() return "fixture.png" end
local g=M.createGallery()
g.init("","",content.families,content.sizes,content.galleryPositions)
local extras=M.catalogFor("formday-buddy",{})
g.bind(M,extras,nil)
g.open(0,0)
g.tab(3)
local function count()
    return tonumber(options.GalleryCount.Text:match("/ (%d+)$"))
end
local function choose(index)
    g.toggleGeneration()
    assert(shown.GalleryEvolution7 and shown.GalleryEvolution8 and shown.GalleryEvolution9)
    assert(not shown.GalleryUpdates)
    g.setGeneration(index)
    assert(not shown.GalleryEvolution7 and shown.GalleryUpdates)
end
local totals={0,0}
local all=0
for _,family in pairs(content.families) do
    for _,row in ipairs(family) do
        all=all+1
        if row[1]<=151 then totals[1]=totals[1]+1
        elseif row[1]<=251 then totals[2]=totals[2]+1 end
    end
end
for _,item in ipairs(M.gallery) do
    if item.kind=="pokemon" and item.dex then
        all=all+1
        if item.dex<=151 then totals[1]=totals[1]+1
        elseif item.dex<=251 then totals[2]=totals[2]+1 end
    end
end
assert(totals[1]==151 and totals[2]==55)
assert(count()==all)
choose(1)
assert(count()==totals[1])
g.page(1)
choose(2)
assert(count()==totals[2] and options.GalleryPageNumber.Text:match("^1 /"))
g.search("이상해씨"); assert(count()==0 and shown.GalleryEmpty)
choose(1); assert(count()==1 and not shown.GalleryEmpty)
g.search("pichu"); assert(count()==0)
choose(2); assert(count()==1)
g.search("#0172");assert(count()==1)
g.select(1)
assert(shown.GalleryEvolution1 and not shown.GallerySearch)
g.back();assert(count()==1 and shown.GallerySearch and not shown.GalleryEvolution7)
g.clear();assert(count()==totals[2])
g.toggleGeneration();g.scrollGeneration(-1);assert(count()==totals[1])
g.scrollGeneration(-1);g.scrollGeneration(-1);assert(count()==all)
g.scrollGeneration(1);g.scrollGeneration(1);g.scrollGeneration(1);assert(count()==totals[2])
g.tab(2);assert(not shown.GalleryEvolution6 and not shown.GalleryEvolution7 and shown.GalleryUpdates)
g.tab(3);assert(count()==totals[2])
g.hide();g.open(0,0);assert(count()==all)
g.search("#0152");assert(count()==1 and shown.GalleryArt1 and shown.GalleryLock1)
assert(options.GalleryArt1.ImageCrop~="64,192,12,12")
g.search("celebi");assert(count()==0 and shown.GalleryEmpty)
print("PASS new card search, portrait, and locked state")

-- Newly registered and unnumbered host cards exercise the generation boundaries.
for _,n in ipairs({151,152,251,252}) do
    extras[#extras+1]={id="fixture-"..n,name="fixture",kind="pokemon",dex=n}
end
extras[#extras+1]={id="fixture-unknown",name="fixture",kind="pokemon"}
local extended={}
for i,item in ipairs(extras) do extended[i]=item end
g.bind(M,extended,nil)
g.search("fixture");assert(count()==5)
choose(1);assert(count()==1)
choose(2);assert(count()==2)
print("PASS generation filter: "..all.." total, "..totals[1].." first, "..totals[2].." second; combined search, navigation and boundaries")

