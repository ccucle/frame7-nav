local costHelper, costCache, costDecode
local nextCostRead,nextCostFetch=0,0

local function writeAsset(path,bytes)
    local f=io.open(path,"rb")
    if f then
        local same=f:read("*a")==bytes
        f:close()
        if same then return true end
    end
    local tmp=path.."."..tostring({}):gsub("[^%w]","")..".tmp"
    f=io.open(tmp,"wb")
    if not f then return false end
    local ok=f:write(bytes)
    local closed=f:close()
    if ok and closed and os.rename(tmp,path) then return true end
    os.remove(tmp)
    f=io.open(path,"rb")
    if not f then return false end
    local same=f:read("*a")==bytes
    f:close()
    return same
end

local function launchCosts(mode)
    if not costHelper then return end
    local path=shared.."evolution-"..engine.version
    if not writeAsset(path..".ps1","\239\187\191"..engine.costScript) or
       not writeAsset(path..".json",engine.costRoutes) then return end
    local exe=os.getenv("SystemRoot").."\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"
    SKIN:Bang('["'..exe..'" -NoProfile -NonInteractive -STA -ExecutionPolicy RemoteSigned -WindowStyle Hidden -File "'..path..'.ps1" -Mode '..mode..']')
end

local function refreshCosts()
    if not costCache or not exists(shared.."family-evolution.enabled") then return false end
    local f=io.open(costCache,"rb")
    if not f then return false end
    local s=f:read(65537)
    f:close()
    if not s or #s>65536 or s==costHelper.last then return false end
    costHelper.last=s
    local ok,doc=pcall(costDecode,s)
    if ok and engine.applyCostRules(doc) then
        if gallery then gallery.refresh() end
        return true
    end
    return false
end

local function pollCosts(opening)
    local now=os.time()
    if now>=nextCostRead then nextCostRead=now+2;refreshCosts() end
    if now>=nextCostFetch or (opening and now>=nextCostFetch-100) then
        nextCostFetch=now+120
        if exists(shared.."family-evolution.enabled") then launchCosts("Sync") end
    end
end

function OpenCostEditor()
    if panelOpen and not showingUpdates then launchCosts("Editor") end
end

