param([ValidateSet('Editor','Sync','Library')][string]$Mode='Editor')
$ErrorActionPreference='Stop'
$rulesApi='https://api.github.com/repos/ccucle/frame7-nav/contents/rules.json'
$rulesBranch='formday-family-evolution'
$cache=Join-Path $PSScriptRoot 'family-evolution.json'
$familyLink=Join-Path $PSScriptRoot 'family-evolution.enabled'
$utf8=[Text.UTF8Encoding]::new($false)
$ProgressPreference='SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12

function Test-Count($value) {
    ($value -is [int] -or $value -is [long]) -and $value -ge 1 -and $value -le 999
}
function Convert-Rules($value) {
    if ($value.schema -ne 1 -or $value.revision -isnot [int] -and $value.revision -isnot [long] -or
        $value.revision -lt 1 -or $value.revision -gt 2147483647 -or
        !(Test-Count $value.first) -or !(Test-Count $value.second) -or $value.overrides -isnot [pscustomobject]) {
        throw '진화 규칙 파일 형식을 확인해 주세요.'
    }
    $entries=@{}
    foreach ($p in $value.overrides.PSObject.Properties) {
        if ($p.Name -cnotmatch '^[a-z0-9_-]{1,48}/[a-z0-9_-]{1,48}$' -or !(Test-Count $p.Value)) {throw '잘못된 진화 경로 또는 비용입니다.'}
        $entries[$p.Name]=[int]$p.Value
    }
    [ordered]@{schema=1;revision=[int]$value.revision;first=[int]$value.first;second=[int]$value.second;overrides=$entries}
}
function Copy-Rules($rules) {Convert-Rules (ConvertFrom-Json (ConvertTo-Json $rules -Depth 5 -Compress))}
function Get-Cost($rules,$route) {
    if ($rules.overrides.ContainsKey($route.edge)) {return $rules.overrides[$route.edge]}
    if ($route.stage -eq 1) {return $rules.first}
    $rules.second
}
function Get-Changes($before,$after,$routes) {
    foreach ($r in $routes) {
        $old=Get-Cost $before $r
        $new=Get-Cost $after $r
        if ($old -ne $new -or $before.overrides.ContainsKey($r.edge) -ne $after.overrides.ContainsKey($r.edge)) {
            [pscustomobject]@{route=$r;old=$old;new=$new;custom=$after.overrides.ContainsKey($r.edge)}
        }
    }
}
function Find-Routes($routes,[string]$query) {
    $q=$query.Trim().TrimStart('#')
    if (!$q) {return $routes}
    $families=@{}
    foreach ($r in $routes) {
        if ($q -match '^\d+$') {
            if ($q.TrimStart('0') -in @([string]$r.dex,[string]$r.parentDex)) {$families[$r.family]=1}
        } elseif (($r.name,$r.parentName,$r.id,$r.parent -join ' ').IndexOf($q,[StringComparison]::OrdinalIgnoreCase) -ge 0) {$families[$r.family]=1}
    }
    $routes | Where-Object {$families.ContainsKey($_.family)}
}
function Read-Snapshot {
    $reply=Invoke-RestMethod -UseBasicParsing -TimeoutSec 10 -Headers @{'User-Agent'='Formday-Evolution';'Cache-Control'='no-cache'} -Uri ($rulesApi+'?ref='+$rulesBranch+'&t='+[DateTimeOffset]::UtcNow.ToUnixTimeSeconds())
    if ($reply.sha -cnotmatch '^[a-f0-9]{40}$' -or $reply.size -gt 65536 -or $reply.encoding -ne 'base64') {throw '공유 규칙을 확인할 수 없습니다.'}
    $rules=Convert-Rules (ConvertFrom-Json ($utf8.GetString([Convert]::FromBase64String($reply.content))))
    [pscustomobject]@{sha=$reply.sha;rules=$rules}
}
function Set-Cache($rules) {
    $lock=New-Object Threading.Mutex($false,'Local\FormdayFamilyEvolutionCache')
    $held=$false
    try {
        try {$held=$lock.WaitOne(4500)} catch [Threading.AbandonedMutexException] {$held=$true}
        if (!$held) {throw '도감 동기화가 진행 중입니다.'}
        if ([IO.File]::Exists($cache)) {
            try {$existing=Convert-Rules (ConvertFrom-Json ([IO.File]::ReadAllText($cache)))
                 if ($existing.revision -ge $rules.revision) {return}} catch {}
        }
        $tmp=$cache+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
        try {
            [IO.File]::WriteAllText($tmp,(ConvertTo-Json $rules -Compress -Depth 5),$utf8)
            if ([IO.File]::Exists($cache)) {[IO.File]::Replace($tmp,$cache,$cache+'.previous')} else {[IO.File]::Move($tmp,$cache)}
        } finally {if ([IO.File]::Exists($tmp)) {[IO.File]::Delete($tmp)}}
    } finally {if ($held) {$lock.ReleaseMutex()};$lock.Dispose()}
}
function Publish-Rules($base,$draft,$credential) {
    $doc=Copy-Rules $draft
    $doc.revision=$base.rules.revision+1
    $body=@{message='Update family evolution costs';branch=$rulesBranch;sha=$base.sha
        content=[Convert]::ToBase64String($utf8.GetBytes((ConvertTo-Json $doc -Depth 5 -Compress)))}
    try {
        if ($credential -eq 'GitHubCLI') {
            $json=(ConvertTo-Json $body -Compress) | & $githubCli api --hostname github.com --method PUT repos/ccucle/frame7-nav/contents/rules.json --input - 2>&1
            if ($LASTEXITCODE) {
                if (($json -join ' ') -match 'HTTP (409|422)') {throw 'CONFLICT'}
                throw 'GitHub 권한 확인 실패'
            }
            $result=ConvertFrom-Json ($json -join [Environment]::NewLine)
        } else {
            $headers=@{'User-Agent'='Formday-Evolution';Authorization=('Bearer '+$credential.GetNetworkCredential().Password)}
            $result=Invoke-RestMethod -Method Put -Uri $rulesApi -UseBasicParsing -Headers $headers -TimeoutSec 15 -ContentType 'application/json' -Body (ConvertTo-Json $body -Compress)
        }
    } catch {
        if ($_.Exception.Message -eq 'CONFLICT' -or ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -in @(409,422))) {throw '다른 변경이 먼저 저장됐습니다. 새로고침한 뒤 다시 편집해 주세요.'}
        throw '공유 저장을 확인하지 못했습니다. 연결과 편집 권한을 확인한 뒤 새로고침해 주세요.'
    }
    if ($result.content.sha -cnotmatch '^[a-f0-9]{40}$') {throw '저장 결과를 확인하지 못했습니다.'}
    Set-Cache $doc
    [pscustomobject]@{sha=$result.content.sha;rules=$doc}
}
if ($Mode -eq 'Library') {return}
if ($Mode -eq 'Sync') {
    if (![IO.File]::Exists($familyLink)) {exit 0}
    try {
        $url='https://raw.githubusercontent.com/ccucle/frame7-nav/'+$rulesBranch+'/rules.json?t='+[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        $result=Invoke-WebRequest -UseBasicParsing -TimeoutSec 10 -Uri $url
        if ($result.RawContentLength -gt 65536) {throw '규칙 파일이 너무 큽니다.'}
        $body=if ($result.Content -is [byte[]]) {$utf8.GetString($result.Content)} else {$result.Content}
        Set-Cache (Convert-Rules (ConvertFrom-Json $body))
    } catch {exit 1}
    exit 0
}

Add-Type -AssemblyName PresentationFramework
$layout=@'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="해금도감 · 진화 비용" Width="480" Height="610" MinWidth="430" MinHeight="530" Background="#F7F3E5" FontFamily="Galmuri9 Regular, Malgun Gothic" WindowStartupLocation="CenterScreen" UseLayoutRounding="True">
<Window.Resources>
  <Style TargetType="Button"><Setter Property="Background" Value="#E7E5CB"/><Setter Property="Foreground" Value="#253B3B"/><Setter Property="BorderBrush" Value="#42534B"/><Setter Property="Padding" Value="10,5"/><Setter Property="Margin" Value="2"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border x:Name="b" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="2,1,2,3" Padding="{TemplateBinding Padding}"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="b" Property="BorderBrush" Value="#518468"/></Trigger><Trigger Property="IsEnabled" Value="False"><Setter TargetName="b" Property="Opacity" Value=".5"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
  <Style TargetType="TextBox"><Setter Property="Padding" Value="6,4"/><Setter Property="BorderBrush" Value="#84998C"/><Setter Property="VerticalContentAlignment" Value="Center"/></Style>
</Window.Resources>
<Border BorderBrush="#253B3B" BorderThickness="3"><DockPanel>
<Border DockPanel.Dock="Top" Background="#263D3E" Padding="14,10"><DockPanel><Button Name="Admin" DockPanel.Dock="Right" Content="관리자 연결"/><TextBlock Foreground="#FFF7DC" FontSize="18" VerticalAlignment="Center" Text="⚙  진화 비용 편집"/></DockPanel></Border>
<StackPanel DockPanel.Dock="Bottom" Margin="12,2,12,10"><TextBlock Name="Status" TextWrapping="Wrap" Margin="3,6" Foreground="#42534B"/><DockPanel><Button Name="Family" DockPanel.Dock="Left" Content="가족 규칙 연결"/><Button Name="Reload" DockPanel.Dock="Left" Content="새로고침"/><Button Name="Review" Content="변경 확인" Background="#F6C471"/></DockPanel></StackPanel>
<TabControl Margin="12" Background="#F7F3E5" BorderBrush="#829588"><TabItem Header="  기본값  "><StackPanel Margin="14">
<TextBlock Text="진화 단계별 기본 비용" FontWeight="Bold" FontSize="16" Margin="0,6,0,8"/><TextBlock Text="개별 지정한 경로는 기존 개수를 유지합니다." TextWrapping="Wrap" Margin="0,0,0,18"/>
<TextBlock Text="첫 번째 진화 · 기본형 → 1차 진화"/><TextBox Name="First" MaxLength="3" Margin="0,4,0,18"/>
<TextBlock Text="두 번째 진화 · 1차 → 2차 진화"/><TextBox Name="Second" MaxLength="3" Margin="0,4,0,10"/>
<TextBlock Text="각 단계에 필요한 돌을 1~999개로 지정합니다." Foreground="#516859"/>
</StackPanel></TabItem>
<TabItem Header="  개별 설정  "><DockPanel Margin="8"><StackPanel DockPanel.Dock="Top"><TextBlock Text="이름 또는 도감 번호로 계열 찾기"/><TextBox Name="Search" Margin="0,4,0,7"/></StackPanel>
<StackPanel DockPanel.Dock="Bottom" Margin="0,8,0,0"><TextBlock Name="Choice" TextWrapping="Wrap" Margin="0,0,0,4"/><DockPanel><Button Name="ResetEdge" DockPanel.Dock="Right" Content="기본값으로 복원"/><Button Name="SetEdge" DockPanel.Dock="Right" Content="개별 지정"/><TextBox Name="EdgeCost" MaxLength="3" VerticalAlignment="Center"/></DockPanel></StackPanel>
<ListBox Name="Routes" Background="#F7F4E4" BorderBrush="#8D988A" ScrollViewer.HorizontalScrollBarVisibility="Disabled"/></DockPanel></TabItem></TabControl>
</DockPanel></Border></Window>
'@
$window=[Windows.Markup.XamlReader]::Parse($layout)
foreach ($n in 'Admin','Family','Status','Reload','Review','First','Second','Search','Choice','EdgeCost','SetEdge','ResetEdge','Routes') {
    Set-Variable -Name $n -Value ($window.FindName($n))
}
$routeFile=[IO.Path]::ChangeExtension($PSCommandPath,'.json')
$allRoutes=ConvertFrom-Json ([IO.File]::ReadAllText($routeFile))
$state=@{base=$null;draft=$null;auth=$null;busy=$false}
$credentialFile=Join-Path $PSScriptRoot 'family-editor-current-user.xml'
$cliFlag=Join-Path $PSScriptRoot 'family-editor-gh.enabled'
$githubCli=Join-Path $env:ProgramFiles 'GitHub CLI\gh.exe'
if (!(Test-Path -LiteralPath $githubCli)) {$githubCli=(Get-Command gh.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1).Source}
function Update-Controls {
    $edit=$null -ne $state.auth -and $null -ne $state.base
    foreach($control in @($First,$Second,$EdgeCost,$SetEdge,$ResetEdge,$Review)) {$control.IsEnabled=$edit}
    $Admin.Content=if($state.auth){'관리자 연결 해제'}else{'관리자 연결'}
    $Family.IsEnabled=($null -ne $state.base) -and ![IO.File]::Exists($familyLink)
    $Family.Content=if ([IO.File]::Exists($familyLink)) {'가족 규칙 연결됨'} else {'가족 규칙 연결'}
}
function Refresh-List {
    $edge=if ($Routes.SelectedItem) {$Routes.SelectedItem.Tag.edge}
    $Routes.Items.Clear()
    foreach ($r in (Find-Routes $allRoutes $Search.Text)) {
        $item=New-Object Windows.Controls.ListBoxItem
        $kind=if ($state.draft.overrides.ContainsKey($r.edge)) {'개별 지정'}else{'기본값'}
        $item.Content=('#{0:0000} {1} → {2}  ·  {3}개  [{4}]' -f [int]$r.dex,$r.parentName,$r.name,(Get-Cost $state.draft $r),$kind)
        $item.Tag=$r
        [void]$Routes.Items.Add($item)
        if ($r.edge -eq $edge) {$Routes.SelectedItem=$item}
    }
    if (!$Routes.SelectedItem -and $Routes.Items.Count) {$Routes.SelectedIndex=0}
    if (!$Routes.Items.Count) {$Choice.Text='일치하는 진화 경로가 없습니다.';$EdgeCost.Clear()}
}
function Show-Draft($doc) {
    $state.busy=$true
    $state.draft=Copy-Rules $doc
    $First.Text=[string]$doc.first;$Second.Text=[string]$doc.second
    $state.busy=$false
    Refresh-List;Update-Controls
}
function Load-Editor {
    try {
        $snap=Read-Snapshot
        if ([IO.File]::Exists($familyLink)) {Set-Cache $snap.rules}
        $state.base=$snap;Show-Draft $snap.rules
        $Status.Text="공유 규칙 $($snap.rules.revision) · 두 PC에 적용되는 설정"
    } catch {
        $state.base=$null
        $doc=Convert-Rules (ConvertFrom-Json '{"schema":1,"revision":1,"first":1,"second":2,"overrides":{}}')
        if (Test-Path -LiteralPath $cache) {try {$doc=Convert-Rules (ConvertFrom-Json ([IO.File]::ReadAllText($cache)))} catch {}}
        Show-Draft $doc;$Status.Text='공유 규칙 연결 대기 · 저장된 비용을 표시합니다.'
    }
}
function Confirm-Draft {
    if (!$state.draft -or !$state.base) {return $true}
    $b=$state.base.rules
    if ($b.first -eq $state.draft.first -and $b.second -eq $state.draft.second -and
        !(Get-Changes $b $state.draft $allRoutes) -and $First.Text -eq [string]$b.first -and $Second.Text -eq [string]$b.second) {return $true}
    [Windows.MessageBox]::Show($window,'저장하지 않은 변경을 버릴까요?','진화 비용','YesNo','Question','No') -eq 'Yes'
}
function Input-Count([string]$s) {if ($s -cmatch '^[1-9][0-9]{0,2}$') {return [int]$s};return 0}
$Search.Add_TextChanged({if ($state.draft) {Refresh-List}})
$Routes.Add_SelectionChanged({
    if ($Routes.SelectedItem) {$r=$Routes.SelectedItem.Tag;$Choice.Text="$($r.parentName) → $($r.name)  ·  $($r.stone)";$EdgeCost.Text=[string](Get-Cost $state.draft $r)}
})
$changeDefaults={
    if ($state.busy -or !$state.draft) {return}
    $a=Input-Count $First.Text;$b=Input-Count $Second.Text
    if ($a -and $b) {$state.draft.first=$a;$state.draft.second=$b;Refresh-List}
}
$First.Add_TextChanged($changeDefaults);$Second.Add_TextChanged($changeDefaults)
$SetEdge.Add_Click({
    if (!$Routes.SelectedItem) {return}
    $n=Input-Count $EdgeCost.Text
    if (!$n) {$Status.Text='돌 개수는 1~999 사이의 정수로 입력해 주세요.';return}
    $state.draft.overrides[$Routes.SelectedItem.Tag.edge]=$n;Refresh-List
})
$ResetEdge.Add_Click({if ($Routes.SelectedItem) {$state.draft.overrides.Remove($Routes.SelectedItem.Tag.edge);Refresh-List}})
$Reload.Add_Click({if (Confirm-Draft) {Load-Editor}})
$Family.Add_Click({
    try {if ($state.base) {Set-Cache $state.base.rules;[IO.File]::WriteAllText($familyLink,'1');Update-Controls;$Status.Text='이 PC가 가족 진화 규칙을 자동으로 받습니다.'}}
    catch {$Status.Text='이 PC의 가족 연결을 저장하지 못했습니다.'}
})
$window.Add_Closing({param($sender,$args2) if (!(Confirm-Draft)) {$args2.Cancel=$true}})
$Admin.Add_Click({
    if ($state.auth) {
        if (!(Confirm-Draft)) {return}
        $state.auth=$null
        if (Test-Path -LiteralPath $credentialFile) {[IO.File]::Delete($credentialFile)}
        if (Test-Path -LiteralPath $cliFlag) {[IO.File]::Delete($cliFlag)}
        Load-Editor;return
    }
    if ($githubCli) {
        try {
            $owner=& $githubCli api --hostname github.com user --jq .login 2>$null
            if ($LASTEXITCODE -eq 0 -and $owner -eq 'ccucle') {
                $canWrite=& $githubCli api --hostname github.com repos/ccucle/frame7-nav --jq .permissions.push 2>$null
                if ($LASTEXITCODE -eq 0 -and $canWrite -eq 'true') {
                    [IO.File]::WriteAllText($cliFlag,'1');[IO.File]::WriteAllText($familyLink,'1')
                    $state.auth='GitHubCLI';Load-Editor;return
                }
            }
        } catch {}
    }
    $login=[Windows.Markup.XamlReader]::Parse('<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Title="재한님 PC 관리자 연결" SizeToContent="WidthAndHeight" WindowStartupLocation="CenterOwner" Background="#F7F3E5"><StackPanel Width="378" Margin="18"><TextBlock TextWrapping="Wrap" Text="ccucle 계정의 frame7-nav 저장소 편집 토큰을 입력하세요. 이 Windows 사용자에게만 암호화해 보관합니다. 지오 PC는 연결할 필요가 없습니다."/><PasswordBox Name="Secret" Margin="0,12"/><Button Name="Accept" Content="이 PC 연결" IsDefault="True" Padding="8"/></StackPanel></Window>')
    $login.Owner=$window;$login.FindName('Accept').Add_Click({$login.DialogResult=$true})
    if ($login.ShowDialog() -ne $true) {return}
    try {
        $cred=[pscredential]::new('ccucle',$login.FindName('Secret').SecurePassword)
        $h=@{Authorization=('Bearer '+$cred.GetNetworkCredential().Password);'User-Agent'='Formday-Evolution'}
        $user=Invoke-RestMethod -UseBasicParsing -TimeoutSec 10 -Uri 'https://api.github.com/user' -Headers $h
        if ($user.login -ne 'ccucle') {throw 'owner'}
        $repo=Invoke-RestMethod -UseBasicParsing -TimeoutSec 10 -Uri 'https://api.github.com/repos/ccucle/frame7-nav' -Headers $h
        if (!$repo.permissions.push) {throw 'write'}
        $cred | Export-Clixml -LiteralPath $credentialFile
        [IO.File]::WriteAllText($familyLink,'1')
        if ($state.base) {Set-Cache $state.base.rules}
        $state.auth=$cred;Update-Controls;$Status.Text='이 PC에서 진화 규칙을 편집할 수 있습니다.'
    } catch {$Status.Text='관리자 연결 실패 · 계정, 토큰 권한, 네트워크를 확인해 주세요.'}
})
$Review.Add_Click({
    if (!$state.base -or !$state.auth) {return}
    if (!(Input-Count $First.Text) -or !(Input-Count $Second.Text)) {$Status.Text='기본값은 1~999 사이의 정수여야 합니다.';return}
    $b=$state.base.rules;$d=$state.draft
    $diff=@(Get-Changes $b $d $allRoutes)
    $summary=@()
    if ($d.first -ne $b.first) {$summary+="첫 번째 진화 기본값   $($b.first) → $($d.first)개"}
    if ($d.second -ne $b.second) {$summary+="두 번째 진화 기본값   $($b.second) → $($d.second)개"}
    if (!$diff.Count -and !$summary.Count) {$Status.Text='변경된 규칙이 없습니다.';return}
    $summary+="변경 경로 $($diff.Count)개"
    foreach ($c in $diff) {
        $kind=if ($c.custom) {'개별 지정'}else{'기본값'}
        $summary+="$($c.route.parentName) → $($c.route.name)   $($c.old) → $($c.new)개 · $kind"
    }
    $preview=[Windows.Markup.XamlReader]::Parse('<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Title="변경 확인" Width="420" Height="420" Background="#F7F3E5" WindowStartupLocation="CenterOwner"><DockPanel Margin="12"><StackPanel Orientation="Horizontal" DockPanel.Dock="Bottom" HorizontalAlignment="Right" Margin="0,8"><Button Content="돌아가기" IsCancel="True" IsDefault="True" Padding="12,5"/><Button Name="Apply" Content="두 PC에 적용" Padding="12,5" Background="#F6C471"/></StackPanel><ListBox Name="Summary"/></DockPanel></Window>')
    $preview.Owner=$window;$preview.FindName('Summary').ItemsSource=$summary
    $preview.FindName('Apply').Add_Click({$preview.DialogResult=$true})
    if ($preview.ShowDialog() -ne $true) {return}
    try {$saved=Publish-Rules $state.base $d $state.auth;$state.base=$saved;Show-Draft $saved.rules;$Status.Text="공유 저장 완료 · 규칙 $($saved.rules.revision)"}
    catch {$Status.Text=$_.Exception.Message}
})
if (Test-Path -LiteralPath $credentialFile) {try {$state.auth=Import-Clixml -LiteralPath $credentialFile} catch {}}
if ($githubCli -and (Test-Path -LiteralPath $cliFlag)) {$state.auth='GitHubCLI'}
$window.Add_ContentRendered({Load-Editor})
[void]$window.ShowDialog()

