-- avatar-unlocks/v1 1.7.0
local M = { api = 1, version = "1.7.0", catalog = {} }
-- @pack-gallery

local function key(value)
    return type(value) == "string" and #value <= 48 and value:match("^[a-z0-9][a-z0-9_-]*$") ~= nil
end

local function exists(path)
    local f = io.open(path,"rb")
    if f then f:close(); return true end
    return false
end

function M.imageFile(cacheDir,name,hex,bundled)
    local path=cacheDir..name.."-"..M.version..".png"
    if exists(path) then return path end
    local temp=path.."."..tostring({}):gsub("[^a-zA-Z0-9]","")..".tmp"
    local file=io.open(temp,"wb")
    if file then
        local bytes=hex:gsub("%x%x",function(pair) return string.char(tonumber(pair,16)) end)
        local written=file:write(bytes)
        local closed=file:close()
        if written and closed and os.rename(temp,path) then return path end
        os.remove(temp)
        if exists(path) then return path end
    end
    return bundled
end

-- Per-avatar signed rules take precedence over bundled copies from older skins.
function M.catalogFor(avatar,localCatalog)
    local rules=M.avatarRewards[avatar] or {}
    local result,signed={},{}
    for _,item in ipairs(rules) do
        result[#result+1]=item
        signed[item.id]=item.kind
    end
    for _,item in ipairs(localCatalog) do
        if not signed[item.id] then result[#result+1]=item
        else assert(signed[item.id]==item.kind,"reward kind changed") end
    end
    return result
end

function M.connect(dataPath, avatar, profile, catalog)
    assert(key(avatar) and key(profile), "invalid avatar or profile")
    local prefix = dataPath .. "unlock~" .. avatar .. "~" .. profile .. "~"
    local pending = prefix .. tostring({}):gsub("[^a-zA-Z0-9]", "") .. "-" .. os.time() .. ".tmp"
    local index, ordered = {}, {}
    local function register(item)
        assert(key(item.id) and key(item.kind) and type(item.level)=="number" and item.level >= 1
            and item.level==math.floor(item.level) and not index[item.id], "invalid reward catalog")
        index[item.id]=item
        if item.kind~="pokemon" or not M.evolutions[item.id] then ordered[#ordered+1]=item end
    end
    for _,item in ipairs(M.catalog) do register(item) end
    for _,item in ipairs(M.catalogFor(avatar,catalog)) do register(item) end
    table.sort(ordered,function(a,b) if a.level==b.level then return a.id<b.id end return a.level<b.level end)
    local session = {}
    M.attachWallet(session,prefix,pending..".wallet")
    local function kindOf(id)
        return (index[id] and index[id].kind) or (M.evolutions[id] and "pokemon")
    end
    function session:owns(id)
        return session.wallet.forms[id] == true or (index[id] ~= nil or M.evolutions[id] ~= nil) and exists(prefix .. id .. ".owned")
    end
    function session:sync(level)
        assert(type(level)=="number" and level>=1 and level==math.floor(level),"invalid level")
        local added = {}
        for _,item in ipairs(ordered) do
            if item.level>level then break end
            local path = prefix .. item.id .. ".owned"
            if not exists(path) then
                local file = assert(io.open(pending,"wb"))
                local written = file:write(item.id,"\n")
                local closed = file:close()
                assert(written and closed,"reward save failed")
                -- On Windows rename creates the receipt only if no other instance won.
                if os.rename(pending,path) then added[#added+1]=item.id
                else os.remove(pending); assert(exists(path),"reward commit failed") end
            end
        end
        return added
    end
    function session:selected(kind)
        assert(key(kind),"invalid reward kind")
        local file=io.open(prefix..kind..".selection","rb")
        if not file then return nil end
        local last
        for line in file:lines() do
            local id=line:match("^=([a-z0-9_-]*)!$")
            if id then last=id end
        end
        file:close()
        if kindOf(last)==kind and self:owns(last) then return last end
    end
    function session:select(kind,id)
        assert(key(kind) and (id==nil or (kindOf(id)==kind and self:owns(id))),"reward unavailable")
        if self:selected(kind)==id then return end
        local file=assert(io.open(prefix..kind..".selection","ab"))
        local written=file:write("\n="..(id or "").."!\n")
        local closed=file:close()
        assert(written and closed,"selection save failed")
    end
    return session
end
-- Older kits already load verified engines as Lua modules. Switch only the gallery
-- measure to the signed shared file. The host's skin and update service stay independent.
if SKIN and SELF then
    if SKIN:GetMeter("GallerySearchFrame") and SELF:GetName()=="AvatarUnlocks" then
        local dir=os.getenv("LOCALAPPDATA").."\\FormdayAvatar\\Unlocks\\v1\\"
        local pointer=io.open(dir.."active.txt","rb")
        if pointer then
            local active=pointer:read(32);pointer:close()
            if active==M.version then
                SKIN:Bang("!SetOption",SELF:GetName(),"ScriptFile",dir..active..".lua")
            end
        end
    end
    return M
end

-- @pack-runtime
return M
