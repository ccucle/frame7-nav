$marker = Join-Path $env:TEMP ("FormdaySearch-" + $token + ".txt")
if (-not [IO.File]::Exists($marker)) { return }
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$form = New-Object Windows.Forms.Form
$form.FormBorderStyle = 'None'
$form.StartPosition = 'Manual'
$form.ShowInTaskbar = $false
$form.TopMost = $true
$inputBox = New-Object Windows.Forms.TextBox
$inputBox.Font = New-Object Drawing.Font('Malgun Gothic', 10)
$inputBox.BorderStyle = 'None'
$inputBox.ForeColor = [Drawing.Color]::FromArgb(36,53,49)
$inputBox.MaxLength = 48
$form.Controls.Add($inputBox)
# Keep the clear hit target in the same native window as the active caret.
$clearButton = New-Object Windows.Forms.Label
$clearButton.Text = [char]0x00D7
$clearButton.Font = $inputBox.Font
$clearButton.TextAlign = [Drawing.ContentAlignment]::MiddleCenter
$clearButton.AccessibleName = 'Clear search'
$clearButton.BackColor = $inputBox.BackColor
$clearButton.ForeColor = $inputBox.ForeColor
$clearButton.Cursor = [Windows.Forms.Cursors]::Hand
$clearButton.TabStop = $false
$form.BackColor = $inputBox.BackColor
$form.Controls.Add($clearButton)
$context = New-Object Windows.Forms.ApplicationContext
$timer = New-Object Windows.Forms.Timer
$timer.Interval = 60
$state = @{ Epoch = 0; ClearGeneration = 0; Dirty = $true; StartText = '' }
if ($seed) {
    $bytes = for ($i=0; $i -lt $seed.Length; $i+=2) { [Convert]::ToByte($seed.Substring($i,2),16) }
    $inputBox.Text = [Text.Encoding]::UTF8.GetString([byte[]]$bytes)
}

function Publish-Search {
    if (-not $state.Dirty) { return }
    $hex = [BitConverter]::ToString([Text.Encoding]::UTF8.GetBytes($inputBox.Text)).Replace('-','')
    $bytes = [Text.Encoding]::ASCII.GetBytes(('QUERY:{0}:{1}|' -f $state.Epoch,$hex))
    try {
        $stream = [IO.File]::Open($marker,'Open','Write','Delete')
        try {
            $stream.Write($bytes,0,$bytes.Length)
            $stream.SetLength($bytes.Length)
        } finally { $stream.Dispose() }
        $state.Dirty = $false
    } catch [IO.IOException] { }
}
function Read-Request {
    try { $record = [IO.File]::ReadAllText($marker + '.focus') } catch [IO.IOException] { return }
    if ($record -notmatch '^(\d+) (\d+) (FOCUS|HIDE) (-?\d+) (-?\d+) (\d+) (\d+) (\d+)\|$') { return }
    $epoch = [long]$Matches[1]
    if ($epoch -le $state.Epoch) { return }
    $generation = [long]$Matches[2]
    $action = $Matches[3]
    $location = New-Object Drawing.Point([int]$Matches[4],[int]$Matches[5])
    $width = [int]$Matches[6]
    $clearX = [int]$Matches[7]
    $clearWidth = [int]$Matches[8]
    $state.Epoch = $epoch
    $state.Dirty = $true
    if ($generation -gt $state.ClearGeneration) {
        $state.ClearGeneration = $generation
        $state.StartText = ''
        $inputBox.Clear()
    }
    if ($action -eq 'HIDE') { $form.Hide(); Publish-Search; return }
    $form.Location = $location
    $inputBox.Width = [Math]::Max(10,$width)
    $clearButton.SetBounds($clearX,0,$clearWidth,$inputBox.Height)
    $clearButton.Visible = $inputBox.TextLength -gt 0
    $form.ClientSize = New-Object Drawing.Size(($clearX+$clearWidth),$inputBox.Height)
    $state.StartText = $inputBox.Text
    if (-not $form.Visible) { $form.Show() }
    $form.Activate()
    [void]$inputBox.Focus()
    $inputBox.SelectAll()
    Publish-Search
}
$inputBox.Add_TextChanged({
    $clearButton.Visible = $inputBox.TextLength -gt 0
    $state.Dirty = $true
    Publish-Search
})
$clearButton.Add_Click({
    $state.StartText = ''
    $inputBox.Clear()
    [void]$inputBox.Focus()
})
$inputBox.Add_KeyDown({
    param($sender,$key)
    if ($key.KeyCode -eq 'Escape') { $inputBox.Text=$state.StartText }
    if ($key.KeyCode -in @([Windows.Forms.Keys]::Enter,[Windows.Forms.Keys]::Escape)) {
        $key.SuppressKeyPress=$true
        Publish-Search
        $form.Hide()
    }
})
$form.Add_Deactivate({ if ($form.Visible) { Publish-Search; $form.Hide() } })
$timer.Add_Tick({
    if (-not [IO.File]::Exists($marker)) { $context.ExitThread(); return }
    Read-Request
    Publish-Search
})
try {
    Read-Request
    $timer.Start()
    [Windows.Forms.Application]::Run($context)
} finally {
    $timer.Dispose()
    $form.Dispose()
    $context.Dispose()
    foreach ($file in @($marker,($marker + '.focus'))) { try { [IO.File]::Delete($file) } catch [IO.IOException] { } }
    Write-Output ('CLOSED ' + $token)
}
