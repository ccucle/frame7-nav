-- Single roster policy; one existing Rainmeter process and one shared atlas.
local P={}
local root=SKIN:GetVariable("CURRENTPATH").."FormdayPokemon\\"
local prefix=SKIN:GetVariable("CURRENTCONFIG").."\\FormdayPokemon\\Slot"
local slots,atlas={},nil
local keys,generation={},0
local function write(path,body)
 local f=io.open(path,"wb"); if not f then return false end
 local ok=f:write(body); return f:close() and ok
end
local childScript=[===[-- Lightweight 10 Hz, bounded desktop movement.
local values,atlas,x,y,lastX,lastY,dx,dy,left,pause,distance,lastCrop,dir
local token,hovered,settle,grabGrace=nil,false,0,0
local privatePath
local menuOpen=false
local menuW,menuH=120,60
local dirs={{-1,0},{1,0},{0,1},{0,-1},{1,1},{-1,1},{1,-1},{-1,-1}}
local function var(n) return tonumber(SKIN:ReplaceVariables("#"..n.."#")) or 0 end
local function bounds()
 local l,t=var("WORKAREAX"),var("WORKAREAY")
 return l,t,math.max(l,l+var("WORKAREAWIDTH")-values[3]),math.max(t,t+var("WORKAREAHEIGHT")-values[4])
end
local function move(l,t,r,b)
 x,y=math.max(l,math.min(x,r)),math.max(t,math.min(y,b))
 local px,py=math.floor(x+0.5),math.floor(y+0.5)
 if px~=lastX or py~=lastY then SKIN:Bang("!Move",px,py);lastX,lastY=px,py end
end
local function paint(walking)
 local row,bx,by,w,h,d,g,strip,cycle=unpack(values,5,13)
 local n=walking and distance%cycle or 0
 local cx,cy
 if strip>=0 then
  local f=0
  while values[14+f] and n>=values[14+f] do f=f+1 end
  cx,cy=f*w*d,strip+(dir>0 and h*d or 0)
 else
  local f=math.floor(n/4)
  cx=math.floor(row/8)*128*g+(f*32+bx)*d
  cy=(row%8)*64*g+((dir>0 and 32 or 0)+by)*d
 end
 local crop=table.concat({cx,cy,w*d,h*d},",")
 if crop~=lastCrop then
  SKIN:Bang("!SetOption","Sprite","ImageCrop",crop); SKIN:Bang("!UpdateMeter","Sprite");lastCrop=crop
 end
end
function Hover(active)
 hovered=active==1
 if hovered then grabGrace=8 else settle=8 end
end
function RequestReturn()
 if not token then return end
 local f=io.open(privatePath.."return."..token..".txt","wb");if not f then return end
 f:write("return\n");f:close()
end
local function position(name,px,py)
 SKIN:Bang("!SetOption",name,"X",px)
 SKIN:Bang("!SetOption",name,"Y",py)
end
function CloseChoice()
 if not menuOpen then return end
 menuOpen=false
 SKIN:Bang("!HideMeterGroup","PokemonChoice")
 position("Sprite",0,0)
 SKIN:Bang("!UpdateMeter","Sprite")
 SKIN:Bang("!Redraw")
 SKIN:Bang("!Draggable",1)
 lastX,lastY=nil,nil
 move(bounds());settle=10
end
function ConfirmReturn()
 if not menuOpen then return end
 CloseChoice();RequestReturn()
end
function OpenChoice(mx,my)
 if not values or not token then return end
 if menuOpen then CloseChoice();return end
 local l,t,r,b=bounds()
 x,y=var("CURRENTCONFIGX"),var("CURRENTCONFIGY")
 local w,h=values[3],values[4]
 local right,bottom=r+w,b+h
 mx=tonumber(mx) or w/2;my=tonumber(my) or h/2
 local ax,ay=x+mx,y+my
 local px=math.max(x+w+2,ax+4)
 if px+menuW>right then px=math.min(x-menuW-2,ax-menuW-4) end
 px=math.max(l,math.min(px,math.max(l,right-menuW)))
 local py=math.max(t,math.min(ay+2,math.max(t,bottom-menuH)))
 local nx,ny=math.min(x,px),math.min(y,py)
 menuOpen=true
 SKIN:Bang("!Draggable",0)
 position("Sprite",x-nx,y-ny)
 position("ChoicePanel",px-nx,py-ny)
 position("ChoiceReturn",px-nx+4,py-ny+4)
 position("ChoiceClose",px-nx+4,py-ny+31)
 SKIN:Bang("!ShowMeterGroup","PokemonChoice")
 SKIN:Bang("!Move",nx,ny)
 SKIN:Bang("!UpdateMeter","Sprite")
 SKIN:Bang("!UpdateMeterGroup","PokemonChoice")
 SKIN:Bang("!Redraw")
end
function Initialize()
 privatePath=SKIN:GetVariable("CURRENTPATH")
 local f=io.open(privatePath.."state.txt","rb");if not f then return end
 local line=f:read("*l");atlas=f:read("*l");local key=f:read("*l");f:close()
 if key and key:match("^[0-9][0-9%-]+$") then token=key end
 if not line or not atlas or not atlas:match("unlock%-walk%-%d+%.%d+%.%d+%.png$") then return end
 values={};for n in line:gmatch("[^,]+") do local v=tonumber(n);if not v then values=nil;return end;values[#values+1]=v end
 if #values<13 or values[3]<1 or values[4]<1 or values[13]<1 then values=nil;return end
 math.randomseed(os.time()+values[5]*79+values[2])
 x,y,dx,dy,left,pause,distance,dir=values[1],values[2],0,0,0,8+2*(values[5]%11),0,1
 SKIN:Bang("!SetOption","Sprite","ImageName",atlas)
 SKIN:Bang("!SetOption","Sprite","W",values[3]);SKIN:Bang("!SetOption","Sprite","H",values[4])
 local sx,sy=var("VSCREENAREAX"),var("VSCREENAREAY")
 SKIN:Bang("!SetWindowPosition",(x-sx).."@0",(y-sy).."@0","0","0")
 move(bounds());paint(false)
end
function Update()
 if not values or menuOpen then return 0 end
 local l,t,r,b=bounds()
 if token then
  local gx,gy=tonumber(SKIN:ReplaceVariables("#CURRENTCONFIGX#")),tonumber(SKIN:ReplaceVariables("#CURRENTCONFIGY#"))
  -- Read window coordinates only while the mouse can be dragging it,
  -- not while Rainmeter may still be reporting the previous commanded position.
  if (hovered or settle>0) and gx and gy and (gx~=lastX or gy~=lastY) then
   x,y,lastX,lastY=gx,gy,gx,gy;settle=8
  end
  if grabGrace>0 or settle>0 then
   if grabGrace>0 then grabGrace=grabGrace-1 end
   if settle>0 then settle=settle-1 end
   paint(false);return 0
  end
 end
 if pause>0 then pause=pause-1;paint(false);return 0 end
 if left<=0 then
  local d=dirs[math.random(#dirs)]
  dx,dy=d[1],d[2];if dx~=0 then dir=dx end
  left=math.random(24,80)
 end
 local speed=1.5 -- 30px/s at 50ms, 1.5x Buddy
 if dx~=0 and dy~=0 then speed=speed/math.sqrt(2) end
 local ox,oy=x,y;x,y=x+dx*speed,y+dy*speed
 move(l,t,r,b)
 distance=distance+math.sqrt((x-ox)^2+(y-oy)^2)
 left=left-1
 if left<=0 or (x==ox and y==oy) then left=0;pause=math.random(10,32) end
 paint(left>0)
 return 0
end
]===]
local childSkin=("fffe5b005200610069006e006d0065007400650072005d000a005500700064006100740065003d00350030000a00440079006e0061006d0069006300570069006e0064006f007700530069007a0065003d0031000a004f006e00520065006600720065007300680041006300740069006f006e003d005b0021005a0050006f00730020002d0032005d005b00210043006c00690063006b005400680072006f00750067006800200030005d005b00210044007200610067006700610062006c006500200031005d005b0021004b006500650070004f006e00530063007200650065006e00200031005d005b00210053006e006100700045006400670065007300200030005d000a005b004d006f00740069006f006e005d000a004d006500610073007500720065003d005300630072006900700074000a00530063007200690070007400460069006c0065003d002300430055005200520045004e005400500041005400480023002e002e005c0072006f0061006d002e006c00750061000a005b005300700072006900740065005d000a004d0065007400650072003d0049006d006100670065000a00440079006e0061006d00690063005600610072006900610062006c00650073003d0031000a004d006f0075007300650041006300740069006f006e0043007500720073006f0072003d0030000a004d006f007500730065004f0076006500720041006300740069006f006e003d005b00210043006f006d006d0061006e0064004d0065006100730075007200650020004d006f00740069006f006e002000220048006f0076006500720028003100290022005d000a004d006f007500730065004c00650061007600650041006300740069006f006e003d005b00210043006f006d006d0061006e0064004d0065006100730075007200650020004d006f00740069006f006e002000220048006f0076006500720028003000290022005d000a00520069006700680074004d006f007500730065005500700041006300740069006f006e003d005b00210043006f006d006d0061006e0064004d0065006100730075007200650020004d006f00740069006f006e00200022004f00700065006e00430068006f00690063006500280024004d006f00750073006500580024002c0024004d006f0075007300650059002400290022005d000a004c006500660074004d006f007500730065005500700041006300740069006f006e003d005b00210043006f006d006d0061006e0064004d0065006100730075007200650020004d006f00740069006f006e002000220043006c006f0073006500430068006f006900630065002800290022005d000a000a005b00430068006f00690063006500500061006e0065006c005d000a004d0065007400650072003d00530068006100700065000a00470072006f00750070003d0050006f006b0065006d006f006e00430068006f006900630065000a00480069006400640065006e003d0031000a00530068006100700065003d00520065006300740061006e0067006c006500200030002c0030002c003100320030002c00360030002c00370020007c002000460069006c006c00200043006f006c006f00720020003200340039002c003200340039002c003200340039002c0032003500350020007c0020005300740072006f006b006500200043006f006c006f00720020003100350034002c003100350034002c003100350034002c0032003500350020007c0020005300740072006f006b00650057006900640074006800200031000a000a005b00430068006f00690063006500520065007400750072006e005d000a004d0065007400650072003d0053007400720069006e0067000a00470072006f00750070003d0050006f006b0065006d006f006e00430068006f006900630065000a00480069006400640065006e003d0031000a0057003d003100310032000a0048003d00320035000a00500061006400640069006e0067003d0038002c0034002c0030002c0030000a0046006f006e00740046006100630065003d004d0061006c00670075006e00200047006f0074006800690063000a0046006f006e007400530069007a0065003d00310030000a0046006f006e00740043006f006c006f0072003d00330030002c00330030002c00330030002c003200350035000a0053006f006c006900640043006f006c006f0072003d003200340039002c003200340039002c003200340039002c003200350035000a0041006e007400690041006c006900610073003d0031000a0054006500780074003d00ccb324b8f4bcb4b030ae0a004d006f007500730065004f0076006500720041006300740069006f006e003d005b0021005300650074004f007000740069006f006e002000430068006f00690063006500520065007400750072006e00200053006f006c006900640043006f006c006f00720020003200320032002c003200330035002c003200350032002c003200350035005d005b0021005500700064006100740065004d0065007400650072002000430068006f00690063006500520065007400750072006e005d005b0021005200650064007200610077005d000a004d006f007500730065004c00650061007600650041006300740069006f006e003d005b0021005300650074004f007000740069006f006e002000430068006f00690063006500520065007400750072006e00200053006f006c006900640043006f006c006f00720020003200340039002c003200340039002c003200340039002c003200350035005d005b0021005500700064006100740065004d0065007400650072002000430068006f00690063006500520065007400750072006e005d005b0021005200650064007200610077005d000a004c006500660074004d006f007500730065005500700041006300740069006f006e003d005b00210043006f006d006d0061006e0064004d0065006100730075007200650020004d006f00740069006f006e002000220043006f006e006600690072006d00520065007400750072006e002800290022005d000a000a005b00430068006f0069006300650043006c006f00730065005d000a004d0065007400650072003d0053007400720069006e0067000a00470072006f00750070003d0050006f006b0065006d006f006e00430068006f006900630065000a00480069006400640065006e003d0031000a0057003d003100310032000a0048003d00320034000a00500061006400640069006e0067003d0038002c0034002c0030002c0030000a0046006f006e00740046006100630065003d004d0061006c00670075006e00200047006f0074006800690063000a0046006f006e007400530069007a0065003d00310030000a0046006f006e00740043006f006c006f0072003d00330030002c00330030002c00330030002c003200350035000a0053006f006c006900640043006f006c006f0072003d003200340039002c003200340039002c003200340039002c003200350035000a0041006e007400690041006c006900610073003d0031000a0054006500780074003d00ebb230ae0a004d006f007500730065004f0076006500720041006300740069006f006e003d005b0021005300650074004f007000740069006f006e002000430068006f0069006300650043006c006f0073006500200053006f006c006900640043006f006c006f00720020003200320032002c003200330035002c003200350032002c003200350035005d005b0021005500700064006100740065004d0065007400650072002000430068006f0069006300650043006c006f00730065005d005b0021005200650064007200610077005d000a004d006f007500730065004c00650061007600650041006300740069006f006e003d005b0021005300650074004f007000740069006f006e002000430068006f0069006300650043006c006f0073006500200053006f006c006900640043006f006c006f00720020003200340039002c003200340039002c003200340039002c003200350035005d005b0021005500700064006100740065004d0065007400650072002000430068006f0069006300650043006c006f00730065005d005b0021005200650064007200610077005d000a004c006500660074004d006f007500730065005500700041006300740069006f006e003d005b00210043006f006d006d0061006e0064004d0065006100730075007200650020004d006f00740069006f006e002000220043006c006f0073006500430068006f006900630065002800290022005d000a00"):gsub("..",function(pair) return string.char(tonumber(pair,16)) end)
local function changed(path,body)
 local f=io.open(path,"rb");if not f then return nil end
 local old=f:read("*a");f:close()
 if old==body then return true end
 if write(path,body) then return true end
 write(path,old)
 return false
end
local function get(name,default) return tonumber(SKIN:GetVariable(name)) or default end
function P.select(ids,sizes,cache,resources)
 ids=ids or {}
 if #ids>0 and not atlas then 
  atlas=M.imageFile(cache,"unlock-walk",M.walkAtlas,resources.."unlock-walk.png")
 end
 local policy=sizes.roam or {}
 local desired,assigned,wanted={},{},{}
 for _,id in ipairs(ids) do wanted[id]=true end
 for n=1,6 do
  local id=slots[n]
  if id and wanted[id] then desired[n]=id;assigned[id]=true end
 end
 for _,id in ipairs(ids) do
  if not assigned[id] then
   for n=1,6 do if not desired[n] then desired[n]=id;break end end
  end
 end
 for n=1,6 do
  local id=desired[n]
  if id~=slots[n] then
   local cfg=prefix..n
   local dir=root.."Slot"..n.."\\"
   if id then
    local row=M.walkRows[id]
    local box=row and M.walkCrops[row+1]
    if box then
     local tier=sizes.tiers[sizes.species[id] or "medium"]
     local k=tier.scale*box.referenceHeight/box.h
     local w,h=math.max(1,math.floor(box.w*k+0.5)),math.max(1,math.floor(box.h*k+0.5))
     local a=SKIN:GetMeter("Avatar")
     local x=get("CURRENTCONFIGX",300)+(a and a:GetX() or 0)
     local y=get("CURRENTCONFIGY",250)+(a and a:GetY()+a:GetH() or 100)
     local gap=policy.spawnGap or 18
     x=policy.spawnSide=="right" and x+(a and a:GetW() or 84)+gap or x-w-gap
     y=y-h+(n-1)*14
     local fields={math.floor(x+0.5),math.floor(y+0.5),w,h,row,box.x,box.y,box.w,box.h,box.density,M.walkDensity,box.stripY or -1,box.cycle or 16}
     for _,v in ipairs(box.ends or {}) do fields[#fields+1]=v end
     -- A single newline-free, numeric record with the signed engine's atlas path.
     local ready=changed(root.."roam.lua",childScript) and changed(dir.."Pokemon.ini",childSkin)
     generation=generation+1
     local key=string.format("%d-%d-%06d",os.time(),generation,math.random(0,999999))
     if ready and atlas and write(dir.."state.txt",table.concat(fields,",").."\n"..atlas.."\n"..key) then
      keys[n]=key
      SKIN:Bang("!DeactivateConfig",cfg)
      SKIN:Bang("!ActivateConfig",cfg,"Pokemon.ini")
      slots[n]=id
     end
    end
   else
    SKIN:Bang("!DeactivateConfig",cfg)
    slots[n],keys[n]=nil,nil
   end
  end
 end
end
function P.takeReturns()
 local ids={}
 for n=1,6 do
  if keys[n] and slots[n] then
   local path=root.."Slot"..n.."\\return."..keys[n]..".txt"
   local f=io.open(path,"rb")
   if f then
    local line=f:read("*l");f:close()
    if line=="return" and os.remove(path) then ids[#ids+1]=slots[n] end
   end
  end
 end
 return ids
end
function P.close()
 for n=1,6 do SKIN:Bang("!DeactivateConfig",prefix..n);slots[n],keys[n]=nil,nil end
end
return P
