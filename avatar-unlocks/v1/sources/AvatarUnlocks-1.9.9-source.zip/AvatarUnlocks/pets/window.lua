-- @pack-pet-clips
local x,y,lastX,lastY,motion,frame,elapsed,drawn
local previousGoalX,previousGoalY
local walkPoseUntil=0
local hovered,nextJump=false,false
local lease,savePosition,latestLease,lastSave,clock
local function variable(name) return tonumber(SKIN:ReplaceVariables("#"..name.."#")) or 0 end
local function read(path)
    local f=io.open(path,"rb");if not f then return "" end
    local s=f:read("*a");f:close();return s
end
local function move(left,top)
    x,y=left,top
    lastX,lastY=math.floor(x+0.5),math.floor(y+0.5)
    SKIN:Bang("!Move",lastX,lastY)
end
local function limits()
    local l,t=variable("WORKAREAX"),variable("WORKAREAY")
    return l,t,math.max(l,l+variable("WORKAREAWIDTH")-windowWidth),math.max(t,t+variable("WORKAREAHEIGHT")-86)
end
local function paint(name)
    if name~=motion then motion,frame,elapsed=name,1,0 end
    local index=clips[name].start+frame-1
    if drawn~=index then
        drawn=index
        SKIN:Bang("!SetOption","Pet","ImageCrop",(index%12*84)..","..(math.floor(index/12)*86)..",84,86")
        SKIN:Bang("!UpdateMeter","Pet")
        if special=="ink" then
            if name=="ink" then
                local i=frame-1
                SKIN:Bang("!SetOption","Ink","ImageCrop",(i%6*168+60)..","..(math.floor(i/6)*86)..",80,86")
                SKIN:Bang("!ShowMeter","Ink")
                SKIN:Bang("!UpdateMeter","Ink")
            else
                SKIN:Bang("!HideMeter","Ink")
            end
        end
    end
end
function Initialize()
    local folder=SKIN:GetVariable("CURRENTPATH")
    lease=folder.."..\\FormdayKirby.active"
    savePosition=folder..(petId=="kirby" and "position.txt" or ("position-"..petId..".txt"))
    local l,t,r,b=limits()
    local sx,sy=read(savePosition):match("^(-?%d+),(-?%d+)")
    move(math.max(l,math.min(r,tonumber(sx) or math.floor((l+r)/2))),
         math.max(t,math.min(b,tonumber(sy) or math.floor((t+b)/2))))
    clock=os.clock()
    latestLease,lastSave=os.time(),0
    paint("idle")
end
local function acting() return motion==special or motion=="jump" end
function Hover(value)
    hovered=value==1
    if hovered and not acting() then paint("idle") end
end
function Interact()
    -- Rainmeter dispatches LeftMouseUpAction only after a click, not after a drag.
    paint(nextJump and "jump" or special);nextJump=not nextJump
end
local headings={{1,0,"E"},{1,1,"SE"},{0,1,"S"},{-1,1,"SW"},{-1,0,"W"},{-1,-1,"NW"},{0,-1,"N"},{1,-1,"NE"}}
local function follow(sample)
    local target=SKIN:GetVariable("PetGoal") or ""
    local gx,gy=target:match("^(-?%d+),(-?%d+)$")
    if not gx then return end
    local l,t,r,b=limits()
    gx,gy=math.max(l,math.min(r,tonumber(gx))),math.max(t,math.min(b,tonumber(gy)))
    local sx,sy=gx-x,gy-y
    local distance=math.sqrt(sx*sx+sy*sy)
    local wasAtGoal=x==previousGoalX and y==previousGoalY
    if not previousGoalX or distance>340 then
        move(gx,gy)
        walkPoseUntil=0
    elseif distance>0 then
        -- The host walks one pixel per 50 ms. Copy its observed movement,
        -- including batched ticks. If dragged away, walk back at the host pace.
        if wasAtGoal or distance<=1 then
            move(gx,gy)
        else
            move(x+sx/distance,y+sy/distance)
        end
        if not acting() and not hovered then
            local horizontal=math.abs(sx)>distance*0.38 and (sx>0 and 1 or -1) or 0
            local vertical=math.abs(sy)>distance*0.38 and (sy>0 and 1 or -1) or 0
            for _,d in ipairs(headings) do
                if d[1]==horizontal and d[2]==vertical then
                    paint("walk-"..d[3])
                    break
                end
            end
            walkPoseUntil=sample+0.10
        end
    end
    previousGoalX,previousGoalY=gx,gy
    if not acting() and (hovered or sample>=walkPoseUntil) then paint("idle") end
end
function Update()
    local now=os.time()
    local sample=os.clock()
    local ms=math.max(0,math.min(200,(sample-clock)*1000))
    clock=sample
    if now~=latestLease then
        latestLease=now
        -- Temporary host stalls, file writes and upgrades are not a return command.
        if read(lease):match("^off%s*$") then
            SKIN:Bang("!DeactivateConfig");return
        end
        if now-lastSave>=4 then
            local f=io.open(savePosition,"wb")
            if f then f:write(lastX,",",lastY);f:close() end
            lastSave=now
        end
    end
    local ax,ay=variable("CURRENTCONFIGX"),variable("CURRENTCONFIGY")
    if math.abs(ax-lastX)>3 or math.abs(ay-lastY)>3 then
        x,y,lastX,lastY=ax,ay,ax,ay
    end
    follow(sample)
    elapsed=elapsed+ms
    local durations=clips[motion].ms
    while elapsed>=durations[frame] do
        elapsed=elapsed-durations[frame]
        frame=frame+1
        if frame>#durations then
            frame=1
            if acting() then paint("idle");break end
        end
    end
    paint(motion)
    return drawn
end
