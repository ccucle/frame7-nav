[UnlockStatus]
Measure=String
String=#UnlockUpdateCode#
DynamicVariables=1
Substitute="0":"최신 버전이에요","1":"새 버전 확인 중…","2":"새 버전이 있어요","3":"확인하지 못했어요","4":"설치 중…"

[UnlockPanelCard]
Meter=Shape
Group=UnlockPanel
Hidden=1
DynamicVariables=1
X=0
Y=0
Shape=Rectangle 0,0,177,118,6 | Fill Color 32,39,56,252 | StrokeWidth 1 | Stroke Color 114,132,154

[UnlockPanelText]
FontFace=Galmuri9 Regular
FontColor=239,241,246
FontSize=9
AntiAlias=0
DynamicVariables=1
Hidden=1
Group=UnlockPanel
X=10

[UnlockPanelTitle]
Meter=String
MeterStyle=UnlockPanelText
Y=8
FontSize=11
FontColor=161,214,234
Text=해금 업데이트

[UnlockPanelClose]
Meter=String
MeterStyle=UnlockPanelText
X=168
Y=10
StringAlign=Right
Text=도감
LeftMouseUpAction=[!CommandMeasure AvatarUnlocks OpenPanel()]

[UnlockPanelCurrent]
Meter=String
MeterStyle=UnlockPanelText
Y=34
Text=설치 버전  #UnlockSystemVersion#

[UnlockPanelLatest]
Meter=String
MeterStyle=UnlockPanelText
Y=52
Text=배포 버전  #UnlockLatestVersion#

[UnlockPanelState]
Meter=String
MeterStyle=UnlockPanelText
Y=72
MeasureName=UnlockStatus
Text=%1

[UnlockInstallButton]
Meter=String
MeterStyle=UnlockPanelText
Group=UnlockInstall
Y=92
FontColor=236,252,248
SolidColor=65,99,98
Padding=5,1,5,1
Text=업데이트 하기
LeftMouseUpAction=[!CommandMeasure AvatarUnlocks Install()]

[UnlockRetryButton]
Meter=String
MeterStyle=UnlockPanelText
Group=UnlockRetry
Y=92
FontColor=161,214,234
Text=다시 확인
LeftMouseUpAction=[!CommandMeasure AvatarUnlocks Check()]
