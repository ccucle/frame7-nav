function Update-AvatarUnlocks {
    param([string]$Mode,[string]$Root,[string]$Base,[string]$Key,[string]$Bundled);
    $ErrorActionPreference='Stop';
    function Get-UnlockDigest([string]$Path) {
        $stream=[IO.File]::OpenRead($Path); $sha=[Security.Cryptography.SHA256]::Create();
        try {return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','').ToLowerInvariant()} finally {$stream.Dispose();$sha.Dispose()};
    };
    if ($Mode -notin 'Check','Install') {throw 'Unknown operation'};
    $lock=$null; $temp=$null; $pointerTemp=$null;
    try {
        [void][IO.Directory]::CreateDirectory($Root);
        $client=New-Object Net.WebClient;
        try {$feed=$client.DownloadString($Base+'/feed.txt?t='+[DateTime]::UtcNow.Ticks)} finally {$client.Dispose()};
        $lines=$feed.TrimEnd().Split([char]10);
        if ($feed.Length -gt 2048 -or $lines.Count -ne 2) {throw 'Invalid manifest'};
        $message=$lines[0].TrimEnd([char]13);
        if ($message -cnotmatch '^avatar-unlocks/v1\|([0-9]{1,4}\.[0-9]{1,4}\.[0-9]{1,4})\|([a-f0-9]{64})$') {throw 'Invalid channel or format'};
        $release=$Matches[1]; $digest=$Matches[2];
        $rsa=New-Object Security.Cryptography.RSACryptoServiceProvider;
        try {$rsa.PersistKeyInCsp=$false; $rsa.FromXmlString($Key); if (!$rsa.VerifyData([Text.Encoding]::ASCII.GetBytes($message),'SHA256',[Convert]::FromBase64String($lines[1]))) {throw 'Invalid signature'}} finally {$rsa.Dispose()};
        if ($Mode -eq 'Install') {$lock=[IO.File]::Open((Join-Path $Root 'update.lock'),'OpenOrCreate','ReadWrite','None')};
        $pointer=Join-Path $Root 'active.txt'; $current=[version]$Bundled;
        if ([IO.File]::Exists($pointer)) {
            $prior=[IO.File]::ReadAllText($pointer).Trim();
            if ($prior -cmatch '^[0-9]{1,4}\.[0-9]{1,4}\.[0-9]{1,4}$' -and [IO.File]::Exists((Join-Path $Root ($prior+'.lua'))) -and [version]$prior -gt $current) {$current=[version]$prior};
        };
        if ([version]$release -lt $current) {return ('CURRENT '+$current)};
        $target=Join-Path $Root ($release+'.lua');
        if ([version]$release -eq $current -and ($release -eq $Bundled -or ([IO.File]::Exists($target) -and (Get-UnlockDigest $target) -eq $digest))) {return ('CURRENT '+$current)};
        if ($Mode -eq 'Check') {return ('AVAILABLE '+$release)};
        $temp=Join-Path $Root ([guid]::NewGuid().ToString('N')+'.tmp');
        $client=New-Object Net.WebClient;
        try {$client.DownloadFile($Base+'/releases/'+$release+'.lua',$temp)} finally {$client.Dispose()};
        if ([IO.FileInfo]::new($temp).Length -gt 1048576 -or (Get-UnlockDigest $temp) -ne $digest) {throw 'Invalid payload'};
        $reader=[IO.File]::OpenText($temp);
        try {$header=$reader.ReadLine()} finally {$reader.Dispose()};
        if ($header -cne ('-- avatar-unlocks/v1 '+$release)) {throw 'Incompatible engine'};
        if ([IO.File]::Exists($target)) {[IO.File]::Replace($temp,$target,[System.Management.Automation.Language.NullString]::Value)} else {[IO.File]::Move($temp,$target)};
        $pointerTemp=Join-Path $Root ([guid]::NewGuid().ToString('N')+'.tmp');
        [IO.File]::WriteAllText($pointerTemp,$release,[Text.Encoding]::ASCII);
        if ([IO.File]::Exists($pointer)) {[IO.File]::Replace($pointerTemp,$pointer,[System.Management.Automation.Language.NullString]::Value)} else {[IO.File]::Move($pointerTemp,$pointer)};
        return ('INSTALLED '+$release);
    } finally {
        if ($lock) {$lock.Dispose()};
        foreach ($path in @($temp,$pointerTemp)) {if ($path -and [IO.File]::Exists($path)) {[IO.File]::Delete($path)}};
    };
};
