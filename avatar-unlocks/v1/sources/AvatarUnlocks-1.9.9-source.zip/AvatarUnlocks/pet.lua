-- The selected pet is a second native Rainmeter config, with its own window and input.
local P={}
local root=SKIN:GetVariable("CURRENTPATH")
local folder=root.."FormdayDesktopPet\\"
local config=SKIN:GetVariable("CURRENTCONFIG").."\\FormdayDesktopPet"
local lease=root.."FormdayKirby.active"
local selected,prepared,nextPulse,nextFolder=nil,false,0,0
local function read(path)
    local f=io.open(path,"rb");if not f then return nil end
    local s=f:read("*a");f:close();return s
end
local function write(path,data)
    local f=io.open(path,"wb");if not f then return false end
    local ok=f:write(data)
    return f:close() and ok
end
local function prepare(now)
    local pet=M.pets[selected]
    -- Keep the registered skin variant so previously installed copies can switch in place.
    local iniPath=folder.."Kirby.ini"
    local prior=read(iniPath)
    local script="motion-"..selected.."-"..M.version..".lua"
    if read(folder..script)~=pet.window and not write(folder..script,pet.window) then
        if now>=nextFolder then
            nextFolder=now+10
            -- Only create this skin's own child directory; all animation runs in Rainmeter.
            local target=folder:sub(1,-2):gsub("'","''")
            local ps=os.getenv("SystemRoot").."\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"
            SKIN:Bang('["'..ps..'" -NoProfile -NonInteractive -WindowStyle Hidden -Command "[void][IO.Directory]::CreateDirectory(\''..target..'\')"]')
        end
        return false
    end
    local image=selected.."-"..M.version..".png"
    if M.imageFile(folder,selected,pet.atlas,"")~=folder..image then return false end
    local ini=M.petIni:gsub("@SCRIPT@",script):gsub("@IMAGE@",image):gsub("@WIDTH@",tostring(pet.width))
    if pet.ink then
        local inkName=selected.."-ink"
        local inkPath=M.imageFile(folder,inkName,pet.ink,"")
        if inkPath=="" then return false end
        ini=ini.."\n[Ink]\nMeter=Image\nX=60\nY=0\nW=80\nH=86\nHidden=1\nImageCrop=60,0,80,86\nImageName=#CURRENTPATH#"..inkName.."-"..M.version..".png\n"
    end
    if prior~=ini and not write(iniPath,ini) then return false end
    prepared=true
    if not prior then
        -- Only the initial installation needs to register the new skin folder.
        SKIN:Bang("!RefreshApp")
    else
        SKIN:Bang("!ActivateConfig",config,"Kirby.ini")
        if prior~=ini then SKIN:Bang("!Refresh",config) end
    end
    return true
end
function P.pulse()
    if not selected then return end
    local now=os.time()
    if now<nextPulse and now>=nextPulse-4 then return end
    nextPulse=now+(prepared and 4 or 1)
    if not write(lease,M.version.."|"..now.."|"..selected.."\n") then return end
    if not prepared then prepare(now) end
end
local px,py,lastGoalAt
function P.active() return selected end
function P.track()
    if not selected or not prepared then return end
    local a=SKIN:GetMeter("Avatar");if not a then return end
    local x=(tonumber(SKIN:GetVariable("CURRENTCONFIGX")) or 0)+a:GetX()-90
    local y=(tonumber(SKIN:GetVariable("CURRENTCONFIGY")) or 0)+a:GetY()+a:GetH()-86
    x,y=math.floor(x+0.5),math.floor(y+0.5)
    local now=os.time()
    -- Resend the goal to a newly loaded or refreshed child even while standing still.
    if x~=px or y~=py or now~=lastGoalAt then
        local target=tostring(x)..","..tostring(y)
        SKIN:Bang("!SetVariable","PetGoal",target,config)
        px,py,lastGoalAt=x,y,now
    end
end

function P.select(id)
    local show=id and M.pets[id] and id or nil
    if show==selected then return end
    selected=show
    if show then
        px,py=nil,nil
        prepared,nextPulse=false,0
        P.pulse()
    else
        write(lease,"off\n")
        if prepared then SKIN:Bang("!DeactivateConfig",config) end
        prepared=false
    end
end
function P.shutdown()
    if selected then write(lease,"off\n") end
end
return P
