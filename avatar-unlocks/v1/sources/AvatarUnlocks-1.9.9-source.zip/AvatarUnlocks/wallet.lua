-- One immutable event grants the item and deducts its cost together.
-- Windows rename publishes a fully closed receipt only if its ordinal is still free.
function M.attachWallet(session,prefix,pending)
    local wallet={xp=0,powder=0,stones={},forms={},sequence=0}
    session.wallet=wallet
    local function nextPath()
        return prefix.."wallet-"..string.format("%09d",wallet.sequence+1)..".txn"
    end
    local function apply(record)
        local xp=tonumber(record:match("^X (%d+)\n$"))
        local crafted=record:match("^C ([a-z]+)\n$")
        local form,stone,cost=record:match("^E ([a-z0-9_-]+) ([a-z]+) (%d+)\n$")
        cost=tonumber(cost)
        if xp and xp>wallet.xp and xp<=900719925474099 then
            wallet.powder=wallet.powder+(xp-wallet.xp)*5
            wallet.xp=xp
        elseif crafted and M.stoneNames[crafted] and wallet.powder>=30 then
            wallet.powder=wallet.powder-30
            wallet.stones[crafted]=(wallet.stones[crafted] or 0)+1
        elseif form and cost and cost>0 and (wallet.stones[stone] or 0)>=cost and not wallet.forms[form] then
            wallet.stones[stone]=wallet.stones[stone]-cost
            wallet.forms[form]=true
        else
            wallet.error="invalid receipt"
            return false
        end
        wallet.sequence=wallet.sequence+1
        return true
    end
    function session:readWallet()
        while not wallet.error do
            local file=io.open(nextPath(),"rb")
            if not file then return true end
            local record=file:read(128)
            local extra=file:read(1)
            file:close()
            if not record or extra or not apply(record) then wallet.error="invalid receipt";break end
        end
        return false
    end
    local function transact(makeRecord)
        for attempt=1,8 do
            if not session:readWallet() then return false end
            local record=makeRecord()
            if not record then return false end
            local path=nextPath()
            local file=io.open(pending,"wb")
            if not file then return false end
            local written=file:write(record)
            local closed=file:close()
            if written and closed and os.rename(pending,path) then return apply(record) end
            os.remove(pending)
            local winner=io.open(path,"rb")
            if not winner then return false end
            winner:close()
        end
        return false
    end
    function session:earn(total)
        if not total or total<0 or total~=math.floor(total) or total>900719925474099 then return false end
        return transact(function()
            if total>wallet.xp then return string.format("X %.0f\n",total) end
        end)
    end
    function session:craft(stone)
        return transact(function()
            if M.stoneNames[stone] and wallet.powder>=30 then return "C "..stone.."\n" end
        end)
    end
    function session:evolve(target)
        return transact(function()
            local rule=M.evolutions[target]
            if rule and self:owns(rule.parent) and not self:owns(target) and (wallet.stones[rule.stone] or 0)>=rule.cost then
                return string.format("E %s %s %d\n",target,rule.stone,rule.cost)
            end
        end)
    end
    session:readWallet()
end
