-- The first gallery image and the live-search timer are free while the book is
-- closed. Reuse them so installed skins can gain a follower through the catalog.
local F={}
local meter,clock="GalleryArt1","GallerySearchWatch"
local id,tier,row,box,scale,width,height,atlas,anchorName
local paused,armed=false,false
local lastX,distance,direction,ground=nil,0,1,nil
local crop,px,py,rearOffsets
local panelHome,panelShift=nil,0
-- The currently installed Formday hosts place these controls beside the actor.
-- Leave their original hit boxes and alignment intact when the catalog is open.
local panelMeters=[[CompactCard CompactTitle CompactState DotWorkout RowWorkout CountWorkout
DotCalories RowCalories CountCalories DotProtein RowProtein CountProtein DotBody RowBody CountBody
InfoCard InfoTitle InfoClose ProgressValue Remaining Completed RecordState OpenFolder Unload OpenSite
GameMode ConnectSite ConnectFolder CopySyncFolder UpdateButtonBg UpdateButton UpdateNote InfoGear PowderIcon PowderBalance OpenWorkshopButton
SettingsCard SettingsTitle SettingsBack SettingsHint SettingsStartupRow SettingsStartupName SettingsStartupValue
SettingsWalkRow SettingsWalkName SettingsWalkValue SettingsBadgeRow SettingsBadgeName SettingsBadgeValue]]

panelMeters=panelMeters.." CraftCard CraftTitle CraftBack CraftPowderIcon CraftPowder CraftCost CraftHeld"
for i=1,#M.stoneOrder do
    panelMeters=panelMeters.." CraftIcon"..i.." CraftName"..i.." CraftStock"..i.." CraftButton"..i
end

local function placePanel(rightEdge)
    if not panelHome then
        panelHome={}
        if not SKIN:GetMeter("CompactCard") then return end
        for name in panelMeters:gmatch("%S+") do
            local control=SKIN:GetMeter(name)
            if control then panelHome[name]=tonumber(control:GetOption("X")) or control:GetX() end
        end
    end
    if not panelHome.CompactCard then return end
    local shift=math.max(0,rightEdge-panelHome.CompactCard)
    if shift==panelShift then return end
    for name,home in pairs(panelHome) do
        SKIN:Bang("!SetOption",name,"X",tostring(home+shift))
        SKIN:Bang("!UpdateMeter",name)
    end
    panelShift=shift
end

local front="GalleryArt1"
function F.active() return armed end
local rear,home,actorShift,coverPose
local function option(target,name,value)
    SKIN:Bang("!SetOption",target,name,tostring(value))
end

-- Reserve just enough space inside the left window edge for a complete sprite.
local function placeActor(shift)
    if actorShift==shift then return end
    for name,position in pairs(home) do
        option(name,"X",shift==0 and position.raw or position.x+shift)
        SKIN:Bang("!UpdateMeter",name)
    end
    actorShift=shift
end

local function prepareLayout()
    home={}
    local companions=SKIN:GetVariable("UnlockFollowerAnchorMeters") or "Level UpdateBalloon UpdateSpeech"
    for name in (anchorName.." "..companions):gmatch("%S+") do
        local control=SKIN:GetMeter(name)
        if control then home[name]={x=tonumber(control:GetOption("X")) or control:GetX(),raw=control:GetOption("X",tostring(control:GetX()),false)} end
    end
    actorShift=0
    meter=front
    if tier~="large" then return end
    local back=SKIN:GetVariable("UnlockFollowerBackMeter")
    if not back or back=="" then
        back=SKIN:GetMeter("UnlockFollowerBack") and "UnlockFollowerBack" or "CompactBounds"
    end
    local host=SKIN:GetMeter(back)
    if host and host:GetOption("Meter",""):lower()=="image" and host:GetOption("ImageName","")=="" then
        meter=back
        rear={x=host:GetX(),y=host:GetY(),w=host:GetW(),h=host:GetH(),options={}}
        for _,key in ipairs({"X","Y","W","H","Padding","ImageName","ImageCrop","Hidden"}) do
            rear.options[key]=host:GetOption(key,"",false)
        end
    end
end

-- A custom host without an earlier empty image can reproduce its animated
-- avatar above the follower with the next unused gallery image.
local function updateCover(actor,ax,ay,w,h)
    if tier~="large" or rear then return end
    local m="GalleryArt2"
    if not SKIN:GetMeter(m) then return end
    local image=actor:GetOption("ImageName","")
    local flip=actor:GetOption("ImageFlip","None")
    local frame=actor:GetOption("ImageCrop","")
    local key=table.concat({image,flip,frame,ax,ay,w,h},"|")
    if key==coverPose then return end
    coverPose=key
    for k,v in pairs({ImageName=image,ImageFlip=flip,ImageCrop=frame,X=ax,Y=ay,W=w,H=h,
                      ImageAlpha=255,Greyscale=0,ToolTipText="",LeftMouseUpAction=""}) do option(m,k,v) end
    SKIN:Bang("!ShowMeter",m)
    SKIN:Bang("!UpdateMeter",m)
end

local function set(name,value) SKIN:Bang("!SetOption",meter,name,tostring(value)) end

local function stop()
    if not armed then return end
    armed=false
    if rear then
        for key,value in pairs(rear.options) do option(meter,key,value) end
        SKIN:Bang(rear.options.Hidden=="1" and "!HideMeter" or "!ShowMeter",meter)
        SKIN:Bang("!UpdateMeter",meter)
        rear=nil
    elseif coverPose then
        option("GalleryArt2","ImageFlip","None")
        SKIN:Bang("!HideMeter","GalleryArt2")
        SKIN:Bang("!UpdateMeter","GalleryArt2")
    end
    meter,coverPose=front,nil
    placeActor(0)
    placePanel(0)
    SKIN:Bang("!DisableMeasure",clock)
    SKIN:Bang("!SetOption",clock,"OnUpdateAction","[!CommandMeasure AvatarUnlocks GallerySearchTick()]")
    SKIN:Bang("!HideMeter",meter)
    SKIN:Bang("!UpdateMeter",meter)
    SKIN:Bang("!Redraw")
end

local function start()
    if armed or paused or not row or not SKIN:GetMeter(anchorName) then return end
    armed=true
    lastX,distance,crop,px,py,ground=nil,0,nil,nil,nil,nil
    prepareLayout()
    set("ImageName",atlas)
    set("W",width);set("H",height)
    if not rear then
        set("Greyscale",0);set("ImageAlpha",255)
        set("ToolTipText","");set("LeftMouseUpAction","")
    end
    SKIN:Bang("!SetOption",clock,"OnUpdateAction","[!CommandMeasure AvatarUnlocks FollowerTick()]")
    SKIN:Bang("!EnableMeasure",clock)
    F.tick()
    SKIN:Bang("!ShowMeter",meter)
    SKIN:Bang("!UpdateMeter",meter)
    SKIN:Bang("!Redraw")
end

function F.select(nextId,nextTier,nextScale,anchor,cacheDir,resources,offsets)
    if nextId~=id or nextTier~=tier or nextScale~=scale or anchor~=anchorName then
        stop()
        id,tier,scale,anchorName,rearOffsets=nextId,nextTier,nextScale,anchor,offsets
        row=id and M.walkRows[id]
        if row then
            box=M.walkCrops[row+1]
            local pixelScale=scale*box.referenceHeight/box.h
            width=math.max(1,math.floor(box.w*pixelScale+0.5))
            height=math.max(1,math.floor(box.h*pixelScale+0.5))
            if not atlas then atlas=M.imageFile(cacheDir,"unlock-walk",M.walkAtlas,resources.."unlock-walk.png") end
        end
    end
    start()
end

function F.panel(open)
    paused=open
    if open then stop() else start() end
end

function F.tick()
    if not armed then return end
    local actor=SKIN:GetMeter(anchorName)
    if not actor then return end
    local ax,ay,w,h=actor:GetX(),actor:GetY(),actor:GetW(),actor:GetH()
    local inset=math.floor(w*0.42+0.5)
    local origin=home[anchorName].x
    local shift=tier=="small" and math.max(0,width+2-origin-inset) or 0
    placeActor(shift)
    ax=origin+shift
    local x=tonumber(SKIN:GetVariable("CURRENTCONFIGX")) or 0
    local dx=lastX and (x-lastX) or 0
    lastX=x
    if dx~=0 then direction=dx>0 and 1 or -1 end
    if dx==0 then distance=0 else distance=(distance+math.abs(dx))%(box.cycle or 16) end
    local density=box.density
    local cx,cy
    if box.ends then
        local frame=0
        while distance>=box.ends[frame+1] do frame=frame+1 end
        cx=frame*box.w*density
        cy=box.stripY+(direction>0 and box.h*density or 0)
    else
        local frame=math.floor(distance/4)
        cx=math.floor(row/8)*128*M.walkDensity+(frame*32+box.x)*density
        cy=(row%8)*64*M.walkDensity+((direction>0 and 32 or 0)+box.y)*density
    end
    local nextCrop=string.format("%d,%d,%d,%d",cx,cy,box.w*density,box.h*density)
    local footInset=tonumber(SKIN:GetVariable("UnlockFollowerFootInset"))
        or (SKIN:GetVariable("UnlockAvatar")=="formday-buddy" and 3 or 0)
    if not ground or SKIN:GetVariable("Pose")~="jump" then ground=ay+h-footInset end
    local nextX,nextY,panelRight
    if tier=="small" then
        nextX,nextY=ax+inset-width,ground-height+math.floor(h*0.065+0.5)
    elseif tier=="large" then
        local offset=0.49
        if rearOffsets then
            offset=direction<0 and rearOffsets.left or rearOffsets.right
            -- Keep the adjacent controls still when the follower turns its head.
            panelRight=ax+math.floor(w*math.max(rearOffsets.left,rearOffsets.right)+0.5)+width
        end
        nextX,nextY=ax+math.floor(w*offset+0.5),ground-height-math.floor(h*0.08+0.5)
    else
        nextX,nextY=ax+math.floor(w*0.73+0.5),ground-height
    end
    nextX,nextY=math.max(0,nextX),math.max(0,nextY)
    placePanel(math.max(ax+w,panelRight or nextX+width)+8)
    updateCover(actor,ax,ay,w,h)
    if crop==nextCrop and px==nextX and py==nextY then return end
    if crop~=nextCrop then set("ImageCrop",nextCrop) end
    if rear then
        if px~=nextX or py~=nextY then
            -- Padding keeps the original transparent skin bounds and hit origin.
            set("X",0);set("Y",0)
            set("Padding",table.concat({nextX,nextY,math.max(0,rear.x+rear.w-nextX-width),
                                       math.max(0,rear.y+rear.h-nextY-height)},","))
        end
    else
        if px~=nextX then set("X",nextX) end
        if py~=nextY then set("Y",nextY) end
    end
    crop,px,py=nextCrop,nextX,nextY
    SKIN:Bang("!UpdateMeter",meter)
    SKIN:Bang("!Redraw")
end

return F
