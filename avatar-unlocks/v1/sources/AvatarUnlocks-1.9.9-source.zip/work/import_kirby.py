"""Import the approved motion pack into the catalog's indexed desktop atlas."""
import argparse
from io import BytesIO
import json
import struct
import zlib
from pathlib import Path
from zipfile import ZipFile
from PIL import Image, ImageDraw, ImageFilter, ImageOps


def outline_frame(frame, transparent, black):
    # Only the background connected to the outside of this frame can form a
    # contour. Enclosed details and blue suction trails retain their colors.
    alpha = frame.point([0 if i == transparent else 255 for i in range(256)], "L")
    exterior = ImageOps.expand(alpha, border=3, fill=0)
    ImageDraw.floodfill(exterior, (0, 0), 128)
    exterior = exterior.point(lambda value: 255 if value == 128 else 0)
    diamond = [int(abs(x) + abs(y) <= 2) for y in range(-2, 3) for x in range(-2, 3)]
    ring = exterior.filter(ImageFilter.Kernel((5, 5), diamond, scale=1))
    ring = ring.crop((3, 3, frame.width + 3, frame.height + 3))
    palette = frame.getpalette()
    pixels = frame.load()
    for y in range(frame.height):
        for x in range(frame.width):
            index = pixels[x, y]
            if index == transparent or not ring.getpixel((x, y)):
                continue
            r, g, b = palette[index * 3:index * 3 + 3]
            if not (b > r + 18 and g > r + 13):
                pixels[x, y] = black
    return frame

def read_pack(source, catalog):
    directory = catalog / "pets"
    directory.mkdir(exist_ok=True)
    with ZipFile(source) as z:
        data = json.loads(z.read("motions.json"))
        w, h = data["cell"]
        top = 26
        cell_h = h - top
        columns = 12
        frame_count = sum(c["frameCount"] for c in data["clips"].values())
        atlas = Image.new("RGBA", (columns*w, ((frame_count+columns-1)//columns)*cell_h))
        offset = 0
        clips = {}
        for name, clip in data["clips"].items():
            strip = Image.open(BytesIO(z.read(clip["file"]))).convert("RGBA")
            assert strip.size == (w*clip["frameCount"], h)
            assert len(clip["frameMs"]) == clip["frameCount"]
            assert not strip.crop((0, 0, strip.width, top)).getchannel("A").getbbox()
            durations = clip["frameMs"]
            if name.startswith("walk-"):
                assert clip["frameCount"] == 8
                durations = [208, 207] * 4  # Eight frames in the approved 1.66 s cycle.
            clips[name] = {"start": offset, "ms": durations}
            for i in range(clip["frameCount"]):
                frame = strip.crop((i*w, top, (i+1)*w, h))
                atlas.paste(frame, ((offset%columns)*w, (offset//columns)*cell_h))
                offset+=1
        assert offset==123
    # Preserve every silhouette pixel, including the thin air streaks.
    opaque = atlas.getchannel("A")
    colors = atlas.convert("RGB").quantize(colors=127, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
    colors.putpalette(colors.getpalette()[:127*3]+[0,0,0])
    colors.paste(127, (0,0), opaque.point(lambda v: 255 if v==0 else 0))
    palette = colors.getpalette()
    black = next(i for i in range(127) if palette[3*i:3*i+3] == [0, 0, 0])
    for i in range(frame_count):
        x, y = i % columns * w, i // columns * cell_h
        tile = outline_frame(colors.crop((x, y, x+w, y+cell_h)), 127, black)
        colors.paste(tile, (x, y))
    colors.save(directory/"kirby.png", transparency=127, optimize=True)
    with Image.open(directory/"kirby.png") as exported:
        rgba = exported.convert("RGBA")
        assert rgba.getchannel("A").tobytes()==opaque.tobytes()
        first = rgba.crop((0, 0, w, cell_h))
        card = first.crop(first.getchannel("A").getbbox())
    info = {"width":w,"height":cell_h,"ground":data["groundAnchor"][1]-top,"columns":columns,"clips":clips}
    (directory/"kirby.json").write_text(json.dumps(info,separators=(",",":"))+"\n",encoding="utf-8")
    gallery = Image.open(catalog/"gallery.png").convert("RGBA")
    entries=json.loads((catalog/"gallery.json").read_text(encoding="utf-8"))
    slot=next((e[2] if len(e)>2 else len(entries["outfit"])+i) for i,e in enumerate(entries["pet"]) if e[0]=="kirby")
    icon=Image.new("RGBA",(64,64))
    assert card.width<=64 and card.height<=64
    icon.paste(card,((64-card.width)//2,(64-card.height)//2))
    gallery.paste(icon,(slot%9*64,slot//9*64))
    # Filter zero compresses this flat-color atlas better than adaptive filters.
    # Keep the published updater's 1 MiB limit and all other cards' exact RGBA.
    def chunk(kind, payload):
        return struct.pack(">I", len(payload))+kind+payload+struct.pack(">I", zlib.crc32(kind+payload))
    stride=gallery.width*4
    pixels=gallery.tobytes()
    scanlines=b"".join(b"\0"+pixels[i:i+stride] for i in range(0,len(pixels),stride))
    header=struct.pack(">IIBBBBB",gallery.width,gallery.height,8,6,0,0,0)
    png=b"\x89PNG\r\n\x1a\n"+chunk(b"IHDR",header)+chunk(b"IDAT",zlib.compress(scanlines,9))+chunk(b"IEND",b"")
    (catalog/"gallery.png").write_bytes(png)

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("pack", type=Path)
    args=parser.parse_args()
    read_pack(args.pack, Path(__file__).resolve().parents[1]/"AvatarUnlocks")
