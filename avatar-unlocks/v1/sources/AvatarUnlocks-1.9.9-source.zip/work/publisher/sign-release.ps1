param([Parameter(Mandatory)][string]$Bundle,[Parameter(Mandatory)][string]$Version,[Parameter(Mandatory)][string]$Feed,[Parameter(Mandatory)][string]$PublicKey,[ValidateSet('buddy','avatar-unlocks/v1')][string]$Channel='buddy')
$ErrorActionPreference='Stop'
if ($Version -notmatch '^\d{1,4}\.\d{1,4}\.\d{1,4}$') { throw 'Invalid release version' }
Add-Type -AssemblyName System.Security
$secret=Join-Path $PSScriptRoot 'publisher.dpapi'
$rsa=[Security.Cryptography.RSACryptoServiceProvider]::new(2048)
$rsa.PersistKeyInCsp=$false
$scope=[Security.Cryptography.DataProtectionScope]::CurrentUser
try {
  if (Test-Path -LiteralPath $secret) {
    $raw=[Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($secret),$null,$scope)
    try {$rsa.ImportCspBlob($raw)}finally{[Array]::Clear($raw,0,$raw.Length)}
  } else {
    if (Test-Path -LiteralPath $PublicKey) {throw 'The existing public key requires its original publisher key.'}
    $raw=$rsa.ExportCspBlob($true)
    try {
      $protected=[Security.Cryptography.ProtectedData]::Protect($raw,$null,$scope)
      $file=[IO.File]::Open($secret,[IO.FileMode]::CreateNew)
      try {$file.Write($protected,0,$protected.Length)}finally{$file.Dispose()}
    }finally{[Array]::Clear($raw,0,$raw.Length)}
  }
  $public=$rsa.ToXmlString($false)
  if (Test-Path -LiteralPath $PublicKey) {if ([IO.File]::ReadAllText($PublicKey) -ne $public){throw 'Publisher key mismatch'}}
  else {[IO.File]::WriteAllText($PublicKey,$public,[Text.Encoding]::ASCII)}
  $message=$Version+'|'+(Get-FileHash -LiteralPath $Bundle -Algorithm SHA256).Hash.ToLowerInvariant()
  if($Channel -ne 'buddy'){$message=$Channel+'|'+$message}
  $signature=$rsa.SignData([Text.Encoding]::ASCII.GetBytes($message),'SHA256')
  [IO.File]::WriteAllLines($Feed,@($message,[Convert]::ToBase64String($signature)),[Text.Encoding]::ASCII)
}finally{$rsa.Dispose()}
