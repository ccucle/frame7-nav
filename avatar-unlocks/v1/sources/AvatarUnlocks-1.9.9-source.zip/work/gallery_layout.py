"""Generate native Rainmeter meters for the shared nine-slot catalog."""


def gallery_layout(resource):
    sections = []
    styles = {"Meter": "String", "FontFace": "Galmuri9 Regular", "AntiAlias": 0,
              "FontSize": 10, "FontColor": "36,53,49"}
    atlas = resource + "unlock-gallery.png"

    def meter(name, x, y, **options):
        data = {"Group": "UnlockGallery", "Hidden": 1, "DynamicVariables": 1, "X": x, "Y": y, **options}
        sections.append("[" + name + "]\n" + "\n".join(f"{k}={v}" for k, v in data.items()))

    def label(name, x, y, caption, **options):
        meter(name, x, y, **{**styles, "Text": caption, **options})

    def image(name, x, y, **options):
        meter(name, x, y, Meter="Image", ImageName=atlas, AntiAlias=0, **options)

    def button(call):
        return f'[!CommandMeasure AvatarUnlocks "{call}"]'

    meter("GalleryCard", 0, 0, Meter="Shape",
          Shape="Rectangle 2,2,326,446,4 | Fill Color 247,243,229 | StrokeWidth 3 | Stroke Color 37,59,59",
          Shape2="Rectangle 3,3,324,41 | Fill Color 38,61,62 | StrokeWidth 0",
          Shape3="Line 14,407,315,407 | StrokeWidth 1 | Stroke Color 167,172,155")
    image("GalleryBook", 13, 13, ImageCrop="64,192,12,12", W=18, H=18)
    label("GalleryTitle", 39, 11, "해금 도감", FontSize=13, FontColor="255,247,220")
    label("GalleryBack", 147, 12, "목록으로", FontColor="255,247,220", LeftMouseUpAction=button("GalleryBack()"))
    label("GalleryClose", 313, 14, "닫기", FontSize=9, StringAlign="Right",
          FontColor="218,229,218", LeftMouseUpAction=button("ClosePanel()"))
    for i, name in enumerate(("의상", "펫", "포켓몬"), 1):
        action = button(f"GalleryTab({i})")
        x = 13 + (i - 1) * 103
        meter(f"GalleryTabBg{i}", x, 54, Meter="Image", W=96, H=30,
              SolidColor="224,226,211", LeftMouseUpAction=action)
        label(f"GalleryTabText{i}", x + 48, 60, name, StringAlign="Center", LeftMouseUpAction=action)
    for i in range(9):
        x, y = 13 + i % 3 * 103, 94 + (i // 3) * 103
        n = i + 1
        meter(f"GalleryCell{n}", x, y, Meter="Shape",
              Shape="Rectangle 0,0,96,96,2 | Fill Color 229,228,218 | StrokeWidth 1 | Stroke Color 172,175,163")
        image(f"GalleryArt{n}", x + 16, y + 5, ImageCrop="0,0,64,64", W=64, H=64)
        image(f"GalleryLock{n}", x + 77, y + 5, ImageCrop="0,192,10,12", W=14, H=16)
        label(f"GalleryName{n}", x + 48, y + 73, "", FontSize=9, StringAlign="Center", ClipString=1, W=86, H=20)
        label(f"GalleryEvolution{n}", 20, 100 + i * 33, "", W=286, H=25, ClipString=1)
    label("GalleryEmpty", 164, 219, "", StringAlign="Center")
    search = button("GallerySearch()")
    # Integer-aligned two-pixel tiles give the lens and handle crisp stepped edges.
    icon_runs = [(2, 0, 3), (1, 1, 1), (5, 1, 1), (0, 2, 1), (6, 2, 1),
                 (0, 3, 1), (6, 3, 1), (0, 4, 1), (6, 4, 1), (1, 5, 1),
                 (5, 5, 1), (2, 6, 3), (6, 6, 1), (7, 7, 1), (8, 8, 1)]
    icon = {f"Shape{i}": f"Rectangle {9+2*x},{6+2*y},{2*w},2 | Fill Color 72,90,81 | StrokeWidth 0"
            for i, (x, y, w) in enumerate(icon_runs, 2)}
    meter("GallerySearchFrame", 13, 370, Meter="Shape", LeftMouseUpAction=search,
          MouseActionCursorName="TEXT",
          Shape="Rectangle 1,1,300,28,6 | Fill Color 255,255,255 | Stroke Color 151,164,155 | StrokeWidth 1",
          **icon)
    label("GallerySearch", 42, 375, "", FontFace="Malgun Gothic", AntiAlias=1,
          W=238, H=20, ClipString=1, MouseActionCursorName="TEXT", LeftMouseUpAction=search)
    label("GalleryClear", 298, 372, "×", FontFace="Malgun Gothic", AntiAlias=1, FontSize=12,
          W=25, H=25, StringAlign="Center", SolidColor="0,0,0,1",
          LeftMouseUpAction=button("GalleryClear()"), ToolTipText="검색 지우기")
    label("GalleryCount", 13, 421, "", FontSize=9)
    label("GalleryPrev", 114, 419, "◀", LeftMouseUpAction=button("GalleryPage(-1)"))
    label("GalleryPageNumber", 164, 421, "", StringAlign="Center", FontSize=9)
    label("GalleryNext", 201, 419, "▶", LeftMouseUpAction=button("GalleryPage(1)"))
    label("GalleryUpdates", 314, 417, "업데이트 확인", StringAlign="Right", FontSize=9,
          SolidColor="228,230,215", Padding="5,3,5,3", LeftMouseUpAction=button("OpenUpdates()"))
    return "\n\n".join(sections) + "\n"
