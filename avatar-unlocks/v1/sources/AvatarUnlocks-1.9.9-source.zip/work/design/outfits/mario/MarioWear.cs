using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections.Generic;

// One native grid for the body, the fitted costume layer and the inventory icon.
public sealed class MarioWear {
    const int W=84,H=112;
    const int Ink=0x392a2b, Skin=0x60bae9, BlueShadow=0x4688a9, Mouth=0xf57868;
    const int Red=0xde3f38, RedLight=0xf3644c, RedShade=0xb92e31, RedDeep=0x8e3031;
    const int Jean=0x355ba2, JeanLight=0x527bc0, JeanShade=0x29457a, JeanDeep=0x233453;
    const int White=0xfff4db, Pearl=0xe5dfcf, GloveShade=0xc2baaf;
    const int Gold=0xf6c24d, GoldLight=0xffdf83, GoldEdge=0x996129;
    const int Boot=0x935a3b, BootLight=0xb97d4f, BootShade=0x714336, Sole=0x583b32;
    static readonly int[] DX={-1,1,0,0},DY={0,0,-1,1};
    readonly Bitmap src, dst, layer;
    readonly int[] faceLeft=new int[H],faceRight=new int[H];
    int xMin=W,xMax=-1,top=H,chin=-1;
    static int RGB(Color c) {return c.ToArgb() & 0xffffff;}
    static Color ColorOf(int c) {return Color.FromArgb(255,(c>>16)&255,(c>>8)&255,c&255);}
    static bool IsSkin(int c) {return c==Skin || c==BlueShadow;}
    MarioWear(Bitmap original,Bitmap worn,Bitmap clothing) {src=original;dst=worn;layer=clothing; LocateFace();}
    void Dot(int x,int y,int rgb) {
        if(x<0||x>=W||y<0||y>=H)return;
        Color c=ColorOf(rgb);dst.SetPixel(x,y,c);
        layer.SetPixel(x,y,c.ToArgb()==src.GetPixel(x,y).ToArgb()?Color.Transparent:c);
    }
    void LocateFace() {
        for(int y=0;y<H;y++){faceLeft[y]=W;faceRight[y]=-1;}
        int sy=0;while(sy<H&&!IsSkin(RGB(src.GetPixel(42,sy))))sy++;
        if(sy>=H)throw new Exception("No blue face");
        bool[,] seen=new bool[W,H];var q=new Queue<Point>();q.Enqueue(new Point(42,sy));seen[42,sy]=true;
        while(q.Count>0) {
            Point p=q.Dequeue();int x=p.X,y=p.Y;
            faceLeft[y]=Math.Min(faceLeft[y],x);faceRight[y]=Math.Max(faceRight[y],x);
            xMin=Math.Min(xMin,x);xMax=Math.Max(xMax,x);top=Math.Min(top,y);chin=Math.Max(chin,y);
            for(int k=0;k<4;k++){int a=x+DX[k],b=y+DY[k];if(a<0||b<0||a>=W||b>=H||seen[a,b])continue;
                seen[a,b]=true;if(IsSkin(RGB(src.GetPixel(a,b))))q.Enqueue(new Point(a,b));}
        }
    }
    bool Border(int x,int y) {
        for(int k=0;k<4;k++)if(src.GetPixel(x+DX[k],y+DY[k]).A==0)return true;
        return false;
    }
    // A separate boot fit is needed when a lifted shoe crosses the other trouser leg.
    static bool Leather(string pose,int x,int y) {
        switch(pose) {
            case "walk1":return (x<=32&&y>=97)||(x>=45&&y>=96);
            case "walk2":return (x<=32&&y>=94)||(x>=39&&y>=101);
            case "walk3":return (x<=31&&y>=86)||(x>=38&&y>=101);
            case "walk4":return (x<=33&&y>=89)||(x<=37&&y>=94)||(x>=35&&y>=101);
            case "walk5":return (x<=32&&y>=96)||(x>=48&&y>=96);
            case "walk6":return (x<=36&&y>=96)||(x>=40&&y>=101);
            case "walk7":return (x<=34&&y>=88)||(x>=38&&y>=101);
            case "walk8":return (x<=37&&y>=91)||(x>=34&&y>=101);
            case "step":return (x<=31||x>=46)&&y>=95;
            case "jump":return (x<=37&&y>=88)||(x>=40&&y>=92);
            case "dance":return (x<=42&&y>=98)||(x>=48&&y>=84);
            default:return y>=(pose=="idle"?99:98);
        }
    }
    static bool OldCloth(int c){return c==0x464563||c==0x373851||c==0x262537;}
    static int LeatherColor(int c,int y,int foot) {
        if(y>=foot-1||c==0x66514a)return Sole;
        if(c==0x9d7d6a||c==0x777880)return BootShade;
        if(c==0xc8ae98||c==0xadb0b2)return Boot;
        return y<foot-5 ? BootLight : Boot;
    }
    bool Sleeve(int x,int y,int shoulder,int neck,int hx,int hy) {
        double ax=hx-shoulder,ay=hy-neck,len=ax*ax+ay*ay;
        if(len<1)return false;
        double t=((x-shoulder)*ax+(y-neck)*ay)/len;
        if(t<0.18||t>1.15)return false;
        double dx=x-shoulder-t*ax,dy=y-neck-t*ay;
        return dx*dx+dy*dy<30.0;
    }
    bool OnFace(int x,int y) {return y<=chin && x>=faceLeft[y]-1 && x<=faceRight[y]+1;}
    bool OnWeight(int x,int y,int bar) {
        return bar>0 && ((Math.Abs(y-bar)<=12 && (x<=22||x>=62)) ||
                          (x>=22&&x<=62&&y>=bar-2&&y<=bar+3));
    }
    void Clothing(string pose,int cx,int hem,int lx,int ly,int rx,int ry,int bar) {
        int neck=chin+2, waist=hem-3,foot=H-1;
        while(foot>0){bool any=false;for(int x=0;x<W;x++)any|=src.GetPixel(x,foot).A!=0;if(any)break;foot--;}
        for(int y=Math.Min(neck-8,Math.Min(ly,ry)-6);y<=foot;y++)for(int x=1;x<W-1;x++){
            Color pixel=src.GetPixel(x,y);int c=RGB(pixel);
            if(pixel.A==0||OnFace(x,y))continue;
            if(IsSkin(c)){
                if(Math.Min((x-lx)*(x-lx)+(y-ly)*(y-ly),(x-rx)*(x-rx)+(y-ry)*(y-ry))<=100)
                    Dot(x,y,c==BlueShadow?GloveShade:y<Math.Min(ly,ry)+1?White:Pearl);
                continue;
            }
            if(OnWeight(x,y,bar)||Border(x,y))continue;
            int u=x-cx,v=y-neck;
            bool arm=Sleeve(x,y,cx-12,neck+1,lx,ly)||Sleeve(x,y,cx+9,neck+1,rx,ry);
            bool bib=!arm && (y>=waist || (v>=7 && u>=-12 && u<=10) ||
                              (v>=0 && v<=9 && ((u>=-12 && u<=-9)||(u>=7 && u<=10))));
            if(pose=="dance" && x>cx+10 && y>=hem-12)bib=true;
            if(c==Ink && !(bib&&v>=2&&y<waist&&Math.Abs(u)<=6))continue;
            if(y<neck-3 && !arm && !OldCloth(c))continue;
            if(Leather(pose,x,y)&&c!=Ink&&!OldCloth(c)){Dot(x,y,LeatherColor(c,y,foot));continue;}
            if(bib) {
                int col=u>7?JeanShade:Jean;
                if(y>=waist){
                    if(c==0x262537)col=JeanDeep;
                    else if(c==0x373851)col=JeanShade;
                    else if(c==0xf4e5d0||c==0xc8ae98)col=JeanLight;
                }else if(v==7 || (u==-12&&v>=8) || (u==-11&&v<7))col=JeanLight;
                if(v==8&&u>=-8&&u<=6)col=Jean;
                // 2-pixel brass fastenings and a discreet stitched front pocket.
                if(v>=5&&v<=8 && ((u>=-12&&u<=-9)||(u>=7&&u<=10))){
                    int k=u<0?u+12:u-7;
                    col=(v==5&&k>=1&&k<=2)?GoldLight:(v==8||k==3)?GoldEdge:Gold;
                }
                if(v>=12&&v<=16&&u>=-5&&u<=4 && (v==12||u==-5||u==4||v==16))
                    col=v==12?JeanLight:JeanShade;
                Dot(x,y,col);
            } else {
                int col=c==0x262537?RedDeep:c==0x373851?RedShade:Red;
                if((x<cx-11||x>=cx+8) && c==0xf4e5d0) col=RedLight;
                Dot(x,y,col);
            }
        }
    }
    // Stepped raster profiles. All outlines are native one-pixel edges.
    static readonly int[,] Crown={
        {-6,4},{-10,8},{-13,11},{-15,14},{-17,16},{-18,17},{-19,18},
        {-20,19},{-21,20},{-21,21},{-22,22},{-22,22},{-23,23},{-23,23},
        {-23,23},{-23,23},{-23,22},{-23,21},{-22,20},{-22,18},{-21,14},{-20,8}};
    static readonly int[,] Brim={
        {3,16},{-3,21},{-9,24},{-13,26},{-17,27},{-19,28},{-20,28},{-20,27},{-19,23}};
    static bool InRows(int[,] rows,int x,int y){return y>=0&&y<rows.GetLength(0)&&x>=rows[y,0]&&x<=rows[y,1];}
    static bool EdgeOf(int[,] rows,int x,int y){for(int k=0;k<4;k++)if(!InRows(rows,x+DX[k],y+DY[k]))return true;return false;}
    void Hat() {
        int cx=(xMin+xMax)/2, cy=top-12;
        for(int y=0;y<Crown.GetLength(0);y++)for(int x=Crown[y,0];x<=Crown[y,1];x++){
            int c=EdgeOf(Crown,x,y)?Ink:(x<-14||y>=17)?RedShade:(y<4&&x<5)?RedLight:Red;
            Dot(cx+x,cy+y,c);
        }
        // White stitched patch with a five-column red M.
        string[] badge={"  .....  "," ....... ","..m...m..","..mm.mm..","..m.m.m..","..m...m.."," .m...m. ","  .....  "};
        for(int y=0;y<badge.Length;y++)for(int x=0;x<badge[y].Length;x++) {
            char p=badge[y][x];if(p!=' ')Dot(cx+3+x,cy+4+y,p=='m'?RedShade:y==7?Pearl:White);
        }
        // The visor is higher at the far side and falls a little over the near temple.
        for(int y=0;y<Brim.GetLength(0);y++)for(int x=Brim[y,0];x<=Brim[y,1];x++){
            int twist=(18-x)/7,yy=cy+11+y+twist;
            int c=EdgeOf(Brim,x,y)?Ink:y<=3?RedLight:y>=6?RedDeep:Red;
            Dot(cx+x,yy,c);
        }
    }
    void SoftenMouth() {
        int lastX=-1,lastY=-1,count=0;
        for(int y=top+6;y<chin-2;y++){
            int pixels=0;
            for(int x=xMin;x<=xMax;x++)
                if(OnFace(x,y) && RGB(src.GetPixel(x,y))==Mouth){pixels++;lastX=x;lastY=y;}
            if(pixels==0 && lastY>=0)break;
            if(pixels>0)count=pixels;
        }
        // Round one inside corner of the lowest coral row without moving the outer lip.
        if(lastY>=0)Dot(lastX,lastY,count>1?Ink:0xd26055);
    }
    public static void Render(string file,string destination,string overlay,string pose,int cx,int hem,int lx,int ly,int rx,int ry,int bar) {
        using(var original=new Bitmap(file))
        using(var dressed=original.Clone(new Rectangle(0,0,W,H),PixelFormat.Format32bppArgb))
        using(var clothing=new Bitmap(W,H,PixelFormat.Format32bppArgb)){
            var art=new MarioWear(original,dressed,clothing);art.Clothing(pose,cx,hem,lx,ly,rx,ry,bar);art.Hat();art.SoftenMouth();
            dressed.Save(destination,ImageFormat.Png);clothing.Save(overlay,ImageFormat.Png);
        }
    }
}
