param(
    [string]$Base = (Join-Path $PSScriptRoot 'base'),
    [string]$Output = (Join-Path $PSScriptRoot '../../../../AvatarUnlocks/outfits/formday-buddy/hoodie'),
    [string]$Layers = (Join-Path $PSScriptRoot 'layers'),
    [string]$Atlas = (Join-Path $PSScriptRoot '../../../../AvatarUnlocks/gallery.png')
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
if (-not ('MarioWear' -as [type])) {
    $refs = if ($PSVersionTable.PSEdition -eq 'Core') {
        @('System.Drawing.Common','System.Drawing.Primitives','System.Private.Windows.Core',
          'System.Private.Windows.GdiPlus','System.Runtime','System.Runtime.InteropServices',
          'System.ComponentModel.Primitives','System.Collections')
    } else { @('System.Drawing') }
    Add-Type -Path (Join-Path $PSScriptRoot 'MarioWear.cs') -ReferencedAssemblies $refs
    Add-Type -Path (Join-Path $PSScriptRoot 'MarioCard.cs') -ReferencedAssemblies $refs
}
$fingerprints = @{}
foreach ($line in (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'base.sha256'))) {
    $digest, $name = $line -split '  ', 2
    $fingerprints[$name] = $digest
}
$fits = Import-Csv -LiteralPath (Join-Path $PSScriptRoot 'fit.csv')
foreach ($fit in $fits) {
    $file = if ($fit.pose -in 'idle','jump','step') { $fit.pose+'.png' } else { 'motion/'+$fit.pose+'.png' }
    $src = Join-Path $Base $file
    if ((Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash -ne $fingerprints[$file]) {
        throw "Body artwork differs from the fitted v0.6.14 frame: $file"
    }
}
foreach ($fit in $fits) {
    $file = if ($fit.pose -in 'idle','jump','step') { $fit.pose+'.png' } else { 'motion/'+$fit.pose+'.png' }
    $src = Join-Path $Base $file
    $dst = Join-Path $Output $file
    $layer = Join-Path $Layers $file
    foreach ($target in $dst,$layer) {
        [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($target))) | Out-Null
    }
    [MarioWear]::Render($src,$dst,$layer,$fit.pose,$fit.frontX,$fit.hemY,
        $fit.leftHandX,$fit.leftHandY,$fit.rightHandX,$fit.rightHandY,$fit.barY)
}
[MarioCard]::Render($Atlas,(Join-Path $PSScriptRoot 'card.png'))
