using System;
using System.Drawing;
using System.Drawing.Imaging;

public static class MarioCard {
    const int Ink=0x392a2b, Red=0xde3f38, RedLight=0xf3644c, RedShade=0xb92e31;
    const int Blue=0x355ba2, BlueLight=0x527bc0, BlueShade=0x29457a;
    static void Dot(Bitmap b,int x,int y,int c){b.SetPixel(x,y,Color.FromArgb(255,c>>16,(c>>8)&255,c&255));}
    static bool Shape(int x,int y) {
        if(y<24||y>56)return false;
        int[] widths={8,12,15,17,18,19,19,20,21,21,22,22,22,21,20,19,18,16};
        if(y<=41)return Math.Abs(x-31)<=widths[y-24];
        return x>=18&&x<=44 && (y<49 || (x<=29 || x>=33));
    }
    public static void Render(string atlasPath,string itemPath) {
        using(var card=new Bitmap(64,64,PixelFormat.Format32bppArgb)){
            for(int y=24;y<=56;y++)for(int x=8;x<=54;x++){
                if(!Shape(x,y))continue;
                bool edge=!Shape(x-1,y)||!Shape(x+1,y)||!Shape(x,y-1)||!Shape(x,y+1);
                bool bib=(y>=33&&x>=21&&x<=41)||(y>=26&&((x>=21&&x<=24)||(x>=38&&x<=41)))||(y>=39&&x>=18&&x<=44);
                int c=bib?(x>=39||y>=55?BlueShade:Blue):(x>=43||y>=37?RedShade:Red);
                if(!bib&&x<=17&&y<34)c=RedLight;
                if(bib && ((x==21||x==38)&&y<=34 || y==34&&x>24&&x<38))c=BlueLight;
                if(y>=32&&y<=34&&((x>=22&&x<=24)||(x>=38&&x<=40)))c=y==34?0xbb812e:0xffd56c;
                if(y>=37&&y<=42&&x>=27&&x<=35&&(y==37||x==27||x==35||y==42))c=y==37?BlueLight:BlueShade;
                Dot(card,x,y,edge?Ink:c);
            }
            int[,] cap={{26,34},{23,37},{21,39},{20,41},{18,42},{18,43},{17,43},{17,43},{16,44},{16,44},{16,44},{16,43},{17,43},{18,40},{19,37}};
            for(int y=0;y<cap.GetLength(0);y++)for(int x=cap[y,0];x<=cap[y,1];x++){
                bool edge=x==cap[y,0]||x==cap[y,1]||y==0||y==14||
                    (y>0&&(x<cap[y-1,0]||x>cap[y-1,1]))||
                    (y<14&&(x<cap[y+1,0]||x>cap[y+1,1]));
                Dot(card,x,y+5,edge?Ink:x<21||y>11?RedShade:y<3?RedLight:Red);
            }
            string[] badge={" ... ",".....","m...m","mm.mm","m.m.m","m...m"," ... "};
            for(int y=0;y<badge.Length;y++)for(int x=0;x<5;x++){
                char p=badge[y][x];if(p!=' ')Dot(card,30+x,y+8,p=='m'?RedShade:0xfff4db);}
            int[,] brim={{34,44},{29,48},{25,50},{21,50},{19,47},{19,41},{20,32}};
            for(int y=0;y<7;y++)for(int x=brim[y,0];x<=brim[y,1];x++){
                bool edge=y==0||y==6||x==brim[y,0]||x==brim[y,1]||
                    (y>0&&(x<brim[y-1,0]||x>brim[y-1,1]))||
                    (y<6&&(x<brim[y+1,0]||x>brim[y+1,1]));
                Dot(card,x,15+y,edge?Ink:y<3?RedLight:RedShade);
            }
            card.Save(itemPath,ImageFormat.Png);
            using(var input=new Bitmap(atlasPath))
            using(var atlas=input.Clone(new Rectangle(0,0,input.Width,input.Height),PixelFormat.Format32bppArgb)){
                bool changed=false;
                for(int y=0;y<64;y++)for(int x=0;x<64;x++){
                    Color pixel=card.GetPixel(x,y);
                    Color current=input.GetPixel(64+x,y);
                    if(current.A!=pixel.A || (pixel.A>0 && current.ToArgb()!=pixel.ToArgb()))changed=true;
                    atlas.SetPixel(64+x,y,pixel);
                }
                if(!changed)return;
                atlas.Save(atlasPath+".new",ImageFormat.Png);
            }
            System.IO.File.Copy(atlasPath+".new",atlasPath,true);System.IO.File.Delete(atlasPath+".new");
        }
    }
}
