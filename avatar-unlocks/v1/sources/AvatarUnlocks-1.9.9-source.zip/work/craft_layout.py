"""Native right-click inventory and the stone workshop."""
def craft_layout(stones):
    sections = []
    group = "Info"

    def meter(name, kind, x, y, **options):
        values = dict(Meter=kind, Group=group, Hidden=1, DynamicVariables=1, X=x, Y=y, **options)
        sections.append(f"[{name}]\n" + "\n".join(f"{key}={value}" for key, value in values.items()))

    def label(name, x, y, value, **options):
        meter(name, "String", x, y, MeterStyle="Type", Text=value, **options)

    def icon(name, x, y, index):
        meter(name, "Image", x, y, ImageName=r"#@##ReleaseSlot#\stone-items.png",
              ImageCrop=f"{24*index},0,24,24", W=24, H=24,
              ToolTipText="스톤 파우더" if index == 0 else stones[index-1]["name"])

    icon("PowderIcon", 115, 258, 0)
    label("PowderBalance", 144, 262, "#Powder#", FontSize=10, W=68, H=19, ToolTipText="보유 스톤 파우더")
    label("OpenWorkshopButton", 275, 260, "[제작하기]", StringAlign="Right", FontSize=9,
          Padding="4,2,4,2", SolidColor="68,97,99", LeftMouseUpAction="[!CommandMeasure Engine OpenWorkshop()]")

    group = "Workshop"
    meter("CraftCard", "Shape", 104, 14, Shape="Rectangle 0,0,254,393,8 | Fill Color 32,39,56,255 | Stroke Color 114,132,154")
    label("CraftTitle", 116, 26, "진화의 돌 제작", FontSize=13)
    label("CraftBack", 346, 27, "돌아가기", StringAlign="Right", FontSize=9, SolidColor="68,97,99",
          Padding="4,2,4,2", LeftMouseUpAction="[!CommandMeasure Engine CloseWorkshop()]")
    icon("CraftPowderIcon", 116, 53, 0)
    label("CraftPowder", 144, 57, "스톤 파우더  #Powder#", FontSize=10)
    label("CraftCost", 118, 83, "돌 1개당 파우더 30개", FontSize=9)
    label("CraftHeld", 269, 83, "보유", StringAlign="Right", FontSize=9)
    for i, stone in enumerate(stones, 1):
        y = 104+(i-1)*29
        icon(f"CraftIcon{i}", 118, y, i)
        label(f"CraftName{i}", 150, y+4, stone["name"])
        label(f"CraftStock{i}", 269, y+4, "0", StringAlign="Right", FontSize=9)
        label(f"CraftButton{i}", 343, y+2, "[제작]", StringAlign="Right", FontSize=10,
              Padding="5,2,5,2", SolidColor="65,70,79", FontColor="184,187,195")
    return "\n\n".join(sections) + "\n"
