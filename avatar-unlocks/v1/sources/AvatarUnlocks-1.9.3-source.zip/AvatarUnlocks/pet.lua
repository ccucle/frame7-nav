-- The selected pet is a second native Rainmeter config, with its own window and input.
local P={}
local root=SKIN:GetVariable("CURRENTPATH")
local folder=root.."FormdayDesktopPet\\"
local config=SKIN:GetVariable("CURRENTCONFIG").."\\FormdayDesktopPet"
local lease=root.."FormdayKirby.active"
local selected,prepared,nextPulse,nextFolder=false,false,0,0
local function read(path)
    local f=io.open(path,"rb");if not f then return nil end
    local s=f:read("*a");f:close();return s
end
local function write(path,data)
    local f=io.open(path,"wb");if not f then return false end
    local ok=f:write(data)
    return f:close() and ok
end
local function prepare(now)
    local iniPath=folder.."Kirby.ini"
    local prior=read(iniPath)
    local script="motion-"..M.version..".lua"
    if read(folder..script)~=M.petWindow and not write(folder..script,M.petWindow) then
        if now>=nextFolder then
            nextFolder=now+10
            -- Only create this skin's own child directory; all animation runs in Rainmeter.
            local target=folder:sub(1,-2):gsub("'","''")
            local ps=os.getenv("SystemRoot").."\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"
            SKIN:Bang('["'..ps..'" -NoProfile -NonInteractive -WindowStyle Hidden -Command "[void][IO.Directory]::CreateDirectory(\''..target..'\')"]')
        end
        return false
    end
    local image="kirby-"..M.version..".png"
    if M.imageFile(folder,"kirby",M.petAtlas,"")~=folder..image then return false end
    local ini=M.petIni:gsub("@SCRIPT@",script):gsub("@IMAGE@",image)
    if prior~=ini and not write(iniPath,ini) then return false end
    prepared=true
    if not prior then
        -- Only the initial installation needs to register the new skin folder.
        SKIN:Bang("!RefreshApp")
    else
        SKIN:Bang("!ActivateConfig",config,"Kirby.ini")
        if prior~=ini then SKIN:Bang("!Refresh",config) end
    end
    return true
end
function P.pulse()
    if not selected then return end
    local now=os.time()
    if now<nextPulse and now>=nextPulse-4 then return end
    nextPulse=now+(prepared and 4 or 1)
    if not write(lease,M.version.."|"..now.."\n") then return end
    if not prepared then prepare(now) end
end
local px,py
function P.active() return selected end
function P.track()
    if not selected or not prepared then return end
    local a=SKIN:GetMeter("Avatar");if not a then return end
    local x=(tonumber(SKIN:GetVariable("CURRENTCONFIGX")) or 0)+a:GetX()-90
    local y=(tonumber(SKIN:GetVariable("CURRENTCONFIGY")) or 0)+a:GetY()+a:GetH()-86
    x,y=math.floor(x+0.5),math.floor(y+0.5)
    if x~=px or y~=py then
        local target=tostring(x)..","..tostring(y)
        SKIN:Bang("!SetVariable","PetGoal",target,config)
        px,py=x,y
    end
end

function P.select(id)
    local show=id=="kirby"
    if show==selected then return end
    selected=show
    if show then
        prepared,nextPulse=false,0
        px,py=nil,nil
        P.pulse()
    else
        write(lease,"off\n")
        if prepared then SKIN:Bang("!DeactivateConfig",config) end
        prepared=false
    end
end
function P.shutdown()
    if selected then write(lease,"off\n") end
end
return P
