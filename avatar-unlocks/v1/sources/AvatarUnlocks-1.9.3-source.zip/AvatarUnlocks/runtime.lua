-- Rainmeter binding for the independently versioned avatar-unlocks/v1 channel.
local engine = M
local resources, shared, catalog, session, lastLevel
local content, effectiveCatalog
local nextPoll, running, panelOpen, updateCode = 0, false, false, 1
local currentProfile, currentAvatar
local panelPositioned=false
local gallery,showingUpdates,roam,pet
local function animationClock()
    local moving=not panelOpen and pet.active()
    local action=moving and "FollowerTick()" or "GallerySearchTick()"
    SKIN:Bang("!SetOption","GallerySearchWatch","OnUpdateAction","[!CommandMeasure AvatarUnlocks "..action.."]")
    SKIN:Bang(moving and "!EnableMeasure" or "!DisableMeasure","GallerySearchWatch")
end
local sizes
local workshopHost, shownWallet, shownSequence, shownEnabled
local wornOutfit, frameFiles = nil, {}

local function var(name, value) SKIN:Bang("!SetVariable",name,tostring(value)) end
local function option(name, fallback)
    local value=SKIN:GetVariable(name)
    if value==nil or value=="" then return fallback end
    return value
end
local function validVersion(v) return v and #v<=14 and v:match("^%d+%.%d+%.%d+$") end
local function newer(a,b)
    local ar,as,at=a:match("^(%d+)%.(%d+)%.(%d+)$")
    local br,bs,bt=b:match("^(%d+)%.(%d+)%.(%d+)$")
    if tonumber(ar)~=tonumber(br) then return tonumber(ar)>tonumber(br) end
    if tonumber(as)~=tonumber(bs) then return tonumber(as)>tonumber(bs) end
    return tonumber(at)>tonumber(bt)
end

local function display(code)
    updateCode=code
    var("UnlockUpdateCode",code)
    SKIN:Bang(code==2 and not panelOpen and "!ShowMeterGroup" or "!HideMeterGroup","UnlockUpdateBubble")
    SKIN:Bang(panelOpen and showingUpdates and code==2 and "!ShowMeterGroup" or "!HideMeterGroup","UnlockInstall")
    SKIN:Bang(panelOpen and showingUpdates and code==3 and "!ShowMeterGroup" or "!HideMeterGroup","UnlockRetry")
    SKIN:Bang("!UpdateMeterGroup","UnlockPanel")
    SKIN:Bang("!Redraw")
end

local function loadShared()
    local f=io.open(shared.."active.txt","rb")
    if not f then return end
    local version=f:read(32); f:close()
    if not validVersion(version) or not newer(version,engine.version) then return end
    local path=shared..version..".lua"
    local file=io.open(path,"rb")
    if not file then return end
    local header=file:read("*l");file:close()
    if header=="-- avatar-unlocks/v1 "..version then
        SKIN:Bang("!SetOption",SELF:GetName(),"ScriptFile",path)
    end
end

local function run(mode)
    running=true
    var("UnlockOperation",mode)
    display(mode=="Install" and 4 or 1)
    SKIN:Bang("!UpdateMeasure","AvatarUnlockDownload")
    SKIN:Bang("!CommandMeasure","AvatarUnlockDownload","Run")
end
function Install()
    if panelOpen and showingUpdates and not running and updateCode==2 then run("Install") end
end
function Check()
    if not running then nextPoll=os.time()+300;run("Check") end
end
function OpenPanel()
    if not panelOpen then
        panelOpen=true
        animationClock()
        var("UnlockPanelOpen",1)
        local callback=option("UnlockOnOpen","")
        if callback~="" then SKIN:Bang(callback) end
    end
    showingUpdates=false
    SKIN:Bang("!HideMeterGroup","UnlockPanel")
    gallery.open(tonumber(option("UnlockPanelX",0)) or 0,tonumber(option("UnlockPanelY",0)) or 0)
    display(updateCode)
end
function Finalize()
    if pet then pet.shutdown() end
    if roam then roam.close() end
    if gallery then gallery.shutdown() end
end
function GalleryTab(index) gallery.tab(index) end
function GalleryPage(delta) gallery.page(delta) end
function GallerySelect(slot) gallery.select(slot) end
function GalleryBack() gallery.back() end
function GallerySearch() gallery.edit() end
function GalleryClear() gallery.clear() end
function GallerySearchTick() gallery.tick() end
function GallerySearchDone() gallery.edited(SKIN:GetMeasure("GallerySearchEditor"):GetStringValue()) end
function OpenUpdates()
    if not panelOpen then OpenPanel() end
    gallery.hide()
    if not panelPositioned then
        local x=tonumber(option("UnlockPanelX",0)) or 0
        local y=tonumber(option("UnlockPanelY",0)) or 0
        for name,pos in pairs(content.panelPositions) do
            SKIN:Bang("!SetOption",name,"X",x+pos[1])
            SKIN:Bang("!SetOption",name,"Y",y+pos[2])
        end
        panelPositioned=true
    end
    showingUpdates=true
    SKIN:Bang("!ShowMeterGroup","UnlockPanel")
    display(updateCode)
    Check()
end
function ClosePanel()
    if not panelOpen then return end
    panelOpen=false
    showingUpdates=false
    gallery.hide()
    var("UnlockPanelOpen",0)
    SKIN:Bang("!HideMeterGroup","UnlockPanel")
    local callback=option("UnlockOnClose","")
    if callback~="" then SKIN:Bang(callback) end
    animationClock()
    display(updateCode)
end
function DownloadFinished()
    local output=SKIN:GetMeasure("AvatarUnlockDownload"):GetStringValue()
    running=false
    local status,version=output:match("^%s*(%u+) (%d+%.%d+%.%d+)%s*$")
    loadShared()
    var("UnlockLatestVersion",version or "-")
    if status=="AVAILABLE" and newer(version,engine.version) then display(2)
    elseif status and version==engine.version then display(0)
    else display(3) end
end

local function readJson(path,decode)
    local file=assert(io.open(path,"rb"))
    local source=file:read("*a")
    file:close()
    return decode(source)
end

local function setCompanions(ids)
    var("UnlockCompanionCount",#(ids or {}))
    roam.select(ids,sizes,shared,resources)
end

local function setPet(id)
    var("UnlockPet",id or "")
    pet.select(id)
    if not panelOpen then animationClock() end
end

function CanWearOutfit(id)
    return option("UnlockAvatar","")=="formday-buddy" and (id=="tracksuit" or id=="hoodie")
end

-- The avatar meter evaluates this when its native pose or direction changes.
-- Preserve the host meter so clicks, jumping and overlays use the same sprite.
function OutfitImage()
    local pose=option("Pose","idle")
    if wornOutfit=="hoodie" then
        local key=pose:gsub("\\","/")
        local hex=engine.hoodieFrames[key]
        if hex then
            if not frameFiles[key] then
                local name="unlock-hoodie-"..key:gsub("/","-")
                frameFiles[key]=engine.imageFile(shared,name,hex,resources..name..".png")
            end
            return frameFiles[key]
        end
    end
    return SKIN:GetVariable("@")..option("ReleaseSlot","A").."\\"..pose..".png"
end

local function setOutfit(id)
    id=CanWearOutfit(id) and id=="hoodie" and id or nil
    if id==wornOutfit then return end
    wornOutfit=id
    var("UnlockOutfit",id or "")
    local meter=option("UnlockAvatarMeter","Avatar")
    SKIN:Bang("!SetOption",meter,"ImageName","[&AvatarUnlocks:OutfitImage()]")
    SKIN:Bang("!UpdateMeter",meter)
    SKIN:Bang("!Redraw")
end

function Initialize()
    resources=SELF:GetOption("ResourcePath")
    local reopen=option("UnlockPanelOpen","0")=="1"
    shared=os.getenv("LOCALAPPDATA").."\\FormdayAvatar\\Unlocks\\v1\\"
    var("UnlockSystemVersion",engine.version)
    var("UnlockLatestVersion",engine.version)
    var("UnlockPanelOpen",0)
    var("UnlockOutfit","")
    local decode=dofile(resources.."json.lua").decode
    content=decode(engine.contentJson)
    catalog=readJson(option("UnlockCatalog",resources.."unlock-catalog.json"),decode).items
    assert(type(catalog)=="table","missing local reward list")
    sizes=content.sizes
    roam=engine.createRoam()
    pet=engine.createPet()
    setPet(nil)
    setCompanions(nil)
    gallery=engine.createGallery()
    gallery.init(resources,shared,content.families,sizes,content.galleryPositions)
    workshopHost=SKIN:GetMeter("PowderBalance")~=nil
    currentAvatar=option("UnlockAvatar","avatar")
    effectiveCatalog=engine.catalogFor(currentAvatar,catalog)
    gallery.bind(engine,effectiveCatalog,nil)
    display(0)
    if reopen then OpenPanel();OpenUpdates() end
    loadShared()
end

local function paintWallet(wallet,enabled)
    if not workshopHost then return end
    enabled=enabled and wallet and not wallet.error or false
    local sequence=wallet and wallet.sequence or -1
    if wallet==shownWallet and sequence==shownSequence and enabled==shownEnabled then return end
    shownWallet,shownSequence,shownEnabled=wallet,sequence,enabled
    var("Powder",wallet and not wallet.error and string.format("%.0f",wallet.powder) or "-")
    for i,id in ipairs(engine.stoneOrder) do
        local button="CraftButton"..i
        local canCraft=enabled and wallet.powder>=30
        SKIN:Bang("!SetOption","CraftStock"..i,"Text",wallet and not wallet.error and tostring(wallet.stones[id] or 0) or "-")
        SKIN:Bang("!SetOption",button,"FontColor",canCraft and "248,250,241" or "184,187,195")
        SKIN:Bang("!SetOption",button,"SolidColor",canCraft and "64,114,93" or "65,70,79")
        SKIN:Bang("!SetOption",button,"LeftMouseUpAction",canCraft and ('[!CommandMeasure AvatarUnlocks "CraftStone('..i..')"]') or "")
    end
    SKIN:Bang("!UpdateMeterGroup","Info")
    SKIN:Bang("!UpdateMeterGroup","Workshop")
    SKIN:Bang("!Redraw")
end

local offline
local function updateRewards()
    local avatar=option("UnlockAvatar","avatar")
    local profile=option("UnlockProfile","local")
    if avatar~=currentAvatar or profile~=currentProfile then
        if avatar~=currentAvatar then effectiveCatalog=engine.catalogFor(avatar,catalog) end
        session,lastLevel,offline=nil,nil,nil
        currentAvatar,currentProfile=avatar,profile
        gallery.bind(engine,effectiveCatalog,nil)
        setCompanions(nil)
        setPet(nil)
        setOutfit(nil)
    end
    local enabled=SKIN:GetVariable("UnlockEnabled")~="0"
    if not enabled or not avatar or not profile or profile=="" then
        if session then gallery.bind(engine,effectiveCatalog,nil) end
        if workshopHost and avatar and profile and not offline then
            offline=session or engine.connect(option("UnlockDataPath",SKIN:GetVariable("CURRENTPATH")),avatar,profile,catalog)
        end
        if offline then offline:readWallet() end
        paintWallet(offline and offline.wallet,false)
        session,lastLevel=nil,nil
        setOutfit(nil)
        -- Connection health gates rewards, not a pet already selected by this profile.
        setCompanions(offline and offline:roster())
        setPet(offline and offline:selected("pet"))
        var("UnlockNewItem","")
        return
    end
    local level=tonumber(option("UnlockLevel",SKIN:GetVariable("Level")))
    if not level or level<1 then return end
    if not session then
        session=offline or engine.connect(option("UnlockDataPath",SKIN:GetVariable("CURRENTPATH")),avatar,profile,catalog)
        offline=nil
        gallery.bind(engine,effectiveCatalog,session)
        lastLevel=nil
        setCompanions(session:roster())
        setPet(session:selected("pet"))
        setOutfit(session:selected("outfit"))
        var("UnlockNewItem","")
    end
    local sequence=session.wallet.sequence
    session:readWallet()
    local total=tonumber(SKIN:GetVariable("Total"))
    if total and total>session.wallet.xp then session:earn(total) end
    paintWallet(session.wallet,true)
    if session.wallet.sequence~=sequence then gallery.refresh() end
    if level==lastLevel then return end
    local gained=session:sync(level)
    lastLevel=level
    if #gained>0 then gallery.refresh() end
    for _,id in ipairs(gained) do
        var("UnlockNewItem",id)
        local callback=SKIN:GetVariable("UnlockOnGrant") or ""
        if callback~="" then SKIN:Bang(callback) end
    end
end

function RefreshWallet() updateRewards() end
function CraftStone(index)
    updateRewards()
    if workshopHost and option("WorkshopOpen","0")=="1" and session and engine.stoneOrder[index] then
        session:craft(engine.stoneOrder[index])
        paintWallet(session.wallet,true)
    end
end
function GalleryMember(slot) gallery.member(slot) end
function GalleryEvolve()
    updateRewards()
    gallery.evolve()
    if session then paintWallet(session.wallet,true) end
end

function GalleryCompanion()
    updateRewards()
    gallery.toggleCompanion()
end

function FollowerTick()
    if currentProfile~=option("UnlockProfile","local") or currentAvatar~=option("UnlockAvatar","avatar") then
        updateRewards()
        return
    end
    pet.track()
end

function Choose(kind,id)
    updateRewards()
    if session then
        if kind=="pokemon" then
            local ok=session:togglePokemon(id)
            if ok then setCompanions(session:roster()) end
            return ok
        end
        session:select(kind,id)
        if kind=="pet" then setPet(session:selected("pet")) end
        if kind=="outfit" then setOutfit(session:selected("outfit")) end
    end
end
function Update()
    gallery.prepare()
    if not nextPoll or nextPoll==0 then
        local meter=option("UnlockAvatarMeter","Avatar")
        if SKIN:GetMeter(meter) then
            SKIN:Bang("!SetOption",meter,"LeftMouseDoubleClickAction","[!CommandMeasure AvatarUnlocks OpenPanel()]")
        end
    end
    loadShared()
    updateRewards()
    pet.pulse()
    pet.track()
    if not running and os.time()>=nextPoll then Check() end
    return 0
end
