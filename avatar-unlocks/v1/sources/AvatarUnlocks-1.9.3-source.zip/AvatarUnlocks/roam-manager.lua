-- Single roster policy; one existing Rainmeter process and one shared atlas.
local P={}
local root=SKIN:GetVariable("CURRENTPATH").."FormdayPokemon\\"
local prefix=SKIN:GetVariable("CURRENTCONFIG").."\\FormdayPokemon\\Slot"
local slots,atlas={},nil
local function write(path,body)
 local f=io.open(path,"wb"); if not f then return false end
 local ok=f:write(body); return f:close() and ok
end
local function get(name,default) return tonumber(SKIN:GetVariable(name)) or default end
function P.select(ids,sizes,cache,resources)
 ids=ids or {}
 if #ids>0 and not atlas then 
  atlas=M.imageFile(cache,"unlock-walk",M.walkAtlas,resources.."unlock-walk.png")
 end
 local policy=sizes.roam or {}
 local desired,assigned,wanted={},{},{}
 for _,id in ipairs(ids) do wanted[id]=true end
 for n=1,6 do
  local id=slots[n]
  if id and wanted[id] then desired[n]=id;assigned[id]=true end
 end
 for _,id in ipairs(ids) do
  if not assigned[id] then
   for n=1,6 do if not desired[n] then desired[n]=id;break end end
  end
 end
 for n=1,6 do
  local id=desired[n]
  if id~=slots[n] then
   local cfg=prefix..n
   local dir=root.."Slot"..n.."\\"
   if id then
    local row=M.walkRows[id]
    local box=row and M.walkCrops[row+1]
    if box then
     local tier=sizes.tiers[sizes.species[id] or "medium"]
     local k=tier.scale*box.referenceHeight/box.h
     local w,h=math.max(1,math.floor(box.w*k+0.5)),math.max(1,math.floor(box.h*k+0.5))
     local a=SKIN:GetMeter("Avatar")
     local x=get("CURRENTCONFIGX",300)+(a and a:GetX() or 0)
     local y=get("CURRENTCONFIGY",250)+(a and a:GetY()+a:GetH() or 100)
     local gap=policy.spawnGap or 18
     x=policy.spawnSide=="right" and x+(a and a:GetW() or 84)+gap or x-w-gap
     y=y-h+(n-1)*14
     local fields={math.floor(x+0.5),math.floor(y+0.5),w,h,row,box.x,box.y,box.w,box.h,box.density,M.walkDensity,box.stripY or -1,box.cycle or 16}
     for _,v in ipairs(box.ends or {}) do fields[#fields+1]=v end
     -- A single newline-free, numeric record with the signed engine's atlas path.
     if atlas and write(dir.."state.txt",table.concat(fields,",").."\n"..atlas) then
      SKIN:Bang("!DeactivateConfig",cfg)
      SKIN:Bang("!ActivateConfig",cfg,"Pokemon.ini")
      slots[n]=id
     end
    end
   else
    SKIN:Bang("!DeactivateConfig",cfg)
    slots[n]=nil
   end
  end
 end
end
function P.close()
 for n=1,6 do SKIN:Bang("!DeactivateConfig",prefix..n);slots[n]=nil end
end
return P
