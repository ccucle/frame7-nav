"""Build the update payload or the one-time Rainmeter bootstrap."""
import argparse
import base64
import configparser
from io import BytesIO
import json
import math
from pathlib import Path
import re
import struct
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[1]
SKIN = ROOT / "DesktopSkin"
ASSETS = SKIN / "@Resources"
CHANNEL = ROOT / "release-channel"
PREFIX = "Skins/FormdayBuddy/"
BOOTSTRAP = "0.6.0"
UNLOCK = ROOT / "AvatarUnlocks"
UNLOCK_URL = "https://raw.githubusercontent.com/ccucle/frame7-nav/formday-buddy-updates/avatar-unlocks/v1"

def walk_display_atlas():
    from PIL import Image
    sizes = json.loads((UNLOCK / "pokemon-sizes.json").read_text(encoding="utf-8"))
    tiers = sizes["tiers"]
    density = max(1, math.ceil(max(tier["scale"] for tier in tiers.values())))
    rows = json.loads((UNLOCK / "walk-rows.json").read_text(encoding="utf-8"))
    with Image.open(UNLOCK / "walk-atlas.png") as image:
        assert image.format == "PNG" and image.size == (128, len(rows) * 64)
        grid_width = 128 * density * math.ceil(len(rows)/8)
        grid_height = 64 * density * min(8,len(rows))
        enlarged = Image.new("RGBA", (grid_width, grid_height))
        row_densities = []
        sequences = {}
        strips = []
        strip_y = grid_height
        for i, entry in enumerate(rows):
            item = {"id": entry} if isinstance(entry, str) else entry
            h = item.get("crop", [0, 0, 32, 32])[3]
            tier = sizes["species"].get(item["id"], "small")
            target = tiers[tier]["scale"] * item.get("referenceHeight", h) / h
            # Exact-size rows avoid Rainmeter filtering the authored pixel edges.
            row_density = int(target) if target.is_integer() and 1 <= target <= density else density
            row_densities.append(row_density)
            if "walkSequence" in item:
                durations = item["frameDurations"]
                assert durations and all(type(d) is int and d > 0 for d in durations)
                w, h = item["crop"][2:]
                with Image.open(UNLOCK / item["walkSequence"]) as master:
                    assert master.size == (w * len(durations), 2 * h)
                    strip = master.convert("RGBA").resize((master.width * row_density, master.height * row_density), Image.Resampling.NEAREST)
                strips.append(strip)
                sequences[item["id"]] = (strip_y, durations)
                strip_y += strip.height
            if "walkMaster" in item:
                # Render detailed masters directly into the on-screen frames.
                # Each master has four left-facing poses above four right-facing poses.
                x, y, w, h = item["crop"]
                with Image.open(UNLOCK / item["walkMaster"]) as master:
                    assert master.width % 4 == 0 and master.height % 2 == 0
                    fw, fh = master.width // 4, master.height // 2
                    for direction in range(2):
                        for frame in range(4):
                            left, top = frame * fw, direction * fh
                            pose = master.crop((left, top, left + fw, top + fh))
                            target_size = (w * row_density, h * row_density)
                            dest_x = (i // 8) * 128 * density + (frame * 32 + x) * row_density
                            dest_y = (i % 8) * 64 * density + (direction * 32 + y) * row_density
                            enlarged.paste(pose.resize(target_size, Image.Resampling.NEAREST), (dest_x, dest_y))
                continue
            strip = image.crop((0, i * 64, 128, (i + 1) * 64))
            enlarged.paste(strip.resize((128 * row_density, 64 * row_density), Image.Resampling.NEAREST),
                           ((i//8)*128*density, (i%8)*64*density))
        if strips:
            canvas = Image.new("RGBA", (max(grid_width, max(s.width for s in strips)), strip_y))
            canvas.paste(enlarged, (0, 0))
            y = grid_height
            for strip in strips:
                canvas.paste(strip, (0, y))
                y += strip.height
            enlarged = canvas
        output = BytesIO()
        enlarged.save(output, format="PNG", compress_level=9)
    return density, output.getvalue(), row_densities, sequences

def gallery_script():
    text = (UNLOCK / "gallery.lua").read_text(encoding="utf-8")
    assert text.count("-- @pack-buttons") == 1
    return text.replace("-- @pack-buttons", (UNLOCK / "buttons.lua").read_text(encoding="utf-8"))

def unlock_engine(walk_display=None):
    previews = json.loads((UNLOCK / "gallery.json").read_text(encoding="utf-8"))
    rows = []
    seen = set()
    from PIL import Image
    slots = set()
    with Image.open(UNLOCK / "gallery.png") as image:
        assert image.width == 576 and image.height % 64 == 0
        capacity = image.height // 64 * 9
    for kind in ("outfit", "pet", "pokemon"):
        for item_id, label, *position in previews[kind]:
            slot = position[0] if position else len(rows)
            assert len(position) <= 1 and type(slot) is int and 0 <= slot < capacity
            assert slot not in slots and not 27 <= slot <= 35, "overlapping gallery art"
            slots.add(slot)
            assert re.fullmatch(r"[a-z0-9_-]+", item_id) and item_id not in seen
            seen.add(item_id)
            rows.append(f'    {{id="{item_id}", kind="{kind}", name={json.dumps(label, ensure_ascii=False)}, icon={slot}}},')
    def encoded_image(data):
        return base64.b64encode(data).decode("ascii")

    atlas = encoded_image((UNLOCK / "gallery.png").read_bytes())
    block = "M.gallery = {\n" + "\n".join(rows) + '\n}\nM.atlas="' + atlas + '"'
    walk_rows = json.loads((UNLOCK / "walk-rows.json").read_text(encoding="utf-8"))
    density, walk_atlas, row_densities, sequences = walk_display or walk_display_atlas()
    identifiers, crops = {}, []
    for index, entry in enumerate(walk_rows):
        # A plain ID from an earlier atlas uses its complete 32px frame.
        item = {"id": entry} if isinstance(entry, str) else entry
        ident = item["id"]
        x, y, w, h = item.get("crop", [0, 0, 32, 32])
        assert re.fullmatch(r"[a-z0-9_-]+", ident) and ident not in identifiers
        assert all(type(n) is int for n in (x, y, w, h))
        assert x >= 0 and y >= 0 and w > 0 and h > 0 and x + w <= 32 and y + h <= 32
        identifiers[ident] = index
        reference_height = item.get("referenceHeight", h)
        assert type(reference_height) is int and 1 <= reference_height <= 32
        motion = ""
        if ident in sequences:
            strip_y, durations = sequences[ident]
            ends = []
            total = 0
            for duration in durations:
                total += duration
                ends.append(str(total))
            motion = f",stripY={strip_y},cycle={total},ends={{{','.join(ends)}}}"
        crops.append(f"{{x={x},y={y},w={w},h={h},referenceHeight={reference_height},density={row_densities[index]}{motion}}}")
    block += "\nM.walkRows = {" + ",".join(f'["{ident}"]={i}' for ident, i in identifiers.items()) + "}"
    block += "\nM.walkCrops = {" + ",".join(crops) + "}"
    block += f"\nM.walkDensity={density}"
    block += '\nM.walkAtlas="' + encoded_image(walk_atlas) + '"'
    hoodie = UNLOCK / "outfits" / "formday-buddy" / "hoodie"
    poses = sorted(hoodie.rglob("*.png"))
    assert len(poses) == 18, "Incomplete hoodie artwork"
    block += "\nM.hoodieFrames = {\n"
    for pose in poses:
        key = pose.relative_to(hoodie).with_suffix("").as_posix()
        block += f'  ["{key}"]="{encoded_image(pose.read_bytes())}",\n'
    block += "}\n"
    from gallery_layout import gallery_layout
    def positions(text, names=None):
        config = configparser.ConfigParser(interpolation=None)
        config.read_string(text)
        return {name: [config.getint(name, "X", fallback=10), config.getint(name, "Y")]
                for name in (names or config.sections())}

    panel_names = ("UnlockPanelCard", "UnlockPanelTitle", "UnlockPanelClose", "UnlockPanelCurrent",
                   "UnlockPanelLatest", "UnlockPanelState", "UnlockInstallButton", "UnlockRetryButton")
    content = {"families": json.loads((UNLOCK / "pokedex.json").read_text(encoding="utf-8")),
               "petMotion": json.loads((UNLOCK / "pets/kirby.json").read_text(encoding="utf-8")),
               "sizes": json.loads((UNLOCK / "pokemon-sizes.json").read_text(encoding="utf-8")),
               "galleryPositions": positions(gallery_layout("")),
               "panelPositions": positions((UNLOCK / "panel.inc").read_text(encoding="utf-8"), panel_names)}
    pokemon = {row[0] for row in previews["pokemon"]}
    numbers, species_ids = set(), set()
    for family in content["families"].values():
        for number, uid, *_ in family:
            assert uid in pokemon and uid not in species_ids and number not in numbers, "missing or duplicate species card"
            species_ids.add(uid)
            numbers.add(number)
    assert species_ids == pokemon, "species card without a dex entry"
    assert set(identifiers) <= pokemon, "walking sprite without a species card"
    def lua_string(text):
        delimiter = "="
        while "]" + delimiter + "]" in text:
            delimiter += "="
        return "[" + delimiter + "[" + text + "]" + delimiter + "]"

    search_script = base64.b64encode((UNLOCK / "search.ps1").read_bytes()).decode("ascii")
    block += '\nM.searchScript="' + search_script + '"'
    block += "\nM.contentJson=" + lua_string(json.dumps(content, ensure_ascii=False, separators=(",", ":")))
    stones = json.loads((UNLOCK / "stones.json").read_text(encoding="utf-8"))
    targets = {}
    block += "\nM.stoneOrder={}\nM.stoneNames={}\nM.evolutions={}\n"
    for i, stone in enumerate(stones, 1):
        ident, name = stone["id"], json.dumps(stone["name"], ensure_ascii=False)
        assert re.fullmatch(r"[a-z]+", ident)
        block += f'M.stoneOrder[{i}]="{ident}"\nM.stoneNames.{ident}={name}\n'
        for target in stone["targets"]:
            assert target not in targets
            targets[target] = ident
    edges = set()
    for family in content["families"].values():
        ancestry = {}
        for number, ident, _, *parent in family:
            depth = 0
            if parent:
                previous, parent_depth = ancestry[parent[0]]
                depth = parent_depth + 1
                block += f'M.evolutions["{ident}"]={{parent="{previous}",stone="{targets[ident]}",cost={depth}}}\n'
                edges.add(ident)
            ancestry[number] = (ident, depth)
    assert edges == set(targets)
    block += (UNLOCK / "wallet.lua").read_text(encoding="utf-8") + "\n"
    rules = json.loads((UNLOCK / "avatar-rewards.json").read_text(encoding="utf-8"))
    block += "\nM.avatarRewards = {\n"
    for avatar, items in rules.items():
        assert re.fullmatch(r"[a-z0-9_-]{1,48}", avatar)
        ids = set()
        block += '  ["' + avatar + '"] = {\n'
        for item in items:
            ident, kind, level = item["id"], item["kind"], item["level"]
            assert re.fullmatch(r"[a-z0-9_-]{1,48}", ident) and ident not in ids
            assert kind in ("outfit", "pet", "pokemon") and type(level) == int and level >= 1
            ids.add(ident)
            block += f'    {{id="{ident}",kind="{kind}",level={level}}},\n'
        block += "  },\n"
    block += "}\nfunction M.createGallery()\n" + gallery_script() + "\nend"
    block += "\nfunction M.createFollower()\n" + (UNLOCK / "follower.lua").read_text(encoding="utf-8") + "\nend"
    block += '\nM.petAtlas="' + encoded_image((UNLOCK / "pets/kirby.png").read_bytes()) + '"'
    block += "\nfunction M.createPet()\n" + (UNLOCK / "pet.lua").read_text(encoding="utf-8") + "\nend"
    src = (UNLOCK / "engine.lua").read_text(encoding="utf-8")
    assert src.count("-- @pack-runtime") == 1
    src = src.replace("-- @pack-runtime", (UNLOCK / "runtime.lua").read_text(encoding="utf-8"))
    assert src.count("-- @pack-gallery") == 1
    return src.replace("-- @pack-gallery", block).encode("utf-8")

def unlock_version():
    first = (UNLOCK / "engine.lua").read_text(encoding="utf-8").splitlines()[0]
    return re.fullmatch(r"-- avatar-unlocks/v1 (\d{1,4}\.\d{1,4}\.\d{1,4})", first)[1]

def unlock_include(root):
    code = " ".join(line.strip() for line in (UNLOCK / "update.ps1").read_text(encoding="utf-8").splitlines())
    key = (UNLOCK / "publisher.xml").read_text(encoding="ascii").strip()
    shared = "([IO.Path]::Combine([Environment]::GetFolderPath('LocalApplicationData'),'FormdayAvatar','Unlocks','v1'))"
    call = f"Update-AvatarUnlocks '#UnlockOperation#' {shared} '{UNLOCK_URL}' '{key}' '{unlock_version()}'"
    cmd = f'-NoLogo -NoProfile -NonInteractive -Command "{code} {call}"'
    binding = (UNLOCK / "connect.template").read_text(encoding="utf-8").replace("@@ROOT@@",root).replace("@@PARAMETER@@",cmd)
    search = base64.b64encode((UNLOCK / "search.ps1").read_bytes()).decode("ascii")
    binding = binding.replace("@@SEARCH@@", search)
    from gallery_layout import gallery_layout
    return binding + "\n" + (UNLOCK / "panel.inc").read_text(encoding="utf-8") + "\n" + gallery_layout(root)

def unlock_files():
    walk_display = walk_display_atlas()
    hoodie = UNLOCK / "outfits" / "formday-buddy" / "hoodie"
    frames = {"unlock-hoodie-" + "-".join(p.relative_to(hoodie).parts): p.read_bytes()
              for p in hoodie.rglob("*.png")}
    return {**frames, "unlock-adapter.lua": (UNLOCK / "adapter.lua").read_bytes(),
            "unlock-engine.lua": unlock_engine(walk_display),
            "unlock-gallery.lua": gallery_script().encode("utf-8"),
            "unlock-gallery.png": (UNLOCK / "gallery.png").read_bytes(),
            "unlock-walk.png": walk_display[1],
            "unlock-kirby.png": (UNLOCK / "pets/kirby.png").read_bytes(),
            "unlock-pokemon-sizes.json": (UNLOCK / "pokemon-sizes.json").read_bytes(),
            "unlock-pokedex.json": (UNLOCK / "pokedex.json").read_bytes(),
            "unlock-catalog.json": (UNLOCK / "catalog.json").read_bytes()}

def unlock_kit():
    entries = unlock_files()
    controls = """[UnlockKitOffer]
Meter=String
Group=UnlockUpdateBubble
Text=해금 업데이트 해줘
FontSize=10
FontColor=255,255,255
StringEffect=Border
FontEffectColor=28,28,28
SolidColor=0,0,0,1
Hidden=1
LeftMouseUpAction=[!CommandMeasure AvatarUnlocks OpenUpdates()]
"""
    entries["connect.inc"] = profile(unlock_include("#@#AvatarUnlocks\\") + "\n" + controls)
    entries["json.lua"] = (UNLOCK / "json.lua").read_bytes()
    entries["README.md"] = (UNLOCK / "README.md").read_bytes()
    target = CHANNEL / "avatar-unlocks" / "v1" / "connect-kit.zip"
    target.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=target.parent) as temp:
        staged = Path(temp) / target.name
        write_zip(staged, {"AvatarUnlocks/" + k:v for k,v in entries.items()})
        staged.replace(target)
    return target

def unlock_release():
    target = CHANNEL / "avatar-unlocks" / "v1" / "releases" / (unlock_version() + ".lua")
    data = unlock_engine()
    if len(data) > 1048576:
        raise ValueError("Catalog exceeds the installed updater's 1 MiB limit.")
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        if target.read_bytes() != data:
            raise ValueError("Bump the engine version before changing an existing release.")
    else:
        with target.open("xb") as out:
            out.write(data)
    return target

def profile(text):
    return b"\xff\xfe" + text.replace("\r\n", "\n").replace("\n", "\r\n").encode("utf-16-le")

def write_zip(target, entries):
    target.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(target, "x") as z:
        for name, data in sorted(entries.items()):
            member = ZipInfo(name, (2026, 11, 24, 0, 0, 0))
            member.external_attr = 0o100644 << 16
            z.writestr(member, data, compress_type=ZIP_DEFLATED, compresslevel=9)
    with ZipFile(target) as z:
        assert z.testzip() is None

def runtime(version, initial=False):
    layout = (SKIN / "Formday.ini").read_text(encoding="utf-8-sig")
    from craft_layout import craft_layout
    layout = layout.replace("; @BuddyCraft", craft_layout(json.loads((UNLOCK / "stones.json").read_text(encoding="utf-8"))))
    settings = (SKIN / "settings.template").read_text(encoding="utf-8")
    startup = base64.b64encode((ROOT / "work/startup.ps1").read_bytes()).decode("ascii")
    layout = layout.replace("; @BuddySettings", settings.replace("@@BUDDY_STARTUP@@", startup))
    layout = layout.replace("; @AvatarUnlocksConnect", unlock_include("#@##ReleaseSlot#\\"))
    layout = re.sub(r"^(BuddyVersion|Version)=[\d.]+", lambda m: m[1] + "=" + version, layout, flags=re.M)
    if initial:
        layout = layout.replace("X=10\nY=#PetY#\nW=84\nH=112", "X=4\nY=#PetY#\nW=96\nH=128")
    result = {"Skin.inc": profile(layout), "build.txt": version.encode("ascii"), **unlock_files()}
    for pattern in ("*.lua", "*.png", "*.json", "motion/*.png"):
        for file in ASSETS.glob(pattern):
            result[file.relative_to(ASSETS).as_posix()] = file.read_bytes()
    return result

def bootstrap(version=BOOTSTRAP):
    payload = runtime(version, initial=version == BOOTSTRAP)
    entries = {"RMSKIN.ini": profile("[rmskin]\nName=Formday Buddy\nAuthor=Formday\nVersion="+version+
               "\nLoadType=Skin\nLoad=FormdayBuddy\\Formday.ini\nMergeSkins=1\nMinimumRainmeter=4.5.0\n")}
    for slot, entry in (("A", "Formday.ini"), ("B", "FormdayB.ini")):
        entries[PREFIX + entry] = profile("[Variables]\nReleaseSlot="+slot+
            "\n[Rainmeter]\n@Include=#@#"+slot+"\\Skin.inc\n")
        for name, data in payload.items():
            entries[PREFIX + "@Resources/"+slot+"/"+name] = data
    for directory in ("Connect", "Updater", "Fonts"):
        for file in (ASSETS / directory).iterdir():
            if file.is_file() and file.suffix in {".json",".js",".lua",".xml",".inc",".txt",".ttf"}:
                entries[PREFIX+"@Resources/"+directory+"/"+file.name] = (
                    profile(file.read_text(encoding="utf-8-sig")) if file.suffix==".inc" else file.read_bytes())
    assert PREFIX+"@Resources/Updater/publisher.xml" in entries
    guide = next((SKIN/"Data").glob("*.txt")).read_text(encoding="utf-8-sig")
    entries[PREFIX+"Data/Readme.txt"] = guide.encode("utf-8-sig")
    out = ROOT / ("FormdayBuddy-"+version+".rmskin")
    write_zip(out,entries)
    size = out.stat().st_size
    with out.open("ab") as stream:
        stream.write(struct.pack("<qB7s",size,0,b"RMSKIN\0"))
    return out

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("kind",choices=("bundle","bootstrap","unlock-kit","unlock-release"))
    parser.add_argument("version",nargs="?")
    opts=parser.parse_args()
    if opts.version is not None and not re.fullmatch(r"[0-9]{1,4}\.[0-9]{1,4}\.[0-9]{1,4}",opts.version):
        parser.error("Provide a numeric three-part version.")
    if opts.kind=="bundle":
        if not opts.version:
            parser.error("Provide a new numeric three-part version.")
        out=CHANNEL/"releases"/(opts.version+".zip")
        write_zip(out,runtime(opts.version))
    elif opts.kind=="unlock-kit":
        out=unlock_kit()
    elif opts.kind=="unlock-release":
        out=unlock_release()
    else:
        out=bootstrap(opts.version or BOOTSTRAP)
    print(out.name,out.stat().st_size)

