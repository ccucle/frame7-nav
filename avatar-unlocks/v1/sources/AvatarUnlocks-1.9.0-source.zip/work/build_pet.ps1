# PowerShell 7 ships the Roslyn compiler. Target the Windows .NET Framework
# reference assemblies so installed Rainmeter users need no additional runtime.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName Microsoft.CodeAnalysis.CSharp
$artDir = Join-Path $PSScriptRoot '../AvatarUnlocks/pets'
$motion = Get-Content (Join-Path $artDir 'kirby.json') -Raw | ConvertFrom-Json
$clips = foreach ($clip in $motion.clips.PSObject.Properties) {
    '{"' + $clip.Name + '",new Clip(' + $clip.Value.start + ',new int[]{' + ($clip.Value.ms -join ',') + '})}'
}
$metadata = @"
using System.Collections.Generic;
internal static class PetArt {
    internal const int Width=$($motion.width), Height=$($motion.height), Columns=$($motion.columns);
    internal static readonly Dictionary<string,Clip> Clips=new Dictionary<string,Clip>{ $($clips -join ',') };
}
"@
$framework = Join-Path $env:WINDIR 'Microsoft.NET/Framework/v4.0.30319'
$references = [Microsoft.CodeAnalysis.MetadataReference[]]@(foreach ($name in 'mscorlib','System','System.Core','System.Windows.Forms','System.Drawing') {
    [Microsoft.CodeAnalysis.MetadataReference]::CreateFromFile((Join-Path $framework ($name+'.dll')))
})
$source = [IO.File]::ReadAllText((Resolve-Path (Join-Path $artDir 'DesktopPet.cs'))) -replace "`r`n","`n"
$trees = [Microsoft.CodeAnalysis.SyntaxTree[]]@(
    [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText($source)
    [Microsoft.CodeAnalysis.CSharp.CSharpSyntaxTree]::ParseText(($metadata -replace "`r`n","`n"))
)
$options = [Microsoft.CodeAnalysis.CSharp.CSharpCompilationOptions]::new([Microsoft.CodeAnalysis.OutputKind]::WindowsApplication).WithDeterministic($true).WithOptimizationLevel([Microsoft.CodeAnalysis.OptimizationLevel]::Release)
$compiler = [Microsoft.CodeAnalysis.CSharp.CSharpCompilation]::Create('FormdayDesktopPet',$trees,$references,$options)
$bytes = [IO.MemoryStream]::new()
try {
    $result = $compiler.Emit($bytes)
    if (!$result.Success) { throw ($result.Diagnostics -join [Environment]::NewLine) }
    [IO.File]::WriteAllBytes((Join-Path $artDir 'FormdayDesktopPet.exe'),$bytes.ToArray())
} finally { $bytes.Dispose() }
