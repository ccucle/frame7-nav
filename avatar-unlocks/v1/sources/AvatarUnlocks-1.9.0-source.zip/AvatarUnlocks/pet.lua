-- The catalog owns selection and lifetime. The pet window owns movement and input.
local P={}
local state=SKIN:GetVariable("CURRENTPATH").."FormdayKirby.active"
local selected,program,atlas,nextPulse,nextLaunch=false,nil,nil,0,0

local function writeState(value)
    local f=io.open(state,"wb")
    if not f then return false end
    local ok=f:write(value,"\n")
    return f:close() and ok
end

local function launch()
    -- The child holds the lock for the lifetime of its window.
    local lock=io.open(state..".lock","a+b")
    if not lock then return end
    lock:close()
    SKIN:Bang('["'..program..'" "'..state..'" "'..atlas..'" "'..M.version..'"]')
end

function P.pulse()
    if not selected then return end
    local now=os.time()
    if now<nextPulse and now>=nextPulse-4 then return end
    nextPulse=now+4
    if not writeState(M.version) then return end
    if now>=nextLaunch or now<nextLaunch-12 then
        nextLaunch=now+12
        launch()
    end
end

function P.select(id,cache,resources)
    local enabled=id=="kirby"
    if selected==enabled then return end
    if enabled then
        program=M.petProgramFile(cache,resources)
        if not program then
            SKIN:Bang("!Log","Could not install the verified Formday desktop pet.","Error")
            return
        end
        atlas=M.imageFile(cache,"unlock-kirby",M.petAtlas,resources.."unlock-kirby.png")
        selected,nextLaunch,nextPulse=true,0,0
        P.pulse()
    else
        selected=false
        writeState("off")
    end
end
function P.shutdown()
    if selected then selected=false;writeState("off") end
end
return P
