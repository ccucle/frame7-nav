using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

internal sealed class Clip
{
    internal readonly int Start;
    internal readonly int[] Durations;
    internal Clip(int start, int[] durations) { Start = start; Durations = durations; }
}

internal sealed class DesktopPet : Form
{
    [DllImport("user32.dll")]
    private static extern bool SetProcessDPIAware();

    private readonly string lease, version;
    private readonly Bitmap[] frames;
    private readonly Region[] shapes;
    private readonly Random random = new Random();
    private readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
    private readonly Stopwatch clock = Stopwatch.StartNew();
    private long previous, nextLeaseCheck;
    private double x, y, remaining, pause = 400, frameTime;
    private int dx, dy, frame, drawn = -1;
    private string motion = "idle";
    private bool hovering, pressed, dragging, nextJump;
    private Point pressPoint, grabOffset;

    [STAThread]
    private static void Main(string[] args)
    {
        if (args.Length != 3) return;
        SetProcessDPIAware();
        if (!Active(args[0], args[2])) return;
        try
        {
            // The OS releases this handle even if Rainmeter or this window crashes.
            using (File.Open(args[0] + ".lock", FileMode.OpenOrCreate, FileAccess.Write, FileShare.None))
            using (DesktopPet pet = new DesktopPet(args[0], args[1], args[2]))
                Application.Run(pet);
        }
        catch (IOException) { /* Another copy owns this host, or it was removed. */ }
    }

    private static bool Active(string path, string expectedVersion)
    {
        try
        {
            using (var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
            using (var reader = new StreamReader(file))
            {
                string state = reader.ReadLine();
                if (state == "off") return false;
                var age = DateTime.UtcNow - File.GetLastWriteTimeUtc(path);
                // A concurrent write can be briefly empty.
                return (state == expectedVersion || String.IsNullOrEmpty(state)) && age.TotalSeconds < 40;
            }
        }
        catch (IOException) { return false; }
        catch (UnauthorizedAccessException) { return false; }
    }

    private DesktopPet(string state, string atlasFile, string release)
    {
        lease = state;
        version = release;
        AutoScaleMode = AutoScaleMode.None;
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        TopMost = true;
        StartPosition = FormStartPosition.Manual;
        DoubleBuffered = true;
        BackColor = Color.Magenta;
        TransparencyKey = BackColor;
        ClientSize = new Size(PetArt.Width, PetArt.Height);
        int count = 0;
        foreach (var c in PetArt.Clips.Values) count = Math.Max(count, c.Start + c.Durations.Length);
        frames = new Bitmap[count];
        shapes = new Region[count];
        using (var atlas = new Bitmap(atlasFile))
        {
            for (int i = 0; i < count; ++i)
            {
                var rect = new Rectangle(i % PetArt.Columns * Width, i / PetArt.Columns * Height, Width, Height);
                frames[i] = atlas.Clone(rect, PixelFormat.Format32bppArgb);
                var mask = new Region();
                mask.MakeEmpty();
                for (int row = 0; row < Height; ++row)
                {
                    int start = -1;
                    for (int col = 0; col <= Width; ++col)
                    {
                        bool opaque = col < Width && frames[i].GetPixel(col, row).A > 0;
                        if (opaque && start < 0) start = col;
                        if (!opaque && start >= 0)
                        {
                            mask.Union(new Rectangle(start, row, col - start, 1));
                            start = -1;
                        }
                    }
                }
                shapes[i] = mask;
            }
        }
        var area = Screen.FromPoint(Cursor.Position).WorkingArea;
        SetPosition(area.Left + (area.Width - Width) * (0.25 + random.NextDouble() * 0.5),
                    area.Top + (area.Height - Height) * (0.25 + random.NextDouble() * 0.5), area);
        SelectFrame();
        timer.Interval = 32;
        timer.Tick += Tick;
        previous = clock.ElapsedMilliseconds;
        timer.Start();
    }

    protected override bool ShowWithoutActivation { get { return true; } }
    protected override CreateParams CreateParams
    {
        get
        {
            var p = base.CreateParams;
            p.ExStyle |= 0x08000000 | 0x80; // WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW
            return p;
        }
    }
    private void SetPosition(double left, double top, Rectangle area)
    {
        x = Math.Max(area.Left, Math.Min(left, area.Right - Width));
        y = Math.Max(area.Top, Math.Min(top, area.Bottom - Height));
        Location = new Point((int)Math.Round(x), (int)Math.Round(y));
    }
    private void SetMotion(string name)
    {
        if (motion == name) return;
        motion = name; frame = 0; frameTime = 0;
        SelectFrame();
    }
    private void SelectFrame()
    {
        int index = PetArt.Clips[motion].Start + frame;
        if (index == drawn) return;
        drawn = index;
        Region = shapes[index].Clone();
        Text = "Formday Kirby - " + motion;
        Invalidate();
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        if (drawn >= 0) e.Graphics.DrawImageUnscaled(frames[drawn], 0, 0);
    }
    private bool Acting { get { return motion == "inhale" || motion == "jump"; } }
    private void PickLeg(Rectangle area)
    {
        // Pick a straight compass heading with room for a visible stride.
        int start = random.Next(8);
        for (int i = 0; i < 8; i++)
        {
            int heading = (start + i) % 8;
            dx = new int[] { 0, 1, 1, 1, 0, -1, -1, -1 }[heading];
            dy = new int[] { -1, -1, 0, 1, 1, 1, 0, -1 }[heading];
            double w = dx == 0 ? Double.MaxValue : dx > 0 ? area.Right - Width - x : x - area.Left;
            double h = dy == 0 ? Double.MaxValue : dy > 0 ? area.Bottom - Height - y : y - area.Top;
            remaining = Math.Min(random.Next(85, 265), Math.Min(w, h));
            if (remaining >= 12) return;
        }
        remaining = 0; pause = 600;
    }
    private void Tick(object sender, EventArgs e)
    {
        long now = clock.ElapsedMilliseconds;
        double ms = Math.Min(120, now - previous);
        previous = now;
        if (now >= nextLeaseCheck)
        {
            nextLeaseCheck = now + 250;
            if (!Active(lease, version)) { Close(); return; }
        }
        if (!Acting)
        {
            var area = Screen.FromRectangle(Bounds).WorkingArea;
            if (!area.Contains(Bounds) && !dragging) SetPosition(x, y, area);
            if (hovering || pressed || pause > 0)
            {
                pause = Math.Max(0, pause - ms);
                SetMotion("idle");
            }
            else
            {
                if (remaining <= 0) PickLeg(area);
                if (remaining > 0)
                {
                    SetMotion("walk-" + (dy < 0 ? "N" : dy > 0 ? "S" : "") + (dx < 0 ? "W" : dx > 0 ? "E" : ""));
                    double step = Math.Min(remaining, ms * 0.062 / (dx != 0 && dy != 0 ? Math.Sqrt(2) : 1));
                    SetPosition(x + dx * step, y + dy * step, area);
                    remaining -= step;
                    if (remaining <= 0) pause = random.Next(400, 1050);
                }
            }
        }
        frameTime += ms;
        var durations = PetArt.Clips[motion].Durations;
        while (frameTime >= durations[frame])
        {
            frameTime -= durations[frame++];
            if (frame == durations.Length)
            {
                frame = 0;
                if (Acting) { SetMotion("idle"); pause = 350; break; }
            }
        }
        SelectFrame();
    }
    protected override void OnMouseEnter(EventArgs e)
    {
        hovering = true;
        if (!Acting) SetMotion("idle");
        base.OnMouseEnter(e);
    }
    protected override void OnMouseLeave(EventArgs e) { hovering = false; base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left)
        {
            pressed = Capture = true; dragging = false;
            pressPoint = PointToScreen(e.Location); grabOffset = e.Location;
        }
        base.OnMouseDown(e);
    }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        if (pressed)
        {
            Point pointer = PointToScreen(e.Location);
            var slack = SystemInformation.DragSize;
            if (Math.Abs(pointer.X - pressPoint.X) >= slack.Width / 2 ||
                Math.Abs(pointer.Y - pressPoint.Y) >= slack.Height / 2) dragging = true;
            if (dragging)
            {
                SetMotion("idle"); remaining = 0;
                SetPosition(pointer.X - grabOffset.X, pointer.Y - grabOffset.Y, Screen.FromPoint(pointer).WorkingArea);
            }
        }
        base.OnMouseMove(e);
    }
    protected override void OnMouseUp(MouseEventArgs e)
    {
        if (pressed && e.Button == MouseButtons.Left)
        {
            bool clicked = !dragging && Region.IsVisible(e.Location);
            pressed = dragging = Capture = false;
            if (clicked) { SetMotion(nextJump ? "jump" : "inhale"); nextJump = !nextJump; }
        }
        base.OnMouseUp(e);
    }
    protected override void OnMouseCaptureChanged(EventArgs e)
    {
        if (!Capture) pressed = dragging = false;
        base.OnMouseCaptureChanged(e);
    }
    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            timer.Dispose();
            foreach (var bitmap in frames) if (bitmap != null) bitmap.Dispose();
            foreach (var region in shapes) if (region != null) region.Dispose();
        }
        base.Dispose(disposing);
    }
}
