-- @pack-pet-clips
local x,y,lastX,lastY,motion,frame,elapsed,drawn
local hold,remaining,dx,dy=400,0,0,0
local hovered,nextJump=false,false
local lease,savePosition,latestLease,lastSave,started,clock
local function variable(name) return tonumber(SKIN:ReplaceVariables("#"..name.."#")) or 0 end
local function read(path)
    local f=io.open(path,"rb");if not f then return "" end
    local s=f:read("*a");f:close();return s
end
local function move(left,top)
    x,y=left,top
    lastX,lastY=math.floor(x+0.5),math.floor(y+0.5)
    SKIN:Bang("!Move",lastX,lastY)
end
local function limits()
    local l,t=variable("WORKAREAX"),variable("WORKAREAY")
    return l,t,math.max(l,l+variable("WORKAREAWIDTH")-84),math.max(t,t+variable("WORKAREAHEIGHT")-86)
end
local function paint(name)
    if name~=motion then motion,frame,elapsed=name,1,0 end
    local index=clips[name].start+frame-1
    if drawn~=index then
        drawn=index
        SKIN:Bang("!SetOption","Kirby","ImageCrop",(index%12*84)..","..(math.floor(index/12)*86)..",84,86")
        SKIN:Bang("!UpdateMeter","Kirby")
    end
end
function Initialize()
    local folder=SKIN:GetVariable("CURRENTPATH")
    lease=folder.."..\\FormdayKirby.active"
    savePosition=folder.."position.txt"
    local l,t,r,b=limits()
    local sx,sy=read(savePosition):match("^(-?%d+),(-?%d+)")
    move(math.max(l,math.min(r,tonumber(sx) or math.floor((l+r)/2))),
         math.max(t,math.min(b,tonumber(sy) or math.floor((t+b)/2))))
    started,clock=os.time(),os.clock()
    latestLease,lastSave=started,0
    paint("idle")
end
local function acting() return motion=="inhale" or motion=="jump" end
function Hover(value)
    hovered=value==1
    if hovered and not acting() then paint("idle") end
end
function Interact()
    -- Rainmeter dispatches LeftMouseUpAction only after a click, not after a drag.
    paint(nextJump and "jump" or "inhale");nextJump=not nextJump
end
local headings={{1,0,"E"},{1,1,"SE"},{0,1,"S"},{-1,1,"SW"},{-1,0,"W"},{-1,-1,"NW"},{0,-1,"N"},{1,-1,"NE"}}
local heading
local function pick(l,t,r,b)
    local first=math.random(8)
    for offset=0,7 do
        local d=headings[(first+offset-1)%8+1]
        local roomX=d[1]==0 and math.huge or d[1]>0 and r-x or x-l
        local roomY=d[2]==0 and math.huge or d[2]>0 and b-y or y-t
        local distance=math.min(math.random(85,264),roomX,roomY)
        if distance>=12 then dx,dy,heading,remaining=d[1],d[2],d[3],distance;return end
    end
    hold=600
end
function Update()
    local now=os.time()
    local sample=os.clock()
    local ms=math.max(0,math.min(200,(sample-clock)*1000))
    clock=sample
    if now~=latestLease then
        latestLease=now
        local ver,at=read(lease):match("^([%d.]+)|(%d+)")
        if now-started>3 and (ver~=version or now-(tonumber(at) or 0)>40) then
            SKIN:Bang("!DeactivateConfig");return
        end
        if now-lastSave>=4 then
            local f=io.open(savePosition,"wb")
            if f then f:write(lastX,",",lastY);f:close() end
            lastSave=now
        end
    end
    local ax,ay=variable("CURRENTCONFIGX"),variable("CURRENTCONFIGY")
    if math.abs(ax-lastX)>3 or math.abs(ay-lastY)>3 then
        x,y,lastX,lastY=ax,ay,ax,ay
        remaining,hold=0,400
    end
    if not acting() then
        if hovered or hold>0 then
            hold=math.max(0,hold-ms);paint("idle")
        else
            local l,t,r,b=limits()
            if remaining<=0 then pick(l,t,r,b) end
            if remaining>0 then
                paint("walk-"..heading)
                local stride=20*ms/1000
                local step=math.min(remaining,(dx~=0 and dy~=0) and stride/math.sqrt(2) or stride)
                move(math.min(r,math.max(l,x+dx*step)),math.min(b,math.max(t,y+dy*step)))
                remaining=remaining-step
                if remaining<=0 then hold=math.random(400,1050) end
            end
        end
    end
    elapsed=elapsed+ms
    local durations=clips[motion].ms
    while elapsed>=durations[frame] do
        elapsed=elapsed-durations[frame]
        frame=frame+1
        if frame>#durations then
            frame=1
            if acting() then paint("idle");hold=350;break end
        end
    end
    paint(motion)
    return drawn
end
