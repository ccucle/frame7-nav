"""Import the approved motion pack into the catalog's indexed desktop atlas."""
import argparse
from io import BytesIO
import json
import struct
import zlib
from pathlib import Path
from zipfile import ZipFile
from PIL import Image

def read_pack(source, catalog):
    directory = catalog / "pets"
    directory.mkdir(exist_ok=True)
    with ZipFile(source) as z:
        data = json.loads(z.read("motions.json"))
        w, h = data["cell"]
        top = 26
        cell_h = h - top
        columns = 12
        frame_count = sum(c["frameCount"] for c in data["clips"].values())
        atlas = Image.new("RGBA", (columns*w, ((frame_count+columns-1)//columns)*cell_h))
        offset = 0
        clips = {}
        for name, clip in data["clips"].items():
            strip = Image.open(BytesIO(z.read(clip["file"]))).convert("RGBA")
            assert strip.size == (w*clip["frameCount"], h)
            assert len(clip["frameMs"]) == clip["frameCount"]
            assert not strip.crop((0, 0, strip.width, top)).getchannel("A").getbbox()
            clips[name] = {"start": offset, "ms": clip["frameMs"]}
            for i in range(clip["frameCount"]):
                frame = strip.crop((i*w, top, (i+1)*w, h))
                atlas.paste(frame, ((offset%columns)*w, (offset//columns)*cell_h))
                if name=="idle" and i==0:
                    card=frame.crop(frame.getchannel("A").getbbox())
                offset+=1
        assert offset==123
    # Preserve every silhouette pixel, including the thin air streaks.
    opaque = atlas.getchannel("A")
    colors = atlas.convert("RGB").quantize(colors=127, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
    colors.putpalette(colors.getpalette()[:127*3]+[0,0,0])
    colors.paste(127, (0,0), opaque.point(lambda v: 255 if v==0 else 0))
    colors.save(directory/"kirby.png", transparency=127, optimize=True)
    with Image.open(directory/"kirby.png") as exported:
        assert exported.convert("RGBA").getchannel("A").tobytes()==opaque.tobytes()
    info = {"width":w,"height":cell_h,"ground":data["groundAnchor"][1]-top,"columns":columns,"clips":clips}
    (directory/"kirby.json").write_text(json.dumps(info,separators=(",",":"))+"\n",encoding="utf-8")
    gallery = Image.open(catalog/"gallery.png").convert("RGBA")
    entries=json.loads((catalog/"gallery.json").read_text(encoding="utf-8"))
    slot=next((e[2] if len(e)>2 else len(entries["outfit"])+i) for i,e in enumerate(entries["pet"]) if e[0]=="kirby")
    icon=Image.new("RGBA",(64,64))
    assert card.width<=64 and card.height<=64
    icon.paste(card,((64-card.width)//2,(64-card.height)//2))
    gallery.paste(icon,(slot%9*64,slot//9*64))
    # Filter zero compresses this flat-color atlas better than adaptive filters.
    # Keep the published updater's 1 MiB limit and all other cards' exact RGBA.
    def chunk(kind, payload):
        return struct.pack(">I", len(payload))+kind+payload+struct.pack(">I", zlib.crc32(kind+payload))
    stride=gallery.width*4
    pixels=gallery.tobytes()
    scanlines=b"".join(b"\0"+pixels[i:i+stride] for i in range(0,len(pixels),stride))
    header=struct.pack(">IIBBBBB",gallery.width,gallery.height,8,6,0,0,0)
    png=b"\x89PNG\r\n\x1a\n"+chunk(b"IHDR",header)+chunk(b"IDAT",zlib.compress(scanlines,9))+chunk(b"IEND",b"")
    (catalog/"gallery.png").write_bytes(png)

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("pack", type=Path)
    args=parser.parse_args()
    read_pack(args.pack, Path(__file__).resolve().parents[1]/"AvatarUnlocks")
