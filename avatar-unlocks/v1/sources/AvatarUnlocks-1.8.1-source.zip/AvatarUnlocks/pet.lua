-- Independent pet animation on the ninth gallery image while the catalog is closed.
local P={}
local meter="GalleryArt9"
local route={{14,0},{21,7},{21,16},{14,23},{4,23},{-3,16},{-3,7},{4,0}}
local id,atlas,active,paused,actorName,layout
local clip,elapsed,frame,hold,leg,x,y,step,lastX,lastY,ground,jumping
local shownX,shownY,shownFrame,actionCount

local function set(option,value) SKIN:Bang("!SetOption",meter,option,tostring(value)) end
local function startClip(name)
    if name~=clip then clip,elapsed,frame=name,0,1 end
end
local function facing(dx,dy)
    return (dy<0 and "N" or dy>0 and "S" or "")..(dx<0 and "W" or dx>0 and "E" or "")
end
local function sign(v) return v>0 and 1 or v<0 and -1 or 0 end
function P.active() return active end

local function refresh()
    local visible=id=="kirby" and not paused and SKIN:GetMeter(actorName) and SKIN:GetMeter(meter)
    if visible and not active then
        active=true
        x,y,leg,hold,step,actionCount=4,0,1,1200,0,0
        shownX,shownY,shownFrame,lastX,lastY,ground,jumping=nil,nil,nil,nil,nil,nil,false
        clip=nil;startClip("idle")
        set("ImageName",atlas);set("W",M.petMotion.width);set("H",M.petMotion.height)
        set("ImageFlip","None");set("Greyscale",0);set("ImageAlpha",255)
        set("ToolTipText","");set("LeftMouseUpAction","[!CommandMeasure AvatarUnlocks PetInteract()]")
        P.tick(0)
        SKIN:Bang("!ShowMeter",meter);SKIN:Bang("!UpdateMeter",meter);SKIN:Bang("!Redraw")
    elseif active and not visible then
        active=false
        layout.petEdge(0)
        set("LeftMouseUpAction","");set("ToolTipText","")
        set("ImageName","");set("ImageCrop","");set("W",64);set("H",64)
        SKIN:Bang("!HideMeter",meter);SKIN:Bang("!UpdateMeter",meter);SKIN:Bang("!Redraw")
    end
end
function P.select(nextId,actor,cache,resources,follower)
    actorName,layout=actor,follower
    id=nextId=="kirby" and nextId or nil
    if id and not atlas then atlas=M.imageFile(cache,"unlock-kirby",M.petAtlas,resources.."unlock-kirby.png") end
    refresh()
end
function P.panel(open) paused=open;refresh() end
function P.interact()
    if not active then return end
    actionCount=actionCount+1
    clip=nil;startClip(actionCount%2==1 and "inhale" or "jump")
end
function P.tick(ms)
    if not active then return end
    local actor=SKIN:GetMeter(actorName)
    if not actor then return end
    local wx=tonumber(SKIN:GetVariable("CURRENTCONFIGX")) or 0
    local wy=tonumber(SKIN:GetVariable("CURRENTCONFIGY")) or 0
    local dx,dy=wx-(lastX or wx),wy-(lastY or wy)
    lastX,lastY=wx,wy
    local actorJump=SKIN:GetVariable("Pose")=="jump"
    if actorJump and not jumping then startClip("jump") end
    jumping=actorJump
    if not ground or not actorJump then ground=actor:GetY()+actor:GetH()-3 end
    if not actorJump and (dx~=0 or dy~=0) then startClip("walk-"..facing(dx,dy)) end
    if clip~="inhale" and clip~="jump" then
        if dx~=0 or dy~=0 then
            startClip("walk-"..facing(dx,dy));hold=600
        elseif hold>0 then
            startClip("idle");hold=math.max(0,hold-ms)
        else
            local target=route[leg]
            local sx,sy=sign(target[1]-x),sign(target[2]-y)
            if sx~=0 or sy~=0 then
                startClip("walk-"..facing(sx,sy))
                step=step+ms
                if step>=75 then x,y=x+sx,y+sy;step=step%75 end
            else
                if leg==4 then startClip("inhale") elseif leg==8 then startClip("jump") else startClip("idle") end
                hold=550;leg=leg%#route+1
            end
        end
    end
    local motion=M.petMotion
    local c=motion.clips[clip]
    elapsed=elapsed+ms
    while elapsed>=c.ms[frame] do
        elapsed=elapsed-c.ms[frame]
        frame=frame+1
        if frame>#c.ms then
            if clip=="inhale" or clip=="jump" then startClip("idle");hold=800;c=motion.clips.idle
            else frame=1 end
        end
    end
    local index=c.start+frame-1
    -- The full patrol stays beyond both companions even when the large one turns.
    local edge=math.max(actor:GetX()+actor:GetW(),layout.companionRight())
    local left=math.max(0,edge-4+x)
    local top=math.max(0,ground-motion.ground-7+y)
    layout.petEdge(edge+motion.width+21)
    if index==shownFrame and left==shownX and top==shownY then return end
    if index~=shownFrame then
        set("ImageCrop",string.format("%d,%d,%d,%d",index%motion.columns*motion.width,math.floor(index/motion.columns)*motion.height,motion.width,motion.height))
    end
    if left~=shownX then set("X",left) end
    if top~=shownY then set("Y",top) end
    shownFrame,shownX,shownY=index,left,top
    SKIN:Bang("!UpdateMeter",meter);SKIN:Bang("!Redraw")
end
return P
