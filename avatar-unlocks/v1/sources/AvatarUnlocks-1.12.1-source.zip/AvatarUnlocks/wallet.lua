-- One immutable event grants the item and deducts its cost together.
-- Windows rename publishes a fully closed receipt only if its ordinal is still free.
M.powderPerXp=5
function M.applyPowderRules(doc)
    if type(doc)~="table" or doc.schema~=1 or type(doc.revision)~="number" or
       doc.revision~=math.floor(doc.revision) or doc.revision<1 or doc.revision>2147483647 or
       doc.revision<=(M.powderRevision or 0) then return false end
    local rate=doc.powderPerXp
    if type(rate)~="number" or rate~=math.floor(rate) or rate<0 or rate>999 then return false end
    M.powderPerXp,M.powderRevision=rate,doc.revision
    return true
end

function M.powderAward(xp,rate)
    return xp*(rate or M.powderPerXp)
end

function M.attachWallet(session,prefix,pending)
    local wallet={xp=0,powder=0,stones={},forms={},sequence=0}
    session.wallet=wallet
    local function nextPath()
        return prefix.."wallet-"..string.format("%09d",wallet.sequence+1)..".txn"
    end
    local function earnedBalance(total,rate)
        if total<=wallet.xp or total>900719925474099 or rate<0 or rate>999 then return nil end
        local amount=M.powderAward(total-wallet.xp,rate)
        if amount>9007199254740991-wallet.powder then return nil end
        return wallet.powder+amount
    end
    local function apply(record)
        local xp=tonumber(record:match("^X (%d+)\n$"))
        local rate=5 -- Older X receipts always paid five per XP.
        if not xp then
            local total,saved=record:match("^X (%d+) (%d+)\n$")
            xp,rate=tonumber(total),tonumber(saved)
        end
        local balance=xp and earnedBalance(xp,rate)
        local crafted=record:match("^C ([a-z]+)\n$")
        local form,stone,cost=record:match("^E ([a-z0-9_-]+) ([a-z]+) (%d+)\n$")
        cost=tonumber(cost)
        if balance then
            wallet.powder=balance
            wallet.xp=xp
        elseif crafted and M.stoneNames[crafted] and wallet.powder>=30 then
            wallet.powder=wallet.powder-30
            wallet.stones[crafted]=(wallet.stones[crafted] or 0)+1
        elseif form and cost and cost>0 and (wallet.stones[stone] or 0)>=cost and not wallet.forms[form] then
            wallet.stones[stone]=wallet.stones[stone]-cost
            wallet.forms[form]=true
        else
            wallet.error="invalid receipt"
            return false
        end
        wallet.sequence=wallet.sequence+1
        return true
    end
    function session:readWallet()
        while not wallet.error do
            local file=io.open(nextPath(),"rb")
            if not file then return true end
            local record=file:read(128)
            local extra=file:read(1)
            file:close()
            if not record or extra or not apply(record) then wallet.error="invalid receipt";break end
        end
        return false
    end
    local function transact(makeRecord)
        for attempt=1,8 do
            if not session:readWallet() then return false end
            local record=makeRecord()
            if not record then return false end
            local path=nextPath()
            local file=io.open(pending,"wb")
            if not file then return false end
            local written=file:write(record)
            local closed=file:close()
            if written and closed and os.rename(pending,path) then return apply(record) end
            os.remove(pending)
            local winner=io.open(path,"rb")
            if not winner then return false end
            winner:close()
        end
        return false
    end
    function session:earn(total)
        if not total or total<0 or total~=math.floor(total) or total>900719925474099 then return false end
        return transact(function()
            local rate=M.powderPerXp
            if not earnedBalance(total,rate) then return nil end
            if rate==5 then return string.format("X %.0f\n",total) end
            return string.format("X %.0f %d\n",total,rate)
        end)
    end
    function session:craft(stone)
        return transact(function()
            if M.stoneNames[stone] and wallet.powder>=30 then return "C "..stone.."\n" end
        end)
    end
    function session:evolve(target)
        return transact(function()
            local rule=M.evolutions[target]
            if rule and self:owns(rule.parent) and not self:owns(target) and (wallet.stones[rule.stone] or 0)>=rule.cost then
                return string.format("E %s %s %d\n",target,rule.stone,rule.cost)
            end
        end)
    end
    session:readWallet()
end
