-- Only roots of evolution trees, pets and outfits are eligible for level rewards.
M.levelKinds={}
M.familyLevels={}
for _,item in ipairs(M.gallery) do
    if item.kind~="pokemon" or not M.evolutions[item.id] then M.levelKinds[item.id]=item.kind end
end

function M.applyLevelRules(doc)
    if type(doc)~="table" or doc.schema~=1 or type(doc.revision)~="number" or
       doc.revision~=math.floor(doc.revision) or doc.revision<1 or doc.revision>2147483647 or
       type(doc.levels)~="table" or doc.revision<=(M.levelRevision or 0) then return false end
    local values={}
    for id,n in pairs(doc.levels) do
        if type(id)~="string" or not id:match("^[a-z0-9_-]+$") or #id>48 or
           type(n)~="number" or n~=math.floor(n) or n<1 or n>999 then return false end
        if M.levelKinds[id] then
            if M.levelKinds[id]=="pokemon" and n>20 then return false end
            values[id]=n
        elseif M.evolutions[id] then return false end
    end
    M.familyLevels,M.levelRevision=values,doc.revision
    return true
end

function M.withFamilyLevels(items)
    if not next(M.familyLevels) then return items end
    local result,found={},{}
    for _,item in ipairs(items) do
        local n=M.familyLevels[item.id]
        result[#result+1]=n and {id=item.id,kind=item.kind,level=n,name=item.name} or item
        found[item.id]=true
    end
    for id,n in pairs(M.familyLevels) do
        if not found[id] then result[#result+1]={id=id,kind=M.levelKinds[id],level=n} end
    end
    return result
end

