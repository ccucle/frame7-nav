local costHelper, costCache, costDecode
local nextCostRead,nextCostFetch,lastCostFetch=0,0,0

local function writeAsset(path,bytes)
    local f=io.open(path,"rb")
    if f then
        local same=f:read("*a")==bytes
        f:close()
        if same then return true end
    end
    local tmp=path.."."..tostring({}):gsub("[^%w]","")..".tmp"
    f=io.open(tmp,"wb")
    if not f then return false end
    local ok=f:write(bytes)
    local closed=f:close()
    if ok and closed and os.rename(tmp,path) then return true end
    os.remove(tmp)
    f=io.open(path,"rb")
    if not f then return false end
    local same=f:read("*a")==bytes
    f:close()
    return same
end

local function familyEnabled()
    return engine.isFamilyAvatar(SKIN:GetVariable("UnlockAvatar")) or exists(shared.."family-evolution.enabled")
end
local function launchCosts(mode)
    if not costHelper then return end
    local path=shared.."evolution-"..engine.version
    if not writeAsset(path..".ps1","\239\187\191"..engine.costScript) or
       not writeAsset(path..".json",engine.costRoutes) or
       not writeAsset(path..".levels.json",engine.levelItems) then return end
    local exe=os.getenv("SystemRoot").."\\System32\\WindowsPowerShell\\v1.0\\powershell.exe"
    SKIN:Bang('["'..exe..'" -NoProfile -NonInteractive -STA -ExecutionPolicy RemoteSigned -WindowStyle Hidden -File "'..path..'.ps1" -Mode '..mode..(engine.isFamilyAvatar(SKIN:GetVariable("UnlockAvatar")) and " -FamilyAvatar" or "")..']')
    return true
end

local function readFamilyFile(path,tag,apply)
    local f=io.open(path,"rb")
    if not f then return false end
    local s=f:read(65537)
    f:close()
    if not s or #s>65536 or s==costHelper[tag] then return false end
    costHelper[tag]=s
    local ok,doc=pcall(costDecode,s)
    return ok and apply(doc)
end

local function refreshCosts()
    if not costCache or not familyEnabled() then return false end
    local changed=readFamilyFile(costCache,"costs",engine.applyCostRules)
    readFamilyFile(shared.."family-unlock-levels.json","levels",engine.applyLevelRules)
    readFamilyFile(shared.."family-powder.json","powder",engine.applyPowderRules)
    if changed and gallery then gallery.refresh() end
    return changed
end

local function pollCosts(opening)
    local now=os.time()
    if now>=nextCostRead then nextCostRead=now+2;refreshCosts() end
    if familyEnabled() and (now>=nextCostFetch or (opening and now>=lastCostFetch+20)) then
        lastCostFetch=now
        local launched=launchCosts("Sync")
        nextCostFetch=now+(not launched and 5 or engine.levelRevision and engine.powderRevision and 120 or 30)
    end
end

function OpenCostEditor()
    if panelOpen and not showingUpdates then launchCosts("Editor") end
end

