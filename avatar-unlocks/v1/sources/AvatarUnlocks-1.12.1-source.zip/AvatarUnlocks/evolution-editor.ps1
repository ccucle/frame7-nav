param([ValidateSet('Editor','Sync','Library')][string]$Mode='Editor',[switch]$FamilyAvatar)
$ErrorActionPreference='Stop'
$apiRoot='https://api.github.com/repos/ccucle/frame7-nav/contents/'
$familyFiles=@{Costs='rules.json';Levels='levels.json';Powder='powder.json'}
$powderCache=Join-Path $PSScriptRoot 'family-powder.json'
$levelCache=Join-Path $PSScriptRoot 'family-unlock-levels.json'
$rulesBranch='formday-family-evolution'
$cache=Join-Path $PSScriptRoot 'family-evolution.json'
$familyLink=Join-Path $PSScriptRoot 'family-evolution.enabled'
$utf8=[Text.UTF8Encoding]::new($false)
$ProgressPreference='SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12

function Test-Count($value) {
    ($value -is [int] -or $value -is [long]) -and $value -ge 1 -and $value -le 999
}
function Convert-Rules($value) {
    if ($value.schema -ne 1 -or $value.revision -isnot [int] -and $value.revision -isnot [long] -or
        $value.revision -lt 1 -or $value.revision -gt 2147483647 -or
        !(Test-Count $value.first) -or !(Test-Count $value.second) -or $value.overrides -isnot [pscustomobject]) {
        throw '진화 규칙 파일 형식을 확인해 주세요.'
    }
    $entries=@{}
    foreach ($p in $value.overrides.PSObject.Properties) {
        if ($p.Name -cnotmatch '^[a-z0-9_-]{1,48}/[a-z0-9_-]{1,48}$' -or !(Test-Count $p.Value)) {throw '잘못된 진화 경로 또는 비용입니다.'}
        $entries[$p.Name]=[int]$p.Value
    }
    [ordered]@{schema=1;revision=[int]$value.revision;first=[int]$value.first;second=[int]$value.second;overrides=$entries}
}
function Copy-Rules($rules) {Convert-Rules (ConvertFrom-Json (ConvertTo-Json $rules -Depth 5 -Compress))}
function Get-Cost($rules,$route) {
    if ($rules.overrides.ContainsKey($route.edge)) {return $rules.overrides[$route.edge]}
    if ($route.stage -eq 1) {return $rules.first}
    $rules.second
}
function Get-Changes($before,$after,$routes) {
    foreach ($r in $routes) {
        $old=Get-Cost $before $r
        $new=Get-Cost $after $r
        if ($old -ne $new -or $before.overrides.ContainsKey($r.edge) -ne $after.overrides.ContainsKey($r.edge)) {
            [pscustomobject]@{route=$r;old=$old;new=$new;custom=$after.overrides.ContainsKey($r.edge)}
        }
    }
}
function Find-Routes($routes,[string]$query) {
    $q=$query.Trim().TrimStart('#')
    if (!$q) {return $routes}
    $families=@{}
    foreach ($r in $routes) {
        if ($q -match '^\d+$') {
            if ($q.TrimStart('0') -in @([string]$r.dex,[string]$r.parentDex)) {$families[$r.family]=1}
        } elseif (($r.name,$r.parentName,$r.id,$r.parent -join ' ').IndexOf($q,[StringComparison]::OrdinalIgnoreCase) -ge 0) {$families[$r.family]=1}
    }
    $routes | Where-Object {$families.ContainsKey($_.family)}
}
function Convert-LevelRules($value) {
    if ($value.schema -ne 1 -or ($value.revision -isnot [int] -and $value.revision -isnot [long]) -or
        $value.revision -lt 1 -or $value.revision -gt 2147483647 -or $value.levels -isnot [pscustomobject]) {throw '해금 레벨 파일 형식 오류'}
    $levels=@{}
    foreach ($pair in $value.levels.PSObject.Properties) {
        if ($pair.Name -cnotmatch '^[a-z0-9_-]{1,48}$' -or !(Test-Count $pair.Value)) {throw '해금 레벨 값 오류'}
        $levels[$pair.Name]=[int]$pair.Value
    }
    [ordered]@{schema=1;revision=[int]$value.revision;levels=$levels}
}
function Convert-FamilyDoc($value,[string]$kind) {
    switch ($kind) {
        Costs {return Convert-Rules $value}
        Levels {return Convert-LevelRules $value}
        Powder {
            $n=$value.powderPerXp
            if ($value.schema -ne 1 -or ($value.revision -isnot [int] -and $value.revision -isnot [long]) -or
                $value.revision -lt 1 -or $value.revision -gt 2147483647 -or ($n -isnot [int] -and $n -isnot [long]) -or
                $n -lt 0 -or $n -gt 999) {throw '스톤파우더 보상 규칙을 확인해 주세요.'}
            return [ordered]@{schema=1;revision=[int]$value.revision;powderPerXp=[int]$n}
        }
        default {throw '알 수 없는 가족 설정입니다.'}
    }
}
function Copy-LevelRules($rules) {Convert-LevelRules (ConvertFrom-Json (ConvertTo-Json $rules -Depth 5 -Compress))}
function Get-LevelLabel($doc,$item) {
    if ($doc.levels.ContainsKey($item.id)) {return ('Lv.'+$doc.levels[$item.id]+' · 개별')}
    if ($item.level) {return ('Lv.'+$item.level+' · 기본')}
    return '지급 레벨 미지정'
}
function Get-LevelSummary {
    if (!$state.levelBase -or !$state.levelDraft) {return}
    foreach ($item in $levelItems) {
        $before=Get-LevelLabel $state.levelBase.rules $item
        $after=Get-LevelLabel $state.levelDraft $item
        if ($before -ne $after) {("$($item.name)   $before → $after")}
    }
}


function Read-Snapshot([ValidateSet('Costs','Levels','Powder')][string]$kind='Costs') {
    $rulesApi=$apiRoot+$familyFiles[$kind]
    $reply=Invoke-RestMethod -UseBasicParsing -TimeoutSec 10 -Headers @{'User-Agent'='Formday-Evolution';'Cache-Control'='no-cache'} -Uri ($rulesApi+'?ref='+$rulesBranch+'&t='+[DateTimeOffset]::UtcNow.ToUnixTimeSeconds())
    if ($reply.sha -cnotmatch '^[a-f0-9]{40}$' -or $reply.size -gt 65536 -or $reply.encoding -ne 'base64') {throw '공유 규칙을 확인할 수 없습니다.'}
    $rules=Convert-FamilyDoc (ConvertFrom-Json ($utf8.GetString([Convert]::FromBase64String($reply.content)))) $kind
    [pscustomobject]@{sha=$reply.sha;rules=$rules}
}
function Set-Cache($rules,[ValidateSet('Costs','Levels','Powder')][string]$kind='Costs') {
    if ($kind -eq 'Levels') {$cache=$levelCache} elseif ($kind -eq 'Powder') {$cache=$powderCache}
    $lock=New-Object Threading.Mutex($false,'Local\FormdayFamilyEvolutionCache')
    $held=$false
    try {
        try {$held=$lock.WaitOne(4500)} catch [Threading.AbandonedMutexException] {$held=$true}
        if (!$held) {throw '도감 동기화가 진행 중입니다.'}
        if ([IO.File]::Exists($cache)) {
            try {$existing=Convert-FamilyDoc (ConvertFrom-Json ([IO.File]::ReadAllText($cache))) $kind
                 if ($existing.revision -ge $rules.revision) {return}} catch {}
        }
        $tmp=$cache+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
        try {
            [IO.File]::WriteAllText($tmp,(ConvertTo-Json $rules -Compress -Depth 5),$utf8)
            if ([IO.File]::Exists($cache)) {[IO.File]::Replace($tmp,$cache,$cache+'.previous')} else {[IO.File]::Move($tmp,$cache)}
        } finally {if ([IO.File]::Exists($tmp)) {[IO.File]::Delete($tmp)}}
    } finally {if ($held) {$lock.ReleaseMutex()};$lock.Dispose()}
}
function Publish-Rules($base,$draft,$credential,[ValidateSet('Costs','Levels','Powder')][string]$kind='Costs') {
    $relPath=$familyFiles[$kind]
    $rulesApi=$apiRoot+$relPath
    if (!(Test-ParentAccount $credential)) {
        if ($credential -is [pscredential] -and (Test-ParentAccount 'GitHubCLI')) {$credential='GitHubCLI'}
        else {throw '저장 권한을 확인할 수 없습니다. PIN 창에서 관리자 계정을 다시 연결해 주세요.'}
    }
    $doc=Convert-FamilyDoc (ConvertFrom-Json (ConvertTo-Json $draft -Depth 5 -Compress)) $kind
    $doc.revision=$base.rules.revision+1
    $body=@{message=('Update family '+$relPath);branch=$rulesBranch;sha=$base.sha
        content=[Convert]::ToBase64String($utf8.GetBytes((ConvertTo-Json $doc -Depth 5 -Compress)))}
    try {
        if ($credential -eq 'GitHubCLI') {
            $json=(ConvertTo-Json $body -Compress) | & $githubCli api --hostname github.com --method PUT ("repos/ccucle/frame7-nav/contents/"+$relPath) --input - 2>&1
            if ($LASTEXITCODE) {
                if (($json -join ' ') -match 'HTTP (409|422)') {throw 'CONFLICT'}
                throw 'GitHub 권한 확인 실패'
            }
            $result=ConvertFrom-Json ($json -join [Environment]::NewLine)
        } else {
            $headers=@{'User-Agent'='Formday-Evolution';Authorization=('Bearer '+$credential.GetNetworkCredential().Password)}
            $result=Invoke-RestMethod -Method Put -Uri $rulesApi -UseBasicParsing -Headers $headers -TimeoutSec 15 -ContentType 'application/json' -Body (ConvertTo-Json $body -Compress)
        }
    } catch {
        if ($_.Exception.Message -eq 'CONFLICT' -or ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -in @(409,422))) {throw '다른 변경이 먼저 저장됐습니다. 새로고침한 뒤 다시 편집해 주세요.'}
        throw '공유 저장을 확인하지 못했습니다. 연결과 편집 권한을 확인한 뒤 새로고침해 주세요.'
    }
    if ($result.content.sha -cnotmatch '^[a-f0-9]{40}$') {throw '저장 결과를 확인하지 못했습니다.'}
    Set-Cache $doc $kind
    [pscustomobject]@{sha=$result.content.sha;rules=$doc}
}
Add-Type -AssemblyName System.Security
$pinFile=Join-Path $PSScriptRoot 'family-editor-pin-v1.json'
$pinScope=[Security.Cryptography.DataProtectionScope]::CurrentUser
function Write-PinState($record) {
    $tmp=$pinFile+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    try {
        [IO.File]::WriteAllText($tmp,(ConvertTo-Json $record -Compress),$utf8)
        if ([IO.File]::Exists($pinFile)) {[IO.File]::Replace($tmp,$pinFile,[NullString]::Value)} else {[IO.File]::Move($tmp,$pinFile)}
    } finally {if ([IO.File]::Exists($tmp)) {[IO.File]::Delete($tmp)}}
}
function Get-PinKey([string]$pin,[byte[]]$salt) {
    $k=[Security.Cryptography.Rfc2898DeriveBytes]::new($pin,$salt,160000,[Security.Cryptography.HashAlgorithmName]::SHA256)
    try {return ,($k.GetBytes(32))} finally {$k.Dispose()}
}
function Access-ParentPin([string]$pin,[string]$registerProvider) {
    if ($pin -cnotmatch '^[0-9]{4}$') {throw '숫자 네 자리를 입력해 주세요.'}
    $guard=[Threading.Mutex]::new($false,'Local\FormdayEvolutionParentPinV1')
    $held=$false;$key=$null
    try {
        try {$held=$guard.WaitOne(5000)} catch [Threading.AbandonedMutexException] {$held=$true}
        if (!$held) {throw '다른 편집 창에서 PIN을 확인 중이에요.'}
        if ($registerProvider) {
            if ($registerProvider -notin 'browser','existing' -or [IO.File]::Exists($pinFile)) {throw 'PIN이 이미 등록됐습니다. 창을 다시 열어 주세요.'}
            $salt=New-Object byte[] 16
            $rng=[Security.Cryptography.RandomNumberGenerator]::Create()
            try {$rng.GetBytes($salt)} finally {$rng.Dispose()}
            $key=Get-PinKey $pin $salt
            $data=[Security.Cryptography.ProtectedData]::Protect($utf8.GetBytes('family-pin-v1/'+$registerProvider),$key,$pinScope)
            Write-PinState @{salt=[Convert]::ToBase64String($salt);proof=[Convert]::ToBase64String($data);tries=0;until=0}
            return $registerProvider
        }
        $disk=ConvertFrom-Json ([IO.File]::ReadAllText($pinFile))
        $now=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        if ($disk.until -gt $now) {throw ('잠시 잠겼어요. 약 '+[math]::Ceiling(($disk.until-$now)/60)+'분 뒤에 다시 입력하세요.')}
        $key=Get-PinKey $pin ([Convert]::FromBase64String($disk.salt))
        try {
            $bytes=[Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($disk.proof),$key,$pinScope)
            $provider=$utf8.GetString($bytes)
        } catch {
            $disk.tries=[int]$disk.tries+1
            if ($disk.tries -ge 5) {$disk.until=$now+300;$disk.tries=0}
            Write-PinState $disk
            if ($disk.until -gt $now) {throw '5회 틀려 5분 동안 잠겼어요.'}
            throw 'PIN이 맞지 않습니다.'
        }
        if ($provider -cnotin 'family-pin-v1/browser','family-pin-v1/existing') {throw '저장된 관리자 연결을 확인할 수 없습니다.'}
        if ($disk.tries -or $disk.until) {$disk.tries=0;$disk.until=0;Write-PinState $disk}
        return $provider.Substring(14)
    } finally {if ($key) {[Array]::Clear($key,0,$key.Length)};if ($held) {$guard.ReleaseMutex()};$guard.Dispose()}
}
function Find-LoginHelper {
    $installed=Join-Path $env:ProgramFiles 'GitHub CLI\gh.exe'
    if ([IO.File]::Exists($installed)) {return $installed}
    $app=Get-Command gh.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($app) {return $app.Source}
    $private=Join-Path $PSScriptRoot 'github-login-2.106.0\gh.exe'
    if ([IO.File]::Exists($private)) {return $private}
}
function Install-LoginHelper {
    $arch=$env:PROCESSOR_ARCHITECTURE
    if ($env:PROCESSOR_ARCHITEW6432) {$arch=$env:PROCESSOR_ARCHITEW6432}
    $packages=@{
      AMD64=@('amd64','d406f442ca0baa3d3e9c695e9cded1aa48e67dad3294b8947e5ab84f980b4844')
      ARM64=@('arm64','6099b15d88eb96b7955050e84bd002432f9572857402d7f342c87cfaeaa83082')
      x86=@('386','de42e53d711a37640120692709693d0f51c461356b3b063d8c1d72220346333f')
    }
    $selected=$packages[$arch]
    if (!$selected) {throw '이 Windows 환경에 맞는 로그인 도구를 찾지 못했습니다.'}
    $folder=Join-Path $PSScriptRoot 'github-login-2.106.0'
    [void][IO.Directory]::CreateDirectory($folder)
    $exe=Join-Path $folder 'gh.exe'
    $tmp=Join-Path $folder ([guid]::NewGuid().ToString('N'))
    $wc=[Net.WebClient]::new()
    try {
        $wc.DownloadFile(('https://github.com/cli/cli/releases/download/v2.106.0/gh_2.106.0_windows_'+$selected[0]+'.zip'),$tmp+'.zip')
        $digest=Get-FileHash -LiteralPath ($tmp+'.zip') -Algorithm SHA256
        if ($digest.Hash -ne $selected[1]) {throw '로그인 도구 파일을 확인할 수 없습니다.'}
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zip=[IO.Compression.ZipFile]::OpenRead($tmp+'.zip')
        try {
            $entries=@($zip.Entries | Where-Object {$_.FullName -match '(^|/)bin/gh\.exe$|^gh\.exe$'})
            if ($entries.Count -ne 1) {throw '로그인 도구 압축 파일을 확인할 수 없습니다.'}
            [IO.Compression.ZipFileExtensions]::ExtractToFile($entries[0],$tmp)
        } finally {$zip.Dispose()}
        try {[IO.File]::Move($tmp,$exe)} catch {if (![IO.File]::Exists($exe)) {throw}}
        return $exe
    } finally {$wc.Dispose();foreach ($path in @($tmp,($tmp+'.zip'))) {if ([IO.File]::Exists($path)) {[IO.File]::Delete($path)}}}
}
function Test-ParentAccount($connection) {
    try {
        if ($connection -eq 'GitHubCLI') {
            if (!$githubCli) {return $false}
            $login=& $githubCli api --hostname github.com user --jq .login 2>$null
            if ($LASTEXITCODE -ne 0 -or $login -ne 'ccucle') {return $false}
            $canWrite=& $githubCli api --hostname github.com repos/ccucle/frame7-nav --jq .permissions.push 2>$null
            return ($LASTEXITCODE -eq 0 -and $canWrite -eq 'true')
        }
        if ($connection -isnot [pscredential]) {return $false}
        $headers=@{Authorization=('Bearer '+$connection.GetNetworkCredential().Password);'User-Agent'='Formday-Evolution'}
        $user=Invoke-RestMethod -UseBasicParsing -TimeoutSec 10 -Uri 'https://api.github.com/user' -Headers $headers
        if ($user.login -ne 'ccucle') {return $false}
        $repo=Invoke-RestMethod -UseBasicParsing -TimeoutSec 10 -Uri 'https://api.github.com/repos/ccucle/frame7-nav' -Headers $headers
        return [bool]$repo.permissions.push
    } catch {return $false}
}


if ($Mode -eq 'Library') {return}
if ($Mode -eq 'Sync') {
    if (!$FamilyAvatar -and ![IO.File]::Exists($familyLink)) {exit 0}
    $failed=$false
    foreach ($kind in 'Levels','Powder','Costs') {
        $file=$familyFiles[$kind]
        try {
            $url='https://raw.githubusercontent.com/ccucle/frame7-nav/'+$rulesBranch+'/'+$file+'?t='+[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
            $result=Invoke-WebRequest -UseBasicParsing -TimeoutSec 10 -Uri $url
            if ($result.RawContentLength -gt 65536) {throw '규칙 파일이 너무 큽니다.'}
            $body=if ($result.Content -is [byte[]]) {$utf8.GetString($result.Content)} else {$result.Content}
            Set-Cache (Convert-FamilyDoc (ConvertFrom-Json $body) $kind) $kind
        } catch {
            try {$snapshot=Read-Snapshot $kind;Set-Cache $snapshot.rules $kind} catch {$failed=$true}
        }
    }
    if ($failed) {exit 1}
    exit 0
}

Add-Type -AssemblyName PresentationFramework
$layout=@'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="해금도감 · 가족 설정" Width="736" Height="556" MinWidth="650" MinHeight="490" WindowStartupLocation="CenterScreen" Background="#FBF9F1" Foreground="#213C35" FontFamily="Malgun Gothic" FontSize="13" UseLayoutRounding="True">
<Window.Resources>
 <Style TargetType="Button"><Setter Property="Background" Value="#F4F5EC"/><Setter Property="Foreground" Value="#264439"/><Setter Property="BorderBrush" Value="#BCCABE"/><Setter Property="Padding" Value="12,7"/><Setter Property="Margin" Value="2"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border Name="B" Padding="{TemplateBinding Padding}" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="1" CornerRadius="5"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center" RecognizesAccessKey="True"/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="B" Property="BorderBrush" Value="#426856"/></Trigger><Trigger Property="IsPressed" Value="True"><Setter TargetName="B" Property="Opacity" Value=".72"/></Trigger><Trigger Property="IsEnabled" Value="False"><Setter TargetName="B" Property="Opacity" Value=".52"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
 <Style TargetType="RadioButton"><Setter Property="GroupName" Value="Section"/><Setter Property="Margin" Value="0,1"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="RadioButton"><Border Name="B" CornerRadius="5" Background="Transparent" Padding="12,8"><ContentPresenter/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="B" Property="Background" Value="#EDF0E6"/></Trigger><Trigger Property="IsChecked" Value="True"><Setter TargetName="B" Property="Background" Value="#D8E6D6"/><Setter Property="Foreground" Value="#204C38"/><Setter Property="FontWeight" Value="Bold"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
 <Style x:Key="GroupTitle" TargetType="TextBlock"><Setter Property="FontSize" Value="12"/><Setter Property="Foreground" Value="#617367"/><Setter Property="FontWeight" Value="Bold"/><Setter Property="Margin" Value="12,13,0,4"/></Style>
 <Style TargetType="TextBox"><Setter Property="Padding" Value="8,5"/><Setter Property="Background" Value="#FFFEFA"/><Setter Property="Foreground" Value="#203D32"/><Setter Property="BorderBrush" Value="#AABBAE"/><Setter Property="VerticalContentAlignment" Value="Center"/></Style>
 <Style TargetType="ListBoxItem"><Setter Property="Padding" Value="8,5"/><Setter Property="HorizontalContentAlignment" Value="Stretch"/></Style>
</Window.Resources>
<DockPanel Background="#FBF9F1">
 <Border DockPanel.Dock="Top" Background="#253F37" Padding="22,13"><DockPanel>
   <Button Name="Admin" DockPanel.Dock="Right" Content="잠그고 닫기" Background="#DDE9D8" VerticalAlignment="Center"/>
   <StackPanel Orientation="Horizontal" VerticalAlignment="Center"><Viewbox Width="29" Height="29" Margin="0,0,12,0"><Canvas Width="16" Height="16"><Path Fill="#F6D18C" Data="M1,4 L7,4 8,5 9,4 15,4 15,13 9,13 8,14 7,13 1,13Z"/><Path Fill="#53775F" Data="M3,6 H6 V7 H3Z M10,6 H13 V7 H10Z M3,9 H6 V10 H3Z M10,9 H13 V10 H10Z"/></Canvas></Viewbox><TextBlock Text="해금도감" Foreground="#FFF7DA" FontSize="20" FontWeight="Bold"/><TextBlock Text="가족 설정" Foreground="#C8D8C8" VerticalAlignment="Center" Margin="12,3,0,0"/></StackPanel>
 </DockPanel></Border>
 <Border DockPanel.Dock="Left" Width="152" Background="#F0F2E7" BorderBrush="#D7DFD2" BorderThickness="0,0,1,0" Padding="8,3"><ScrollViewer VerticalScrollBarVisibility="Auto"><StackPanel>
   <TextBlock Style="{StaticResource GroupTitle}" Text="경험치 보상"/><RadioButton Name="NavPowder" Content="스톤파우더" Tag="0"/>
   <TextBlock Style="{StaticResource GroupTitle}" Text="진화의 돌 비용"/><RadioButton Name="NavDefaults" Content="단계별 기본값" Tag="1"/><RadioButton Name="NavRoutes" Content="개별 진화 경로" Tag="2"/>
   <TextBlock Style="{StaticResource GroupTitle}" Text="해금 레벨"/><RadioButton Name="NavPokemon" Content="포켓몬" Tag="3"/><RadioButton Name="NavPets" Content="펫" Tag="4"/><RadioButton Name="NavOutfits" Content="의상" Tag="5"/>
 </StackPanel></ScrollViewer></Border>
 <DockPanel Margin="22,16,22,14">
  <TextBlock Name="PageTitle" DockPanel.Dock="Top" FontSize="22" FontWeight="Bold" Text="스톤파우더" Margin="0,0,0,12"/>
  <Border DockPanel.Dock="Bottom" BorderBrush="#D4DCCF" BorderThickness="0,1,0,0" Margin="0,13,0,0" Padding="0,9,0,0"><DockPanel>
    <Button Name="Review" Content="변경 확인" DockPanel.Dock="Right" Background="#F5CA76" BorderBrush="#C89C51" FontWeight="Bold"/>
    <Button Name="Reload" Content="새로고침" DockPanel.Dock="Right"/><TextBlock Name="Status" FontSize="12" VerticalAlignment="Center" Foreground="#506755" TextWrapping="Wrap"/>
  </DockPanel></Border>
  <TabControl Name="Tabs" Background="Transparent" BorderThickness="0"><TabControl.Template><ControlTemplate TargetType="TabControl"><ContentPresenter ContentSource="SelectedContent"/></ControlTemplate></TabControl.Template>
   <TabItem Tag="Powder"><ScrollViewer VerticalScrollBarVisibility="Auto"><StackPanel>
    <Border Padding="21,17" CornerRadius="8" Background="#FFFEF9" BorderBrush="#CCD8C9" BorderThickness="1"><StackPanel>
      <TextBlock Text="경험치 1당 지급량" FontWeight="Bold" FontSize="16"/><TextBlock Text="스톤파우더를 0~999개로 정할 수 있어요." Margin="0,5,0,13" Foreground="#526958"/>
      <StackPanel Orientation="Horizontal"><TextBox Name="Powder" MaxLength="3" Width="92" FontSize="26" FontWeight="Bold" HorizontalContentAlignment="Center" AutomationProperties.Name="경험치 1당 스톤파우더 개수"/><TextBlock Text="개" FontSize="16" VerticalAlignment="Center" Margin="9,0"/></StackPanel>
      <Border Background="#EBF1E5" CornerRadius="4" Margin="0,15,0,0" Padding="11,8"><TextBlock Name="Example" TextWrapping="Wrap" Foreground="#315D44"/></Border>
    </StackPanel></Border><TextBlock Text="각 PC가 동기화한 뒤 새로 적립하는 경험치부터 적용합니다." TextWrapping="Wrap" Margin="2,12,2,0" Foreground="#54695B"/>
   </StackPanel></ScrollViewer></TabItem>
   <TabItem Tag="Costs"><ScrollViewer VerticalScrollBarVisibility="Auto"><StackPanel>
    <TextBlock Text="각 단계에 필요한 진화의 돌을 1~999개로 정하세요." Margin="0,0,0,12" TextWrapping="Wrap"/>
    <Border Padding="16" Background="#FFFEF9" BorderBrush="#CCD8C9" BorderThickness="1" CornerRadius="7"><StackPanel>
    <TextBlock Text="기본형 → 1차 진화" FontWeight="Bold"/><TextBox Name="First" MaxLength="3" Width="90" HorizontalAlignment="Left" Margin="0,7,0,15"/>
    <TextBlock Text="1차 진화 → 2차 진화" FontWeight="Bold"/><TextBox Name="Second" MaxLength="3" Width="90" HorizontalAlignment="Left" Margin="0,7,0,0"/>
    </StackPanel></Border><TextBlock Text="개별 비용을 지정한 경로는 그 값을 우선합니다." Margin="0,12,0,0" Foreground="#526958"/>
   </StackPanel></ScrollViewer></TabItem>
   <TabItem Tag="Costs"><DockPanel><StackPanel DockPanel.Dock="Top"><TextBlock Text="포켓몬 이름 또는 도감 번호"/><TextBox Name="Search" Margin="0,5,0,8"/></StackPanel>
   <StackPanel DockPanel.Dock="Bottom" Margin="0,8,0,0"><TextBlock Name="Choice" Margin="0,0,0,4" FontWeight="Bold"/><DockPanel><Button Name="ResetEdge" DockPanel.Dock="Right" Content="기본값 복원"/><Button Name="SetEdge" DockPanel.Dock="Right" Content="개별 지정"/><TextBox Name="EdgeCost" MaxLength="3" VerticalAlignment="Center"/></DockPanel></StackPanel>
   <ListBox Name="Routes" Background="#FFFEF9" BorderBrush="#CAD3C8" ScrollViewer.HorizontalScrollBarVisibility="Disabled"/></DockPanel></TabItem>
  </TabControl>
 </DockPanel>
</DockPanel></Window>
'@
$window=[Windows.Markup.XamlReader]::Parse($layout)
foreach ($n in 'Tabs','Admin','Status','Reload','Review','First','Second','Search','Choice','EdgeCost','SetEdge','ResetEdge','Routes','PageTitle','Powder','Example','NavPowder','NavDefaults','NavRoutes','NavPokemon','NavPets','NavOutfits') {
    Set-Variable -Name $n -Value ($window.FindName($n))
}

$routeFile=[IO.Path]::ChangeExtension($PSCommandPath,'.json')
$allRoutes=ConvertFrom-Json ([IO.File]::ReadAllText($routeFile))
$levelItems=ConvertFrom-Json ([IO.File]::ReadAllText([IO.Path]::ChangeExtension($PSCommandPath,'.levels.json')))
$state=@{base=$null;draft=$null;auth=$null;busy=$false}
function Update-Controls {
    $edit=$null -ne $state.auth -and $null -ne $state.base
    foreach($control in @($First,$Second,$EdgeCost,$SetEdge,$ResetEdge)) {$control.IsEnabled=$edit}
    $levelsEdit=$null -ne $state.auth -and $null -ne $state.levelBase
    foreach ($v in $levelViews.Values) {foreach ($field in 'Assign','Amount','Restore') {$v[$field].IsEnabled=$levelsEdit}}
    $Powder.IsEnabled=$null -ne $state.auth -and $null -ne $state.powderBase
    $Review.IsEnabled=switch ($Tabs.SelectedItem.Tag) {'Powder' {$Powder.IsEnabled} 'Costs' {$edit} default {$levelsEdit}}
}
function Refresh-List {
    $edge=if ($Routes.SelectedItem) {$Routes.SelectedItem.Tag.edge}
    $Routes.Items.Clear()
    foreach ($r in (Find-Routes $allRoutes $Search.Text)) {
        $item=New-Object Windows.Controls.ListBoxItem
        $kind=if ($state.draft.overrides.ContainsKey($r.edge)) {'개별 지정'}else{'기본값'}
        $item.Content=('#{0:0000} {1} → {2}  ·  {3}개  [{4}]' -f [int]$r.dex,$r.parentName,$r.name,(Get-Cost $state.draft $r),$kind)
        $item.Tag=$r
        [void]$Routes.Items.Add($item)
        if ($r.edge -eq $edge) {$Routes.SelectedItem=$item}
    }
    if (!$Routes.SelectedItem -and $Routes.Items.Count) {$Routes.SelectedIndex=0}
    if (!$Routes.Items.Count) {$Choice.Text='일치하는 진화 경로가 없습니다.';$EdgeCost.Clear()}
}
function Show-Draft($doc) {
    $state.busy=$true
    $state.draft=Copy-Rules $doc
    $First.Text=[string]$doc.first;$Second.Text=[string]$doc.second
    $state.busy=$false
    Refresh-List;Update-Controls
}
function Load-Editor {
    try {
        $snap=Read-Snapshot
        if ([IO.File]::Exists($familyLink)) {Set-Cache $snap.rules}
        $state.base=$snap;Show-Draft $snap.rules
        $Status.Text="공유 규칙 $($snap.rules.revision) · 두 PC에 적용되는 설정"
    } catch {
        $state.base=$null
        $doc=Convert-Rules (ConvertFrom-Json '{"schema":1,"revision":1,"first":1,"second":2,"overrides":{}}')
        if (Test-Path -LiteralPath $cache) {try {$doc=Convert-Rules (ConvertFrom-Json ([IO.File]::ReadAllText($cache)))} catch {}}
        Show-Draft $doc;$Status.Text='공유 규칙 연결 대기 · 저장된 비용을 표시합니다.'
    }
    Load-LevelEditor
    try {
        $snapshot=Read-Snapshot Powder
        Set-Cache $snapshot.rules Powder
        $state.powderBase=$snapshot;$rate=$snapshot.rules.powderPerXp
    } catch {
        $state.powderBase=$null;$rate=5
        if ([IO.File]::Exists($powderCache)) {try {$rate=(Convert-FamilyDoc (ConvertFrom-Json ([IO.File]::ReadAllText($powderCache))) Powder).powderPerXp} catch {}}
    }
    $Powder.Text=[string]$rate
    Show-SectionStatus
    Update-Controls
}
function Confirm-Draft {
    if (($state.powderBase -and $Powder.Text -cne [string]$state.powderBase.rules.powderPerXp) -or @(Get-LevelSummary).Count) {
        return [Windows.MessageBox]::Show($window,'저장하지 않은 변경을 버릴까요?','해금도감 설정','YesNo','Question','No') -eq 'Yes'
    }
    if (!$state.draft -or !$state.base) {return $true}
    $b=$state.base.rules
    if ($b.first -eq $state.draft.first -and $b.second -eq $state.draft.second -and
        !(Get-Changes $b $state.draft $allRoutes) -and $First.Text -eq [string]$b.first -and $Second.Text -eq [string]$b.second) {return $true}
    [Windows.MessageBox]::Show($window,'저장하지 않은 변경을 버릴까요?','진화 비용','YesNo','Question','No') -eq 'Yes'
}
function Input-Count([string]$s) {if ($s -cmatch '^[1-9][0-9]{0,2}$') {return [int]$s};return 0}
$Search.Add_TextChanged({if ($state.draft) {Refresh-List}})
$Routes.Add_SelectionChanged({
    if ($Routes.SelectedItem) {$r=$Routes.SelectedItem.Tag;$Choice.Text="$($r.parentName) → $($r.name)  ·  $($r.stone)";$EdgeCost.Text=[string](Get-Cost $state.draft $r)}
})
$changeDefaults={
    if ($state.busy -or !$state.draft) {return}
    $a=Input-Count $First.Text;$b=Input-Count $Second.Text
    if ($a -and $b) {$state.draft.first=$a;$state.draft.second=$b;Refresh-List}
}
$First.Add_TextChanged($changeDefaults);$Second.Add_TextChanged($changeDefaults)
$SetEdge.Add_Click({
    if (!$Routes.SelectedItem) {return}
    $n=Input-Count $EdgeCost.Text
    if (!$n) {$Status.Text='돌 개수는 1~999 사이의 정수로 입력해 주세요.';return}
    $state.draft.overrides[$Routes.SelectedItem.Tag.edge]=$n;Refresh-List
})
$ResetEdge.Add_Click({if ($Routes.SelectedItem) {$state.draft.overrides.Remove($Routes.SelectedItem.Tag.edge);Refresh-List}})
$Reload.Add_Click({if (Confirm-Draft) {Load-Editor}})
$Admin.Add_Click({$window.Close()})
$window.Add_Closing({param($sender,$evt) if (!(Confirm-Draft)) {$evt.Cancel=$true}})

function Open-AdminGate {
    $gate=[Windows.Markup.XamlReader]::Parse(@'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Title="해금도감 · 관리자 PIN" Width="366" SizeToContent="Height" ResizeMode="NoResize" WindowStartupLocation="CenterScreen" Background="#FBF9F1" Foreground="#253F37" FontFamily="Malgun Gothic" FontSize="13" UseLayoutRounding="True">
 <StackPanel><Border Background="#253F37" Padding="20,13"><StackPanel Orientation="Horizontal"><Viewbox Width="21" Height="24" Margin="0,0,10,0"><Canvas Width="16" Height="20"><Path Fill="#F4CF88" Data="M4,8 V5 L6,2 H10 L12,5 V8 H14 V18 H2 V8 Z M6,8 H10 V5 L9,4 H7 L6,5 Z M7,12 V15 H9 V12 Z"/></Canvas></Viewbox><TextBlock Text="해금도감" Foreground="#FFF6DA" FontSize="17" FontWeight="Bold"/></StackPanel></Border>
 <StackPanel Margin="20,16,20,14"><TextBlock Name="Heading" FontSize="20" FontWeight="Bold"/><TextBlock Name="Hint" TextWrapping="Wrap" Margin="0,5,0,10" Foreground="#536B59"/>
 <PasswordBox Name="Pin" AutomationProperties.Name="관리자 PIN" MaxLength="4" FontSize="22" Padding="10,5" BorderBrush="#839D89"/>
 <StackPanel Name="Repeat"><TextBlock Text="PIN 확인" Margin="0,9,0,4"/><PasswordBox Name="Again" MaxLength="4" FontSize="22" Padding="10,5" BorderBrush="#839D89"/></StackPanel>
 <CheckBox Name="Reconnect" Content="관리자 계정 다시 연결" Margin="0,9,0,0"/>
 <TextBlock Name="Message" TextWrapping="Wrap" Foreground="#864F2F" Margin="0,6,0,5"/>
 <Button Name="Accept" IsDefault="True" FontWeight="Bold" Background="#F3CB7F" BorderBrush="#BE9656" Padding="10,7"/>
 <Button Name="Family" Content="이 PC에서 가족 규칙 받기" ToolTip="연결하면 해금도감이 가족 설정을 자동으로 받습니다." Background="#EFF3E9" BorderBrush="#BECCBE" Padding="8,5" Margin="0,8,0,0"/>
 </StackPanel></StackPanel></Window>
'@)
    $registered=[IO.File]::Exists($pinFile)
    $pin=$gate.FindName('Pin');$again=$gate.FindName('Again')
    $accept=$gate.FindName('Accept');$message=$gate.FindName('Message')
    $reconnect=$gate.FindName('Reconnect');$family=$gate.FindName('Family')
    if ($registered) {
        $gate.FindName('Heading').Text='관리자 PIN'
        $gate.FindName('Hint').Text='네 자리를 입력하면 가족 설정이 열립니다.'
        $gate.FindName('Repeat').Visibility='Collapsed';$accept.Content='편집기 열기'
    } else {
        $gate.FindName('Heading').Text='관리자 PIN 등록'
        $gate.FindName('Hint').Text='재한 PC에서 사용할 숫자 네 자리를 정하세요. 처음 한 번 관리자 계정을 확인합니다.'
        $reconnect.Visibility='Collapsed';$accept.Content='계정 확인 후 PIN 등록'
    }
    if ($FamilyAvatar -or [IO.File]::Exists($familyLink)) {$family.Visibility='Collapsed'}
    $family.Add_Click({
        try {
            [IO.File]::WriteAllText($familyLink,'1');$family.Visibility='Collapsed'
            $message.Text='연결됐습니다. 창을 닫아도 이 PC에 가족 규칙이 반영됩니다.'
        } catch {$message.Text='가족 연결을 저장하지 못했습니다.'}
    })
    $credentialFile=Join-Path $PSScriptRoot 'family-editor-current-user.xml'
    $script:githubCli=Find-LoginHelper
    $flow=@{process=$null;auth=$null}
    $watch=[Windows.Threading.DispatcherTimer]::new();$watch.Interval=[TimeSpan]::FromMilliseconds(400)
    function Complete-Admission($credential,[string]$provider) {
        if (!$registered) {[void](Access-ParentPin $pin.Password $provider)}
        [IO.File]::WriteAllText($familyLink,'1')
        $flow.auth=$credential;$gate.DialogResult=$true
    }
    $watch.Add_Tick({
        if (!$flow.process -or !$flow.process.HasExited) {return}
        $watch.Stop();$code=$flow.process.ExitCode;$flow.process.Dispose();$flow.process=$null
        $pin.IsEnabled=$true;$again.IsEnabled=$true;$accept.IsEnabled=$true
        try {
            if ($code -ne 0 -or !(Test-ParentAccount 'GitHubCLI')) {throw 'ccucle 계정의 인증이 완료되지 않았습니다.'}
            Complete-Admission 'GitHubCLI' 'browser'
        } catch {$message.Text=$_.Exception.Message}
    })
    $accept.Add_Click({
        try {
            if ($pin.Password -cnotmatch '^[0-9]{4}$') {throw '숫자 네 자리를 입력해 주세요.'}
            if (!$registered -and $pin.Password -cne $again.Password) {throw '두 PIN이 일치하지 않습니다.'}
            $old=$null
            if ([IO.File]::Exists($credentialFile)) {
                try {$old=Import-Clixml -LiteralPath $credentialFile} catch {}
            }
            if ($registered) {
                try {$provider=Access-ParentPin $pin.Password ''} catch {$pin.Clear();[void]$pin.Focus();throw}
                if (!$reconnect.IsChecked) {
                    if ($provider -eq 'existing' -and $old) {Complete-Admission $old $provider}
                    else {Complete-Admission 'GitHubCLI' $provider}
                    return
                }
            } elseif ($old -and (Test-ParentAccount $old)) {Complete-Admission $old 'existing';return}
            if ($githubCli -and (Test-ParentAccount 'GitHubCLI')) {Complete-Admission 'GitHubCLI' 'browser';return}
            if (!$githubCli) {
                $gate.Cursor=[Windows.Input.Cursors]::Wait
                try {$script:githubCli=Install-LoginHelper} finally {$gate.Cursor=$null}
            }
            $flow.process=Start-Process -FilePath $githubCli -ArgumentList 'auth','login','--hostname','github.com','--web','--git-protocol','https' -WindowStyle Normal -PassThru
            $pin.IsEnabled=$false;$again.IsEnabled=$false;$accept.IsEnabled=$false
            $message.Text='열린 브라우저에서 ccucle 계정으로 승인해 주세요.';$watch.Start()
        } catch {$message.Text=$_.Exception.Message}
    })
    $gate.Add_ContentRendered({[void]$pin.Focus()})
    try {
        if ($gate.ShowDialog() -ne $true -or !$flow.auth) {return $false}
        $state.auth=$flow.auth
        return $true
    } finally {
        $watch.Stop();if ($flow.process) {$flow.process.Dispose()}
        $pin.Clear();$again.Clear()
    }
}



$titles=@{pokemon='포켓몬';pet='펫';outfit='의상'}
$levelViews=@{}
foreach ($kind in 'pokemon','pet','outfit') {
    $tab=[Windows.Markup.XamlReader]::Parse('<TabItem xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"><DockPanel><StackPanel DockPanel.Dock="Top"><TextBlock Name="Legend" TextWrapping="Wrap" Margin="0,2,0,6"/><TextBox Name="Filter" Margin="0,0,0,6" ToolTip="이름 또는 도감 번호 검색"/></StackPanel><StackPanel DockPanel.Dock="Bottom" Margin="0,8,0,2"><TextBlock Name="Selected" Margin="0,0,0,5"/><DockPanel><Button Name="Restore" DockPanel.Dock="Right" Content="기본값 복원"/><Button Name="Assign" DockPanel.Dock="Right" Content="레벨 지정"/><TextBox Name="Amount" MaxLength="3" ToolTip="해금 레벨"/></DockPanel></StackPanel><ListBox Name="Items" Background="#FFFEF9" BorderBrush="#CAD3C8" ScrollViewer.HorizontalScrollBarVisibility="Disabled"/></DockPanel></TabItem>')
    $tab.Header=$titles[$kind]+' 레벨';$tab.Tag=$kind
    $v=@{}
    foreach ($name in 'Legend','Filter','Selected','Amount','Restore','Assign','Items') {$v[$name]=$tab.FindName($name);$v[$name].Tag=$kind}
    $v.Legend.Text=if ($kind -eq 'pokemon') {"기본형·단일형 · Lv.1~20`n이름 또는 도감 번호 검색"} else {"Lv.1~999 · 카드 전용 항목은 보유만 해금됩니다.`n이름 검색"}
    $levelViews[$kind]=$v;[void]$Tabs.Items.Add($tab)
}
function Refresh-LevelList($kind) {
    if (!$state.levelDraft) {return}
    $v=$levelViews[$kind];$selected=if ($v.Items.SelectedItem) {$v.Items.SelectedItem.Tag.id}
    $v.Items.Items.Clear();$q=$v.Filter.Text.Trim().TrimStart('#')
    foreach ($entry in $levelItems) {
        if ($entry.kind -ne $kind) {continue}
        if ($q -and $entry.name.IndexOf($q,[StringComparison]::OrdinalIgnoreCase) -lt 0 -and
            $entry.id.IndexOf($q,[StringComparison]::OrdinalIgnoreCase) -lt 0 -and
            (!$entry.dex -or [string]$entry.dex -ne $q.TrimStart('0'))) {continue}
        $row=[Windows.Controls.ListBoxItem]::new();$row.Tag=$entry
        $number=if ($entry.dex) {'#{0:0000} ' -f [int]$entry.dex} else {''}
        $availability=if ($entry.cardOnly) {' · 카드 전용'} else {''}
        $row.Content=$number+$entry.name+'   '+(Get-LevelLabel $state.levelDraft $entry)+$availability
        [void]$v.Items.Items.Add($row);if ($entry.id -eq $selected) {$v.Items.SelectedItem=$row}
    }
    if ($v.Items.Items.Count -and !$v.Items.SelectedItem) {$v.Items.SelectedIndex=0}
    if ($v.Items.SelectedItem) {$v.Items.ScrollIntoView($v.Items.SelectedItem)}
    if (!$v.Items.SelectedItem) {$v.Selected.Text='검색 결과 없음';$v.Amount.Clear()}
}
function Load-LevelEditor {
    try {$snapshot=Read-Snapshot Levels;if ([IO.File]::Exists($familyLink)) {Set-Cache $snapshot.rules Levels};$state.levelBase=$snapshot;$doc=$snapshot.rules}
    catch {
        $state.levelBase=$null;$doc=@{schema=1;revision=1;levels=@{}}
        if ([IO.File]::Exists($levelCache)) {try {$doc=Convert-LevelRules (ConvertFrom-Json ([IO.File]::ReadAllText($levelCache)))} catch {}}
    }
    $state.levelDraft=Copy-LevelRules $doc
    foreach ($k in $levelViews.Keys) {Refresh-LevelList $k}
    Update-Controls
}
foreach ($view in $levelViews.Values) {
    $view.Filter.Add_TextChanged({param($sender,$eventArgs) Refresh-LevelList $sender.Tag})
    $view.Items.Add_SelectionChanged({
        param($sender,$eventArgs)
        if (!$sender.SelectedItem) {return}
        $v=$levelViews[$sender.Tag];$item=$sender.SelectedItem.Tag
        $v.Selected.Text=$item.name+' · '+(Get-LevelLabel $state.levelDraft $item)
        $v.Amount.Text=if ($state.levelDraft.levels.ContainsKey($item.id)) {[string]$state.levelDraft.levels[$item.id]} else {[string]$item.level}
    })
    $view.Restore.Add_Click({
        param($sender,$eventArgs)
        $v=$levelViews[$sender.Tag];if (!$state.auth -or !$state.levelBase -or !$v.Items.SelectedItem) {return}
        $state.levelDraft.levels.Remove($v.Items.SelectedItem.Tag.id);Refresh-LevelList $sender.Tag
    })
    $view.Assign.Add_Click({
        param($sender,$eventArgs)
        $v=$levelViews[$sender.Tag];if (!$state.auth -or !$state.levelBase -or !$v.Items.SelectedItem) {return}
        $n=Input-Count $v.Amount.Text;$max=if ($sender.Tag -eq 'pokemon') {20} else {999}
        if (!$n -or $n -gt $max) {$Status.Text="1~$max 사이의 레벨을 입력해 주세요.";return}
        $state.levelDraft.levels[$v.Items.SelectedItem.Tag.id]=$n;Refresh-LevelList $sender.Tag
    })
}
function Show-SectionStatus {
    $kind=$Tabs.SelectedItem.Tag
    $base=switch ($kind) {'Powder' {$state.powderBase} 'Costs' {$state.base} default {$state.levelBase}}
    $Status.Text=if ($base) {'가족 규칙 연결됨'} else {'오프라인 · 최근 설정 표시'}
}
foreach ($nav in @($NavPowder,$NavDefaults,$NavRoutes,$NavPokemon,$NavPets,$NavOutfits)) {
    $nav.Add_Checked({param($sender,$evt)
        $Tabs.SelectedIndex=[int]$sender.Tag
        $PageTitle.Text=[string]$sender.Content
        Update-Controls;Show-SectionStatus
    })
}
$Tabs.Add_SelectionChanged({param($sender,$evt)
    if ($evt.Source -eq $Tabs -and $Tabs.SelectedIndex -ge 0) {
        $buttons=@($NavPowder,$NavDefaults,$NavRoutes,$NavPokemon,$NavPets,$NavOutfits)
        $buttons[$Tabs.SelectedIndex].IsChecked=$true
    }
})
function Get-PowderInput {
    if ($Powder.Text -cmatch '^(0|[1-9][0-9]{0,2})$') {return [int]$Powder.Text}
}
$Powder.Add_TextChanged({
    $n=Get-PowderInput
    $Example.Text=if ($null -eq $n) {'0~999 사이의 정수를 입력하세요.'} else {"경험치 10을 얻으면 스톤파우더 $($n*10)개"}
})

$Review.Add_Click({
    if (!$state.auth) {return}
    $kind=$Tabs.SelectedItem.Tag
    $levelMode=$kind -in 'pokemon','pet','outfit'
    if ($kind -eq 'Powder') {
        if (!$state.powderBase) {return}
        $n=Get-PowderInput
        if ($null -eq $n) {$Status.Text='0~999 사이의 정수를 입력해 주세요.';return}
        $old=$state.powderBase.rules.powderPerXp
        if ($old -eq $n) {$Status.Text='스톤파우더 지급량이 그대로입니다.';return}
        $summary=@("경험치 1당 스톤파우더   $old → $n개", "각 PC가 동기화한 뒤 새로 적립하는 경험치부터 적용합니다.")
    } elseif ($levelMode) {
        if (!$state.levelBase) {return}
        $changes=@(Get-LevelSummary)
        if (!$changes.Count) {$Status.Text='변경된 해금 레벨이 없습니다.';return}
        $summary=@("해금 레벨 변경 · $($changes.Count)개")+$changes
    } else {
    if (!$state.base) {return}
    if (!(Input-Count $First.Text) -or !(Input-Count $Second.Text)) {$Status.Text='기본값은 1~999 사이의 정수여야 합니다.';return}
    $b=$state.base.rules;$d=$state.draft
    $diff=@(Get-Changes $b $d $allRoutes)
    $summary=@()
    if ($d.first -ne $b.first) {$summary+="첫 번째 진화 기본값   $($b.first) → $($d.first)개"}
    if ($d.second -ne $b.second) {$summary+="두 번째 진화 기본값   $($b.second) → $($d.second)개"}
    if (!$diff.Count -and !$summary.Count) {$Status.Text='변경된 규칙이 없습니다.';return}
    $summary+="변경 경로 $($diff.Count)개"
    foreach ($c in $diff) {
        $routeKind=if ($c.custom) {'개별 지정'}else{'기본값'}
        $summary+="$($c.route.parentName) → $($c.route.name)   $($c.old) → $($c.new)개 · $routeKind"
    }
    }
    $preview=[Windows.Markup.XamlReader]::Parse(@'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Title="변경 확인" Width="440" Height="346" MinWidth="390" MinHeight="255" Background="#FBF9F1" FontFamily="Malgun Gothic" FontSize="13" WindowStartupLocation="CenterOwner"><DockPanel Margin="18">
<TextBlock DockPanel.Dock="Top" Text="두 PC에 적용할 변경" FontWeight="Bold" FontSize="19" Foreground="#253F37" Margin="0,0,0,12"/>
<StackPanel DockPanel.Dock="Bottom" Orientation="Horizontal" HorizontalAlignment="Right" Margin="0,12,0,0"><Button Content="돌아가기" IsCancel="True" IsDefault="True" Padding="12,6"/><Button Name="Apply" Content="두 PC에 적용" Padding="12,6" Margin="6,0,0,0" Background="#F5CA76" BorderBrush="#C89C51" FontWeight="Bold"/></StackPanel>
<ListBox Name="Summary" Background="#FFFEF9" BorderBrush="#CAD3C8" Padding="6" ScrollViewer.HorizontalScrollBarVisibility="Disabled"><ListBox.ItemTemplate><DataTemplate><TextBlock Text="{Binding}" TextWrapping="Wrap" Padding="2,4"/></DataTemplate></ListBox.ItemTemplate></ListBox></DockPanel></Window>
'@)
    $preview.Owner=$window;$preview.FindName('Summary').ItemsSource=$summary
    $preview.FindName('Apply').Add_Click({$preview.DialogResult=$true})
    if ($preview.ShowDialog() -ne $true) {return}
    try {
        if ($kind -eq 'Powder') {
            $draft=@{schema=1;revision=$state.powderBase.rules.revision;powderPerXp=$n}
            $state.powderBase=Publish-Rules $state.powderBase $draft $state.auth Powder
            $Status.Text="보상 저장 완료 · 경험치 1당 스톤파우더 $n개"
        } elseif ($levelMode) {
            $saved=Publish-Rules $state.levelBase $state.levelDraft $state.auth Levels
            $state.levelBase=$saved;$state.levelDraft=Copy-LevelRules $saved.rules
            foreach ($kind in $levelViews.Keys) {Refresh-LevelList $kind}
            $Status.Text="해금 레벨 저장 완료 · 규칙 $($saved.rules.revision)"
        } else {
            $saved=Publish-Rules $state.base $d $state.auth;$state.base=$saved;Show-Draft $saved.rules
            $Status.Text="진화 비용 저장 완료 · 규칙 $($saved.rules.revision)"
        }
    }
    catch {$Status.Text=$_.Exception.Message}
})
if (!(Open-AdminGate)) {return}
$window.Add_ContentRendered({$NavPowder.IsChecked=$true;Load-Editor})
try {[void]$window.ShowDialog()} finally {$state.auth=$null}

