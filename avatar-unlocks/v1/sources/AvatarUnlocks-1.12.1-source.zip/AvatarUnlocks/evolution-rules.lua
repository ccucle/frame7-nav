-- Rule snapshots contain costs only. Wallet receipts keep the original charge.
function M.applyCostRules(doc)
    local function cost(n)
        return type(n)=="number" and n==math.floor(n) and n>=1 and n<=999
    end
    if type(doc)~="table" or doc.schema~=1 or type(doc.revision)~="number" or
       doc.revision~=math.floor(doc.revision) or doc.revision<1 or doc.revision>2147483647 or
       type(doc.overrides)~="table" or not cost(doc.first) or not cost(doc.second) then return false end
    for edge,n in pairs(doc.overrides) do
        if type(edge)~="string" or #edge>98 or not edge:match("^[a-z0-9_-]+/[a-z0-9_-]+$") or not cost(n) then return false end
    end
    if doc.revision<=(M.costRevision or 0) then return false end
    for target,rule in pairs(M.evolutions) do
        rule.stage=rule.stage or rule.cost
        rule.cost=doc.overrides[rule.parent.."/"..target] or (rule.stage==1 and doc.first or doc.second)
    end
    M.costRevision=doc.revision
    return true
end

