param([ValidateSet('Editor','Sync','Library')][string]$Mode='Editor')
$ErrorActionPreference='Stop'
$rulesApi='https://api.github.com/repos/ccucle/frame7-nav/contents/rules.json'
$levelsApi='https://api.github.com/repos/ccucle/frame7-nav/contents/levels.json'
$levelCache=Join-Path $PSScriptRoot 'family-unlock-levels.json'
$rulesBranch='formday-family-evolution'
$cache=Join-Path $PSScriptRoot 'family-evolution.json'
$familyLink=Join-Path $PSScriptRoot 'family-evolution.enabled'
$utf8=[Text.UTF8Encoding]::new($false)
$ProgressPreference='SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12

function Test-Count($value) {
    ($value -is [int] -or $value -is [long]) -and $value -ge 1 -and $value -le 999
}
function Convert-Rules($value) {
    if ($value.schema -ne 1 -or $value.revision -isnot [int] -and $value.revision -isnot [long] -or
        $value.revision -lt 1 -or $value.revision -gt 2147483647 -or
        !(Test-Count $value.first) -or !(Test-Count $value.second) -or $value.overrides -isnot [pscustomobject]) {
        throw '진화 규칙 파일 형식을 확인해 주세요.'
    }
    $entries=@{}
    foreach ($p in $value.overrides.PSObject.Properties) {
        if ($p.Name -cnotmatch '^[a-z0-9_-]{1,48}/[a-z0-9_-]{1,48}$' -or !(Test-Count $p.Value)) {throw '잘못된 진화 경로 또는 비용입니다.'}
        $entries[$p.Name]=[int]$p.Value
    }
    [ordered]@{schema=1;revision=[int]$value.revision;first=[int]$value.first;second=[int]$value.second;overrides=$entries}
}
function Copy-Rules($rules) {Convert-Rules (ConvertFrom-Json (ConvertTo-Json $rules -Depth 5 -Compress))}
function Get-Cost($rules,$route) {
    if ($rules.overrides.ContainsKey($route.edge)) {return $rules.overrides[$route.edge]}
    if ($route.stage -eq 1) {return $rules.first}
    $rules.second
}
function Get-Changes($before,$after,$routes) {
    foreach ($r in $routes) {
        $old=Get-Cost $before $r
        $new=Get-Cost $after $r
        if ($old -ne $new -or $before.overrides.ContainsKey($r.edge) -ne $after.overrides.ContainsKey($r.edge)) {
            [pscustomobject]@{route=$r;old=$old;new=$new;custom=$after.overrides.ContainsKey($r.edge)}
        }
    }
}
function Find-Routes($routes,[string]$query) {
    $q=$query.Trim().TrimStart('#')
    if (!$q) {return $routes}
    $families=@{}
    foreach ($r in $routes) {
        if ($q -match '^\d+$') {
            if ($q.TrimStart('0') -in @([string]$r.dex,[string]$r.parentDex)) {$families[$r.family]=1}
        } elseif (($r.name,$r.parentName,$r.id,$r.parent -join ' ').IndexOf($q,[StringComparison]::OrdinalIgnoreCase) -ge 0) {$families[$r.family]=1}
    }
    $routes | Where-Object {$families.ContainsKey($_.family)}
}
function Convert-LevelRules($value) {
    if ($value.schema -ne 1 -or ($value.revision -isnot [int] -and $value.revision -isnot [long]) -or
        $value.revision -lt 1 -or $value.revision -gt 2147483647 -or $value.levels -isnot [pscustomobject]) {throw '해금 레벨 파일 형식 오류'}
    $levels=@{}
    foreach ($pair in $value.levels.PSObject.Properties) {
        if ($pair.Name -cnotmatch '^[a-z0-9_-]{1,48}$' -or !(Test-Count $pair.Value)) {throw '해금 레벨 값 오류'}
        $levels[$pair.Name]=[int]$pair.Value
    }
    [ordered]@{schema=1;revision=[int]$value.revision;levels=$levels}
}
function Convert-FamilyDoc($value,[bool]$levelMode) {
    if ($levelMode) {return Convert-LevelRules $value}
    Convert-Rules $value
}
function Copy-LevelRules($rules) {Convert-LevelRules (ConvertFrom-Json (ConvertTo-Json $rules -Depth 5 -Compress))}
function Get-LevelLabel($doc,$item) {
    if ($doc.levels.ContainsKey($item.id)) {return ('Lv.'+$doc.levels[$item.id]+' · 개별')}
    if ($item.level) {return ('Lv.'+$item.level+' · 기본')}
    return '지급 레벨 미지정'
}
function Get-LevelSummary {
    if (!$state.levelBase -or !$state.levelDraft) {return}
    foreach ($item in $levelItems) {
        $before=Get-LevelLabel $state.levelBase.rules $item
        $after=Get-LevelLabel $state.levelDraft $item
        if ($before -ne $after) {("$($item.name)   $before → $after")}
    }
}


function Read-Snapshot([bool]$levelMode=$false) {
    if ($levelMode) {$rulesApi=$levelsApi}
    $reply=Invoke-RestMethod -UseBasicParsing -TimeoutSec 10 -Headers @{'User-Agent'='Formday-Evolution';'Cache-Control'='no-cache'} -Uri ($rulesApi+'?ref='+$rulesBranch+'&t='+[DateTimeOffset]::UtcNow.ToUnixTimeSeconds())
    if ($reply.sha -cnotmatch '^[a-f0-9]{40}$' -or $reply.size -gt 65536 -or $reply.encoding -ne 'base64') {throw '공유 규칙을 확인할 수 없습니다.'}
    $rules=Convert-FamilyDoc (ConvertFrom-Json ($utf8.GetString([Convert]::FromBase64String($reply.content)))) $levelMode
    [pscustomobject]@{sha=$reply.sha;rules=$rules}
}
function Set-Cache($rules,[bool]$levelMode=$false) {
    if ($levelMode) {$cache=$levelCache}
    $lock=New-Object Threading.Mutex($false,'Local\FormdayFamilyEvolutionCache')
    $held=$false
    try {
        try {$held=$lock.WaitOne(4500)} catch [Threading.AbandonedMutexException] {$held=$true}
        if (!$held) {throw '도감 동기화가 진행 중입니다.'}
        if ([IO.File]::Exists($cache)) {
            try {$existing=Convert-FamilyDoc (ConvertFrom-Json ([IO.File]::ReadAllText($cache))) $levelMode
                 if ($existing.revision -ge $rules.revision) {return}} catch {}
        }
        $tmp=$cache+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
        try {
            [IO.File]::WriteAllText($tmp,(ConvertTo-Json $rules -Compress -Depth 5),$utf8)
            if ([IO.File]::Exists($cache)) {[IO.File]::Replace($tmp,$cache,$cache+'.previous')} else {[IO.File]::Move($tmp,$cache)}
        } finally {if ([IO.File]::Exists($tmp)) {[IO.File]::Delete($tmp)}}
    } finally {if ($held) {$lock.ReleaseMutex()};$lock.Dispose()}
}
function Publish-Rules($base,$draft,$credential,[bool]$levelMode=$false) {
    $relPath=if ($levelMode) {$rulesApi=$levelsApi;"levels.json"} else {"rules.json"}
    if (!(Test-ParentAccount $credential)) {throw 'ccucle 계정의 편집 권한을 확인할 수 없습니다.'}
    $doc=if ($levelMode) {Copy-LevelRules $draft} else {Copy-Rules $draft}
    $doc.revision=$base.rules.revision+1
    $body=@{message=('Update family '+$relPath);branch=$rulesBranch;sha=$base.sha
        content=[Convert]::ToBase64String($utf8.GetBytes((ConvertTo-Json $doc -Depth 5 -Compress)))}
    try {
        if ($credential -eq 'GitHubCLI') {
            $json=(ConvertTo-Json $body -Compress) | & $githubCli api --hostname github.com --method PUT ("repos/ccucle/frame7-nav/contents/"+$relPath) --input - 2>&1
            if ($LASTEXITCODE) {
                if (($json -join ' ') -match 'HTTP (409|422)') {throw 'CONFLICT'}
                throw 'GitHub 권한 확인 실패'
            }
            $result=ConvertFrom-Json ($json -join [Environment]::NewLine)
        } else {
            $headers=@{'User-Agent'='Formday-Evolution';Authorization=('Bearer '+$credential.GetNetworkCredential().Password)}
            $result=Invoke-RestMethod -Method Put -Uri $rulesApi -UseBasicParsing -Headers $headers -TimeoutSec 15 -ContentType 'application/json' -Body (ConvertTo-Json $body -Compress)
        }
    } catch {
        if ($_.Exception.Message -eq 'CONFLICT' -or ($_.Exception.Response -and [int]$_.Exception.Response.StatusCode -in @(409,422))) {throw '다른 변경이 먼저 저장됐습니다. 새로고침한 뒤 다시 편집해 주세요.'}
        throw '공유 저장을 확인하지 못했습니다. 연결과 편집 권한을 확인한 뒤 새로고침해 주세요.'
    }
    if ($result.content.sha -cnotmatch '^[a-f0-9]{40}$') {throw '저장 결과를 확인하지 못했습니다.'}
    Set-Cache $doc $levelMode
    [pscustomobject]@{sha=$result.content.sha;rules=$doc}
}
Add-Type -AssemblyName System.Security
$pinFile=Join-Path $PSScriptRoot 'family-editor-pin-v1.json'
$pinScope=[Security.Cryptography.DataProtectionScope]::CurrentUser
function Write-PinState($record) {
    $tmp=$pinFile+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    try {
        [IO.File]::WriteAllText($tmp,(ConvertTo-Json $record -Compress),$utf8)
        if ([IO.File]::Exists($pinFile)) {[IO.File]::Replace($tmp,$pinFile,[NullString]::Value)} else {[IO.File]::Move($tmp,$pinFile)}
    } finally {if ([IO.File]::Exists($tmp)) {[IO.File]::Delete($tmp)}}
}
function Get-PinKey([string]$pin,[byte[]]$salt) {
    $k=[Security.Cryptography.Rfc2898DeriveBytes]::new($pin,$salt,160000,[Security.Cryptography.HashAlgorithmName]::SHA256)
    try {return ,($k.GetBytes(32))} finally {$k.Dispose()}
}
function Access-ParentPin([string]$pin,[string]$registerProvider) {
    if ($pin -cnotmatch '^[0-9]{4}$') {throw '숫자 네 자리를 입력해 주세요.'}
    $guard=[Threading.Mutex]::new($false,'Local\FormdayEvolutionParentPinV1')
    $held=$false;$key=$null
    try {
        try {$held=$guard.WaitOne(5000)} catch [Threading.AbandonedMutexException] {$held=$true}
        if (!$held) {throw '다른 편집 창에서 PIN을 확인 중이에요.'}
        if ($registerProvider) {
            if ($registerProvider -notin 'browser','existing' -or [IO.File]::Exists($pinFile)) {throw 'PIN이 이미 등록됐습니다. 창을 다시 열어 주세요.'}
            $salt=New-Object byte[] 16
            $rng=[Security.Cryptography.RandomNumberGenerator]::Create()
            try {$rng.GetBytes($salt)} finally {$rng.Dispose()}
            $key=Get-PinKey $pin $salt
            $data=[Security.Cryptography.ProtectedData]::Protect($utf8.GetBytes('family-pin-v1/'+$registerProvider),$key,$pinScope)
            Write-PinState @{salt=[Convert]::ToBase64String($salt);proof=[Convert]::ToBase64String($data);tries=0;until=0}
            return $registerProvider
        }
        $disk=ConvertFrom-Json ([IO.File]::ReadAllText($pinFile))
        $now=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        if ($disk.until -gt $now) {throw ('잠시 잠겼어요. 약 '+[math]::Ceiling(($disk.until-$now)/60)+'분 뒤에 다시 입력하세요.')}
        $key=Get-PinKey $pin ([Convert]::FromBase64String($disk.salt))
        try {
            $bytes=[Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($disk.proof),$key,$pinScope)
            $provider=$utf8.GetString($bytes)
        } catch {
            $disk.tries=[int]$disk.tries+1
            if ($disk.tries -ge 5) {$disk.until=$now+300;$disk.tries=0}
            Write-PinState $disk
            if ($disk.until -gt $now) {throw '5회 틀려 5분 동안 잠겼어요.'}
            throw 'PIN이 맞지 않습니다.'
        }
        if ($provider -cnotin 'family-pin-v1/browser','family-pin-v1/existing') {throw '저장된 관리자 연결을 확인할 수 없습니다.'}
        if ($disk.tries -or $disk.until) {$disk.tries=0;$disk.until=0;Write-PinState $disk}
        return $provider.Substring(14)
    } finally {if ($key) {[Array]::Clear($key,0,$key.Length)};if ($held) {$guard.ReleaseMutex()};$guard.Dispose()}
}
function Find-LoginHelper {
    $installed=Join-Path $env:ProgramFiles 'GitHub CLI\gh.exe'
    if ([IO.File]::Exists($installed)) {return $installed}
    $app=Get-Command gh.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($app) {return $app.Source}
    $private=Join-Path $PSScriptRoot 'github-login-2.106.0\gh.exe'
    if ([IO.File]::Exists($private)) {return $private}
}
function Install-LoginHelper {
    $arch=$env:PROCESSOR_ARCHITECTURE
    if ($env:PROCESSOR_ARCHITEW6432) {$arch=$env:PROCESSOR_ARCHITEW6432}
    $packages=@{
      AMD64=@('amd64','d406f442ca0baa3d3e9c695e9cded1aa48e67dad3294b8947e5ab84f980b4844')
      ARM64=@('arm64','6099b15d88eb96b7955050e84bd002432f9572857402d7f342c87cfaeaa83082')
      x86=@('386','de42e53d711a37640120692709693d0f51c461356b3b063d8c1d72220346333f')
    }
    $selected=$packages[$arch]
    if (!$selected) {throw '이 Windows 환경에 맞는 로그인 도구를 찾지 못했습니다.'}
    $folder=Join-Path $PSScriptRoot 'github-login-2.106.0'
    [void][IO.Directory]::CreateDirectory($folder)
    $exe=Join-Path $folder 'gh.exe'
    $tmp=Join-Path $folder ([guid]::NewGuid().ToString('N'))
    $wc=[Net.WebClient]::new()
    try {
        $wc.DownloadFile(('https://github.com/cli/cli/releases/download/v2.106.0/gh_2.106.0_windows_'+$selected[0]+'.zip'),$tmp+'.zip')
        $digest=Get-FileHash -LiteralPath ($tmp+'.zip') -Algorithm SHA256
        if ($digest.Hash -ne $selected[1]) {throw '로그인 도구 파일을 확인할 수 없습니다.'}
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zip=[IO.Compression.ZipFile]::OpenRead($tmp+'.zip')
        try {
            $entries=@($zip.Entries | Where-Object {$_.FullName -match '(^|/)bin/gh\.exe$|^gh\.exe$'})
            if ($entries.Count -ne 1) {throw '로그인 도구 압축 파일을 확인할 수 없습니다.'}
            [IO.Compression.ZipFileExtensions]::ExtractToFile($entries[0],$tmp)
        } finally {$zip.Dispose()}
        try {[IO.File]::Move($tmp,$exe)} catch {if (![IO.File]::Exists($exe)) {throw}}
        return $exe
    } finally {$wc.Dispose();foreach ($path in @($tmp,($tmp+'.zip'))) {if ([IO.File]::Exists($path)) {[IO.File]::Delete($path)}}}
}
function Test-ParentAccount($connection) {
    try {
        if ($connection -eq 'GitHubCLI') {
            if (!$githubCli) {return $false}
            $login=& $githubCli api --hostname github.com user --jq .login 2>$null
            if ($LASTEXITCODE -ne 0 -or $login -ne 'ccucle') {return $false}
            $canWrite=& $githubCli api --hostname github.com repos/ccucle/frame7-nav --jq .permissions.push 2>$null
            return ($LASTEXITCODE -eq 0 -and $canWrite -eq 'true')
        }
        if ($connection -isnot [pscredential]) {return $false}
        $headers=@{Authorization=('Bearer '+$connection.GetNetworkCredential().Password);'User-Agent'='Formday-Evolution'}
        $user=Invoke-RestMethod -UseBasicParsing -TimeoutSec 10 -Uri 'https://api.github.com/user' -Headers $headers
        if ($user.login -ne 'ccucle') {return $false}
        $repo=Invoke-RestMethod -UseBasicParsing -TimeoutSec 10 -Uri 'https://api.github.com/repos/ccucle/frame7-nav' -Headers $headers
        return [bool]$repo.permissions.push
    } catch {return $false}
}


if ($Mode -eq 'Library') {return}
if ($Mode -eq 'Sync') {
    if (![IO.File]::Exists($familyLink)) {exit 0}
    $failed=$false
    foreach ($file in 'rules.json','levels.json') {
        try {
            $url='https://raw.githubusercontent.com/ccucle/frame7-nav/'+$rulesBranch+'/'+$file+'?t='+[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
            $result=Invoke-WebRequest -UseBasicParsing -TimeoutSec 10 -Uri $url
            if ($result.RawContentLength -gt 65536) {throw '규칙 파일이 너무 큽니다.'}
            $body=if ($result.Content -is [byte[]]) {$utf8.GetString($result.Content)} else {$result.Content}
            $isLevel=$file -eq 'levels.json'
            Set-Cache (Convert-FamilyDoc (ConvertFrom-Json $body) $isLevel) $isLevel
        } catch {$failed=$true}
    }
    if ($failed) {exit 1}
    exit 0
}

Add-Type -AssemblyName PresentationFramework
$layout=@'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="해금도감 · 가족 설정" Width="520" Height="610" MinWidth="485" MinHeight="530" Background="#F7F3E5" FontFamily="Galmuri9 Regular, Malgun Gothic" WindowStartupLocation="CenterScreen" UseLayoutRounding="True">
<Window.Resources>
  <Style TargetType="Button"><Setter Property="Background" Value="#E7E5CB"/><Setter Property="Foreground" Value="#253B3B"/><Setter Property="BorderBrush" Value="#42534B"/><Setter Property="Padding" Value="10,5"/><Setter Property="Margin" Value="2"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border x:Name="b" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="2,1,2,3" Padding="{TemplateBinding Padding}"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="b" Property="BorderBrush" Value="#518468"/></Trigger><Trigger Property="IsEnabled" Value="False"><Setter TargetName="b" Property="Opacity" Value=".5"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
  <Style TargetType="TextBox"><Setter Property="Padding" Value="6,4"/><Setter Property="BorderBrush" Value="#84998C"/><Setter Property="VerticalContentAlignment" Value="Center"/></Style>
</Window.Resources>
<Border BorderBrush="#253B3B" Background="#F7F3E5" BorderThickness="3"><DockPanel>
<Border DockPanel.Dock="Top" Background="#263D3E" Padding="14,10"><DockPanel><Button Name="Admin" DockPanel.Dock="Right" Content="관리자 PIN 설정"/><TextBlock Foreground="#FFF7DC" FontSize="18" VerticalAlignment="Center" Text="⚙  해금도감 설정"/></DockPanel></Border>
<StackPanel DockPanel.Dock="Bottom" Margin="12,2,12,10"><TextBlock Name="Status" TextWrapping="Wrap" Margin="3,6" Foreground="#42534B"/><DockPanel><Button Name="Family" DockPanel.Dock="Left" Content="가족 규칙 연결"/><Button Name="Reload" DockPanel.Dock="Left" Content="새로고침"/><Button Name="Review" Content="변경 확인" Background="#F6C471"/></DockPanel></StackPanel>
<TabControl Name="Tabs" Margin="12" Background="#F7F3E5" BorderBrush="#829588"><TabItem Header=" 기본 비용 "><StackPanel Margin="14">
<TextBlock Text="진화 단계별 기본 비용" FontWeight="Bold" FontSize="16" Margin="0,6,0,8"/><TextBlock Text="개별 지정한 경로는 기존 개수를 유지합니다." TextWrapping="Wrap" Margin="0,0,0,18"/>
<TextBlock Text="첫 번째 진화 · 기본형 → 1차 진화"/><TextBox Name="First" MaxLength="3" Margin="0,4,0,18"/>
<TextBlock Text="두 번째 진화 · 1차 → 2차 진화"/><TextBox Name="Second" MaxLength="3" Margin="0,4,0,10"/>
<TextBlock Text="각 단계에 필요한 돌을 1~999개로 지정합니다." Foreground="#516859"/>
</StackPanel></TabItem>
<TabItem Header=" 개별 비용 "><DockPanel Margin="8"><StackPanel DockPanel.Dock="Top"><TextBlock Text="이름 또는 도감 번호로 계열 찾기"/><TextBox Name="Search" Margin="0,4,0,7"/></StackPanel>
<StackPanel DockPanel.Dock="Bottom" Margin="0,8,0,0"><TextBlock Name="Choice" TextWrapping="Wrap" Margin="0,0,0,4"/><DockPanel><Button Name="ResetEdge" DockPanel.Dock="Right" Content="기본값으로 복원"/><Button Name="SetEdge" DockPanel.Dock="Right" Content="개별 지정"/><TextBox Name="EdgeCost" MaxLength="3" VerticalAlignment="Center"/></DockPanel></StackPanel>
<ListBox Name="Routes" Background="#F7F4E4" BorderBrush="#8D988A" ScrollViewer.HorizontalScrollBarVisibility="Disabled"/></DockPanel></TabItem></TabControl>
</DockPanel></Border></Window>
'@
$window=[Windows.Markup.XamlReader]::Parse($layout)
foreach ($n in 'Tabs','Admin','Family','Status','Reload','Review','First','Second','Search','Choice','EdgeCost','SetEdge','ResetEdge','Routes') {
    Set-Variable -Name $n -Value ($window.FindName($n))
}
$routeFile=[IO.Path]::ChangeExtension($PSCommandPath,'.json')
$allRoutes=ConvertFrom-Json ([IO.File]::ReadAllText($routeFile))
$levelItems=ConvertFrom-Json ([IO.File]::ReadAllText([IO.Path]::ChangeExtension($PSCommandPath,'.levels.json')))
$state=@{base=$null;draft=$null;auth=$null;busy=$false}
$credentialFile=Join-Path $PSScriptRoot 'family-editor-current-user.xml'
$githubCli=Find-LoginHelper
function Update-Controls {
    $edit=$null -ne $state.auth -and $null -ne $state.base
    foreach($control in @($First,$Second,$EdgeCost,$SetEdge,$ResetEdge,$Review)) {$control.IsEnabled=$edit}
    $levelsEdit=$null -ne $state.auth -and $null -ne $state.levelBase
    foreach ($v in $levelViews.Values) {foreach ($field in 'Assign','Amount','Restore') {$v[$field].IsEnabled=$levelsEdit}}
    if ($Tabs.SelectedIndex -ge 2) {$Review.IsEnabled=$levelsEdit;$Review.Content='레벨 변경 확인'} else {$Review.Content='비용 변경 확인'}
    $Admin.IsEnabled=($null -eq $state.login)
    $Admin.Content=if($state.auth){'편집 잠그기'}elseif ([IO.File]::Exists($pinFile)) {'PIN으로 편집'}else{'관리자 PIN 설정'}
    $Family.IsEnabled=($null -ne $state.base) -and ![IO.File]::Exists($familyLink)
    $Family.Content=if ([IO.File]::Exists($familyLink)) {'가족 규칙 연결됨'} else {'가족 규칙 연결'}
}
function Refresh-List {
    $edge=if ($Routes.SelectedItem) {$Routes.SelectedItem.Tag.edge}
    $Routes.Items.Clear()
    foreach ($r in (Find-Routes $allRoutes $Search.Text)) {
        $item=New-Object Windows.Controls.ListBoxItem
        $kind=if ($state.draft.overrides.ContainsKey($r.edge)) {'개별 지정'}else{'기본값'}
        $item.Content=('#{0:0000} {1} → {2}  ·  {3}개  [{4}]' -f [int]$r.dex,$r.parentName,$r.name,(Get-Cost $state.draft $r),$kind)
        $item.Tag=$r
        [void]$Routes.Items.Add($item)
        if ($r.edge -eq $edge) {$Routes.SelectedItem=$item}
    }
    if (!$Routes.SelectedItem -and $Routes.Items.Count) {$Routes.SelectedIndex=0}
    if (!$Routes.Items.Count) {$Choice.Text='일치하는 진화 경로가 없습니다.';$EdgeCost.Clear()}
}
function Show-Draft($doc) {
    $state.busy=$true
    $state.draft=Copy-Rules $doc
    $First.Text=[string]$doc.first;$Second.Text=[string]$doc.second
    $state.busy=$false
    Refresh-List;Update-Controls
}
function Load-Editor {
    try {
        $snap=Read-Snapshot
        if ([IO.File]::Exists($familyLink)) {Set-Cache $snap.rules}
        $state.base=$snap;Show-Draft $snap.rules
        $Status.Text="공유 규칙 $($snap.rules.revision) · 두 PC에 적용되는 설정"
    } catch {
        $state.base=$null
        $doc=Convert-Rules (ConvertFrom-Json '{"schema":1,"revision":1,"first":1,"second":2,"overrides":{}}')
        if (Test-Path -LiteralPath $cache) {try {$doc=Convert-Rules (ConvertFrom-Json ([IO.File]::ReadAllText($cache)))} catch {}}
        Show-Draft $doc;$Status.Text='공유 규칙 연결 대기 · 저장된 비용을 표시합니다.'
    }
    Load-LevelEditor
}
function Confirm-Draft {
    if (@(Get-LevelSummary).Count) {
        return [Windows.MessageBox]::Show($window,'저장하지 않은 변경을 버릴까요?','해금도감 설정','YesNo','Question','No') -eq 'Yes'
    }
    if (!$state.draft -or !$state.base) {return $true}
    $b=$state.base.rules
    if ($b.first -eq $state.draft.first -and $b.second -eq $state.draft.second -and
        !(Get-Changes $b $state.draft $allRoutes) -and $First.Text -eq [string]$b.first -and $Second.Text -eq [string]$b.second) {return $true}
    [Windows.MessageBox]::Show($window,'저장하지 않은 변경을 버릴까요?','진화 비용','YesNo','Question','No') -eq 'Yes'
}
function Input-Count([string]$s) {if ($s -cmatch '^[1-9][0-9]{0,2}$') {return [int]$s};return 0}
$Search.Add_TextChanged({if ($state.draft) {Refresh-List}})
$Routes.Add_SelectionChanged({
    if ($Routes.SelectedItem) {$r=$Routes.SelectedItem.Tag;$Choice.Text="$($r.parentName) → $($r.name)  ·  $($r.stone)";$EdgeCost.Text=[string](Get-Cost $state.draft $r)}
})
$changeDefaults={
    if ($state.busy -or !$state.draft) {return}
    $a=Input-Count $First.Text;$b=Input-Count $Second.Text
    if ($a -and $b) {$state.draft.first=$a;$state.draft.second=$b;Refresh-List}
}
$First.Add_TextChanged($changeDefaults);$Second.Add_TextChanged($changeDefaults)
$SetEdge.Add_Click({
    if (!$Routes.SelectedItem) {return}
    $n=Input-Count $EdgeCost.Text
    if (!$n) {$Status.Text='돌 개수는 1~999 사이의 정수로 입력해 주세요.';return}
    $state.draft.overrides[$Routes.SelectedItem.Tag.edge]=$n;Refresh-List
})
$ResetEdge.Add_Click({if ($Routes.SelectedItem) {$state.draft.overrides.Remove($Routes.SelectedItem.Tag.edge);Refresh-List}})
$Reload.Add_Click({if (Confirm-Draft) {Load-Editor}})
$Family.Add_Click({
    try {if ($state.base) {Set-Cache $state.base.rules;if ($state.levelBase) {Set-Cache $state.levelBase.rules $true};[IO.File]::WriteAllText($familyLink,'1');Update-Controls;$Status.Text='이 PC가 가족 진화 규칙을 자동으로 받습니다.'}}
    catch {$Status.Text='이 PC의 가족 연결을 저장하지 못했습니다.'}
})
$window.Add_Closing({param($sender,$args2) if (!(Confirm-Draft)) {$args2.Cancel=$true}})
function Show-ParentPin([string]$registerProvider) {
    $dialog=[Windows.Markup.XamlReader]::Parse('<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Title="관리자 PIN" SizeToContent="WidthAndHeight" ResizeMode="NoResize" WindowStartupLocation="CenterOwner" Background="#F7F3E5"><StackPanel Width="312" Margin="18"><TextBlock Name="Prompt" TextWrapping="Wrap"/><PasswordBox Name="Pin" MaxLength="4" FontSize="20" Padding="6" Margin="0,9,0,6"/><TextBlock Name="AgainLabel" Text="같은 PIN 한 번 더"/><PasswordBox Name="Again" MaxLength="4" FontSize="20" Padding="6" Margin="0,6"/><TextBlock Name="Message" TextWrapping="Wrap" Foreground="#81492D" Margin="0,4"/><StackPanel Orientation="Horizontal" HorizontalAlignment="Right"><Button Content="취소" IsCancel="True" Padding="12,5" Margin="0,0,6,0"/><Button Name="Accept" IsDefault="True" Padding="14,5" Background="#F6C471"/></StackPanel></StackPanel></Window>')
    $dialog.Owner=$window
    $inputBox=$dialog.FindName('Pin');$repeatBox=$dialog.FindName('Again');$ok=$dialog.FindName('Accept')
    if ($registerProvider) {$dialog.FindName('Prompt').Text='이 PC에서 가족 규칙을 편집할 때 쓸 숫자 4자리를 정하세요.';$ok.Content='PIN 등록'}
    else {$dialog.FindName('Prompt').Text='이 PC에 등록한 관리자 PIN 네 자리를 입력하세요.';$ok.Content='편집 열기';$repeatBox.Visibility='Collapsed';$dialog.FindName('AgainLabel').Visibility='Collapsed'}
    $pinResult=@{provider=$null}
    $dialog.Add_ContentRendered({[void]$inputBox.Focus()})
    $ok.Add_Click({
        try {
            if ($registerProvider -and $inputBox.Password -cne $repeatBox.Password) {throw '두 PIN이 일치하지 않습니다.'}
            $pinResult.provider=Access-ParentPin $inputBox.Password $registerProvider
            $dialog.DialogResult=$true
        } catch {$dialog.FindName('Message').Text=$_.Exception.Message;$inputBox.Clear();$repeatBox.Clear();[void]$inputBox.Focus()}
    })
    $confirmed=$dialog.ShowDialog()
    $inputBox.Clear();$repeatBox.Clear()
    if ($confirmed) {return $pinResult.provider}
}
function Enable-ParentEditing($connection) {
    $state.auth=$connection
    [IO.File]::WriteAllText($familyLink,'1')
    if ($state.base) {Set-Cache $state.base.rules}
    if ($state.levelBase) {Set-Cache $state.levelBase.rules $true}
    Update-Controls
    $Status.Text='편집이 열렸습니다. 창을 닫으면 다시 잠깁니다.'
}
function Register-VerifiedParent($connection,[string]$provider) {
    if (!(Test-ParentAccount $connection)) {throw 'ccucle 계정과 저장 권한을 확인한 후 다시 시도해 주세요.'}
    if (Show-ParentPin $provider) {Enable-ParentEditing $connection}
}
function Start-ParentSetup {
    if (Test-Path -LiteralPath $credentialFile) {
        try {$old=Import-Clixml -LiteralPath $credentialFile -ErrorAction Stop} catch {$old=$null}
        if ($old -and (Test-ParentAccount $old)) {Register-VerifiedParent $old 'existing';return}
    }
    if ($githubCli -and (Test-ParentAccount 'GitHubCLI')) {Register-VerifiedParent 'GitHubCLI' 'browser';return}
    $message='최초 한 번 ccucle 계정으로 이 PC를 확인한 뒤, 원하는 PIN 네 자리를 정합니다.'
    if (!$githubCli) {$message+=" 먼저 GitHub 공식 로그인 도구를 이 PC에 내려받습니다."}
    $message+=" 인증 창의 일회용 코드는 GitHub에만 입력하세요."
    if ([Windows.MessageBox]::Show($window,$message,'관리자 PC 등록','OKCancel','Information','OK') -ne 'OK') {return}
    if (!$githubCli) {
        $window.Cursor=[Windows.Input.Cursors]::Wait
        try {$script:githubCli=Install-LoginHelper} finally {$window.Cursor=$null}
    }
    $state.login=Start-Process -FilePath $githubCli -ArgumentList 'auth','login','--hostname','github.com','--web','--git-protocol','https' -WindowStyle Normal -PassThru
    $Status.Text='열린 GitHub 인증 창에서 ccucle 계정으로 승인해 주세요.'
    Update-Controls
    $loginWatch.Start()
}
$loginWatch=[Windows.Threading.DispatcherTimer]::new()
$loginWatch.Interval=[TimeSpan]::FromMilliseconds(500)
$loginWatch.Add_Tick({
    if (!$state.login -or !$state.login.HasExited) {return}
    $loginWatch.Stop()
    $reconnect=$state.reconnect;$state.reconnect=$false
    $exitCode=$state.login.ExitCode;$state.login.Dispose();$state.login=$null
    Update-Controls
    try {
        if ($exitCode -ne 0) {throw '브라우저 인증이 완료되지 않았습니다. 다시 시도할 수 있어요.'}
        if ($reconnect) {
            if (!(Test-ParentAccount 'GitHubCLI')) {throw 'ccucle 계정으로 승인해 주세요.'}
            Enable-ParentEditing 'GitHubCLI'
        } else {Register-VerifiedParent 'GitHubCLI' 'browser'}
    } catch {$Status.Text=$_.Exception.Message}
})
$window.Add_Closed({$loginWatch.Stop();if ($state.login) {$state.login.Dispose()};$state.auth=$null})
$Admin.Add_Click({
    try {
        if ($state.auth) {
            if (!(Confirm-Draft)) {return}
            $state.auth=$null;Load-Editor;return
        }
        if (![IO.File]::Exists($pinFile)) {Start-ParentSetup;return}
        $provider=Show-ParentPin ''
        if (!$provider) {return}
        $connection=if ($provider -eq 'existing' -and [IO.File]::Exists($credentialFile)) {Import-Clixml -LiteralPath $credentialFile} else {'GitHubCLI'}
        if (!(Test-ParentAccount $connection)) {
            $Status.Text='저장 권한을 다시 확인해야 합니다.'
            # PIN was accepted. A new browser grant can replace a revoked legacy credential.
            if ($provider -eq 'existing' -and (Test-ParentAccount 'GitHubCLI')) {Enable-ParentEditing 'GitHubCLI';return}
            $state.reconnect=$true
            try {
                if (!$githubCli) {$script:githubCli=Install-LoginHelper}
                $state.login=Start-Process -FilePath $githubCli -ArgumentList 'auth','login','--hostname','github.com','--web','--git-protocol','https' -PassThru -WindowStyle Normal
                Update-Controls;$loginWatch.Start()
            } catch {$state.reconnect=$false;throw}
            return
        }
        Enable-ParentEditing $connection
    } catch {$Status.Text=$_.Exception.Message}
})


$titles=@{pokemon='포켓몬';pet='펫';outfit='의상'}
$levelViews=@{}
foreach ($kind in 'pokemon','pet','outfit') {
    $tab=[Windows.Markup.XamlReader]::Parse('<TabItem xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"><DockPanel Margin="8"><StackPanel DockPanel.Dock="Top"><TextBlock Name="Legend" TextWrapping="Wrap" Margin="0,2,0,6"/><TextBox Name="Filter" Margin="0,0,0,6" ToolTip="이름 또는 도감 번호 검색"/></StackPanel><StackPanel DockPanel.Dock="Bottom" Margin="0,8,0,2"><TextBlock Name="Selected" Margin="0,0,0,5"/><DockPanel><Button Name="Restore" DockPanel.Dock="Right" Content="기본값 복원"/><Button Name="Assign" DockPanel.Dock="Right" Content="레벨 지정"/><TextBox Name="Amount" MaxLength="3" ToolTip="해금 레벨"/></DockPanel></StackPanel><ListBox Name="Items" Background="#F7F4E4" BorderBrush="#8D988A" ScrollViewer.HorizontalScrollBarVisibility="Disabled"/></DockPanel></TabItem>')
    $tab.Header=$titles[$kind]+' 레벨';$tab.Tag=$kind
    $v=@{}
    foreach ($name in 'Legend','Filter','Selected','Amount','Restore','Assign','Items') {$v[$name]=$tab.FindName($name);$v[$name].Tag=$kind}
    $v.Legend.Text=if ($kind -eq 'pokemon') {"기본형·단일형 · Lv.1~20`n이름 또는 도감 번호 검색"} else {"Lv.1~999 · 카드 전용 항목은 보유만 해금됩니다.`n이름 검색"}
    $levelViews[$kind]=$v;[void]$Tabs.Items.Add($tab)
}
function Refresh-LevelList($kind) {
    if (!$state.levelDraft) {return}
    $v=$levelViews[$kind];$selected=if ($v.Items.SelectedItem) {$v.Items.SelectedItem.Tag.id}
    $v.Items.Items.Clear();$q=$v.Filter.Text.Trim().TrimStart('#')
    foreach ($entry in $levelItems) {
        if ($entry.kind -ne $kind) {continue}
        if ($q -and $entry.name.IndexOf($q,[StringComparison]::OrdinalIgnoreCase) -lt 0 -and
            $entry.id.IndexOf($q,[StringComparison]::OrdinalIgnoreCase) -lt 0 -and
            (!$entry.dex -or [string]$entry.dex -ne $q.TrimStart('0'))) {continue}
        $row=[Windows.Controls.ListBoxItem]::new();$row.Tag=$entry
        $number=if ($entry.dex) {'#{0:0000} ' -f [int]$entry.dex} else {''}
        $availability=if ($entry.cardOnly) {' · 카드 전용'} else {''}
        $row.Content=$number+$entry.name+'   '+(Get-LevelLabel $state.levelDraft $entry)+$availability
        [void]$v.Items.Items.Add($row);if ($entry.id -eq $selected) {$v.Items.SelectedItem=$row}
    }
    if ($v.Items.Items.Count -and !$v.Items.SelectedItem) {$v.Items.SelectedIndex=0}
    if ($v.Items.SelectedItem) {$v.Items.ScrollIntoView($v.Items.SelectedItem)}
    if (!$v.Items.SelectedItem) {$v.Selected.Text='검색 결과 없음';$v.Amount.Clear()}
}
function Load-LevelEditor {
    try {$snapshot=Read-Snapshot $true;if ([IO.File]::Exists($familyLink)) {Set-Cache $snapshot.rules $true};$state.levelBase=$snapshot;$doc=$snapshot.rules}
    catch {
        $state.levelBase=$null;$doc=@{schema=1;revision=1;levels=@{}}
        if ([IO.File]::Exists($levelCache)) {try {$doc=Convert-LevelRules (ConvertFrom-Json ([IO.File]::ReadAllText($levelCache)))} catch {}}
    }
    $state.levelDraft=Copy-LevelRules $doc
    foreach ($k in $levelViews.Keys) {Refresh-LevelList $k}
    Update-Controls
}
foreach ($view in $levelViews.Values) {
    $view.Filter.Add_TextChanged({param($sender,$eventArgs) Refresh-LevelList $sender.Tag})
    $view.Items.Add_SelectionChanged({
        param($sender,$eventArgs)
        if (!$sender.SelectedItem) {return}
        $v=$levelViews[$sender.Tag];$item=$sender.SelectedItem.Tag
        $v.Selected.Text=$item.name+' · '+(Get-LevelLabel $state.levelDraft $item)
        $v.Amount.Text=if ($state.levelDraft.levels.ContainsKey($item.id)) {[string]$state.levelDraft.levels[$item.id]} else {[string]$item.level}
    })
    $view.Restore.Add_Click({
        param($sender,$eventArgs)
        $v=$levelViews[$sender.Tag];if (!$state.auth -or !$state.levelBase -or !$v.Items.SelectedItem) {return}
        $state.levelDraft.levels.Remove($v.Items.SelectedItem.Tag.id);Refresh-LevelList $sender.Tag
    })
    $view.Assign.Add_Click({
        param($sender,$eventArgs)
        $v=$levelViews[$sender.Tag];if (!$state.auth -or !$state.levelBase -or !$v.Items.SelectedItem) {return}
        $n=Input-Count $v.Amount.Text;$max=if ($sender.Tag -eq 'pokemon') {20} else {999}
        if (!$n -or $n -gt $max) {$Status.Text="1~$max 사이의 레벨을 입력해 주세요.";return}
        $state.levelDraft.levels[$v.Items.SelectedItem.Tag.id]=$n;Refresh-LevelList $sender.Tag
    })
}
$Tabs.Add_SelectionChanged({param($sender,$eventArgs)
    if ($eventArgs.Source -ne $Tabs) {return}
    Update-Controls
    if ($Tabs.SelectedIndex -ge 2 -and $state.levelDraft -and !$state.levelBase) {$Status.Text='해금 레벨 연결 대기 · 새로고침으로 다시 확인하세요.'}
})


$Review.Add_Click({
    if (!$state.auth) {return}
    $levelMode=$Tabs.SelectedIndex -ge 2
    if ($levelMode) {
        if (!$state.levelBase) {return}
        $changes=@(Get-LevelSummary)
        if (!$changes.Count) {$Status.Text='변경된 해금 레벨이 없습니다.';return}
        $summary=@("해금 레벨 변경 · $($changes.Count)개")+$changes
    } else {
    if (!$state.base) {return}
    if (!(Input-Count $First.Text) -or !(Input-Count $Second.Text)) {$Status.Text='기본값은 1~999 사이의 정수여야 합니다.';return}
    $b=$state.base.rules;$d=$state.draft
    $diff=@(Get-Changes $b $d $allRoutes)
    $summary=@()
    if ($d.first -ne $b.first) {$summary+="첫 번째 진화 기본값   $($b.first) → $($d.first)개"}
    if ($d.second -ne $b.second) {$summary+="두 번째 진화 기본값   $($b.second) → $($d.second)개"}
    if (!$diff.Count -and !$summary.Count) {$Status.Text='변경된 규칙이 없습니다.';return}
    $summary+="변경 경로 $($diff.Count)개"
    foreach ($c in $diff) {
        $kind=if ($c.custom) {'개별 지정'}else{'기본값'}
        $summary+="$($c.route.parentName) → $($c.route.name)   $($c.old) → $($c.new)개 · $kind"
    }
    }
    $preview=[Windows.Markup.XamlReader]::Parse('<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Title="변경 확인" Width="420" Height="420" Background="#F7F3E5" WindowStartupLocation="CenterOwner"><DockPanel Margin="12"><StackPanel Orientation="Horizontal" DockPanel.Dock="Bottom" HorizontalAlignment="Right" Margin="0,8"><Button Content="돌아가기" IsCancel="True" IsDefault="True" Padding="12,5"/><Button Name="Apply" Content="두 PC에 적용" Padding="12,5" Background="#F6C471"/></StackPanel><ListBox Name="Summary"/></DockPanel></Window>')
    $preview.Owner=$window;$preview.FindName('Summary').ItemsSource=$summary
    $preview.FindName('Apply').Add_Click({$preview.DialogResult=$true})
    if ($preview.ShowDialog() -ne $true) {return}
    try {
        if ($levelMode) {
            $saved=Publish-Rules $state.levelBase $state.levelDraft $state.auth $true
            $state.levelBase=$saved;$state.levelDraft=Copy-LevelRules $saved.rules
            foreach ($kind in $levelViews.Keys) {Refresh-LevelList $kind}
            $Status.Text="해금 레벨 저장 완료 · 규칙 $($saved.rules.revision)"
        } else {
            $saved=Publish-Rules $state.base $d $state.auth;$state.base=$saved;Show-Draft $saved.rules
            $Status.Text="진화 비용 저장 완료 · 규칙 $($saved.rules.revision)"
        }
    }
    catch {$Status.Text=$_.Exception.Message}
})
$window.Add_ContentRendered({Load-Editor})
[void]$window.ShowDialog()

