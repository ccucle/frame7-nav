-- Host adapter. The independently updated catalog engine and its feed stay intact.
local env,engine,resources,pendingEngine
local forward
local geoCraftStatus,localCraft
local hostEnvironment=getfenv(1)
-- Keep host-only controls attached to their panel when the catalog follower moves it.
local followerPanelOffsets={
    SettingsCard={"SettingsVersion","AvatarChoiceTitle","AvatarChoiceCurrent","AvatarChoiceBuddyButton","AvatarChoiceBuddyArt","AvatarChoiceBuddyName","AvatarChoiceRabbitButton","AvatarChoiceRabbitArt","AvatarChoiceRabbitName"},
    CompactCard={"GeoCompactCard","GeoCompactTitle","GeoCompactLevel","GeoCompactXP","GeoCompactGauge","GeoCompactCheckIcon","GeoCompactToday","GeoCompactPowder","GeoCompactRewardIcon","GeoCompactLast","GeoCompactSyncIcon","GeoCompactSync","GeoCompactAt"},
    InfoCard={"GeoInfoLevel","GeoInfoXP","GeoInfoGauge","GeoInfoNext","GeoInfoCheckIcon","GeoInfoToday","GeoInfoPowder","GeoInfoRewardIcon","GeoInfoLast","GeoInfoLastAt","GeoInfoSyncIcon","GeoInfoSync","GeoInfoAt","GeoInfoFooterLine","GeoInfoCraftBg","GeoInfoCraftIcon","GeoInfoCraftText"},
}
local followerPanelHome={}
local function alignFollowerPanel(host,anchor,position)
    local controls=followerPanelOffsets[anchor]
    local x=tonumber(position)
    if not controls or not x then return end
    local offsets=followerPanelHome[anchor]
    if not offsets then
        offsets={}
        local card=host:GetMeter(anchor)
        local left=tonumber(card:GetOption("X")) or card:GetX()
        for _,name in ipairs(controls) do
            local meter=host:GetMeter(name)
            if meter then offsets[name]=(tonumber(meter:GetOption("X")) or meter:GetX())-left end
        end
        followerPanelHome[anchor]=offsets
    end
    for meter,offset in pairs(offsets) do
        if host:GetMeter(meter) then
            host:Bang("!SetOption",meter,"X",tostring(x+offset))
            host:Bang("!UpdateMeter",meter)
        end
    end
end
local function paintCraftStatus(code)
    geoCraftStatus=code
    SKIN:Bang("!SetVariable","GeoCraftStatus",code)
    SKIN:Bang("!SetOption","CraftCost","Text",SKIN:GetVariable("GeoCraft_"..code))
    SKIN:Bang("!UpdateMeter","CraftCost")
    SKIN:Bang("!Redraw")
end
function ClearGeoCraftStatus() paintCraftStatus("ready") end
function GeoCraftClick(index)
    if SKIN:GetVariable("WorkshopOpen")~="1" or SKIN:GetVariable("UnlockAvatar")~="formday-geo" then return end
    if not localCraft then paintCraftStatus("unavailable");return end
    local code=localCraft(index)
    forward("RefreshWallet")
    paintCraftStatus(code=="committed" and "done" or code or "unavailable")
end
local function loadEngine(path)
    local host=SKIN
    env=setmetatable({SELF=SELF}, {__index=getfenv(1)})
    env.SKIN=setmetatable({}, {__index=function(_,k)
        if k=="Bang" then return function(_,command,...)
            local a={...}
            -- Preserve the host adapter when the catalog selects a newer shared engine.
            if command=="!SetOption" and a[1]==SELF:GetName() and a[2]=="ScriptFile" then pendingEngine=a[3];return end
            if command=="!SetOption" and a[2]=="X" then alignFollowerPanel(host,a[1],a[3]) end
            if command=="!SetOption" and a[2]=="LeftMouseUpAction" and host:GetVariable("UnlockAvatar")=="formday-geo" then
                local index=type(a[1])=="string" and a[1]:match("^CraftButton(%d+)$")
                if index then return host:Bang(command,a[1],a[2],'[!CommandMeasure AvatarUnlocks "GeoCraftClick('..index..')"]') end
            end
            if command=="!SetOption" and host:GetVariable("UnlockAvatar")=="formday-geo"
                and (a[2]=="FontColor" or a[2]=="SolidColor") and type(a[1])=="string"
                and a[1]:match("^CraftButton%d+$") and (tonumber(host:GetVariable("Powder")) or 0)>=30 then
                return host:Bang(command,a[1],a[2],a[2]=="FontColor" and "248,250,241" or "64,114,93")
            end
            return host:Bang(command,...)
        end end
        return function(_,...) return host[k](host,...) end
    end})
    -- Match Rainmeter's load lifecycle: SKIN/SELF are injected after the chunk loads.
    -- The catalog intentionally returns its module early when both are already present.
    local proxy=env.SKIN
    env.SKIN=false;env.SELF=false
    local chunk=assert(loadfile(path));setfenv(chunk,env);engine=chunk()
    env.SKIN=proxy;env.SELF=SELF
    assert(rawget(env,"Initialize"),"catalog runtime missing")
    for name,fn in pairs(env) do
        if type(fn)=="function" and name~="Initialize" and name~="Update" and name~="Finalize" then
            local n=name
            hostEnvironment[n]=function(...) return forward(n,...) end
        end
    end
    local connect=engine.connect
    local json=dofile(resources.."json.lua")
    local geo=dofile(resources.."geo-state.lua")
    local function refresh(data)
        local folder=host:GetVariable("SyncFolder").."\\"
        local w=geo.wallet(data,json)
        local d=geo.read(folder,json)
        local row,reason=w.ingest(d,folder,engine.powderRevision and engine.powderAward)
        return w,row,reason
    end
    localCraft=function(index)
        local stone=type(index)=="number" and engine.stoneOrder[index]
        local data=geo.walletPath(host)
        if not stone or not data or data=="" then return "unavailable" end
        local w,row,reason=refresh(data)
        if not row then return reason or "offline" end
        local _,result=w.craft(stone)
        return result
    end
    engine.connect=function(data,avatar,profile,catalog)
        local session=connect(data,avatar,profile,catalog)
        if avatar~="formday-geo" then
            if avatar=="formday-buddy" then
                function session:savedLevel()
                    return tonumber(host:GetVariable("CatalogSavedLevel"))
                end
            end
            return session
        end
        local wallet={xp=0,powder=0,stones={},forms={},sequence=-1,error="unavailable"}
        session.wallet=wallet
        local function show(row,reason)
            local good=row~=nil
            wallet.xp=good and row.xp or 0
            wallet.powder=good and row.powder or 0
            wallet.stones=good and row.stones or {}
            wallet.forms=good and row.forms or {}
            wallet.sequence=good and row.sequence or -1
            wallet.error=not good and (reason or "unavailable") or nil
            return good
        end
        function session:readWallet()
            local _,row,reason=refresh(data)
            return show(row,reason)
        end
        function session:savedLevel()
            if not self:readWallet() then return nil end
            return geo.levelForXp(self.wallet.xp)
        end
        function session:earn() return false end
        function session:craft(stone)
            if not engine.stoneNames[stone] then return false end
            local w,row=refresh(data)
            if not row then return false end
            local after,result=w.craft(stone)
            show(after,result)
            return result=="committed"
        end
        function session:evolve(target)
            local w,row=refresh(data)
            if not row or not self:readWallet() then return false end
            local after,result=w.evolve(target,engine.evolutions[target],function(id) return self:owns(id) end)
            show(after or w.read(),result)
            return result=="committed"
        end
        session:readWallet()
        return session
    end
    local offlineGeo,offlineOwner,offlinePath
    local choose=env.Choose
    if choose then
        env.Choose=function(kind,id)
            -- Keep the normal roster implementation. A stale Notion connection
            -- pauses new rewards, not use of already owned Pokemon.
            if kind=="pokemon" and offlineGeo and host:GetVariable("UnlockEnabled")=="0"
                and host:GetVariable("UnlockAvatar")=="formday-geo"
                and host:GetVariable("UnlockProfile")==offlineOwner and geo.walletPath(host)==offlinePath then
                offlineGeo:readWallet()
                return offlineGeo:togglePokemon(id)
            end
            return choose(kind,id)
        end
    end
    local baseGallery=engine.createGallery
    engine.createGallery=function()
        local g=baseGallery()
        local bind=g.bind
        -- The catalog passes nil while disconnected. Refresh its fallback Geo
        -- session from the same ledger as the workshop before rendering or spending.
        for _,name in ipairs({"open","select","member","evolve","refresh","toggleCompanion"}) do
            local original=g[name]
            if original then g[name]=function(...)
                if offlineGeo then offlineGeo:readWallet() end
                return original(...)
            end end
        end
        g.bind=function(module,items,profile)
            offlineGeo,offlineOwner,offlinePath=nil,nil,nil
            if profile==nil then
                local avatar=host:GetVariable("UnlockAvatar")
                local owner=host:GetVariable("UnlockProfile")
                local path=geo.walletPath(host)
                if (avatar=="formday-buddy" or avatar=="formday-geo") and owner and owner~="" and path then
                    local existing=engine.connect(path,avatar,owner,items)
                    if avatar=="formday-geo" then
                        offlineGeo,offlineOwner,offlinePath=existing,owner,path
                        profile=existing
                    else
                        profile={wallet=existing.wallet,owns=function(_,id)return existing:owns(id) end,
                            selected=function(_,kind)return existing:selected(kind) end,evolve=function()return false end}
                    end
                end
            end
            return bind(module,items,profile)
        end
        return g
    end
end
function Initialize()
    resources=SELF:GetOption("ResourcePath")
    loadEngine(resources.."unlock-engine.lua")
    env.Initialize()
end
forward=function(name,...)
    if pendingEngine then local p=pendingEngine;pendingEngine=nil;loadEngine(p);env.Initialize() end
    if env and env[name] then return env[name](...) end
end

-- Rainmeter discovers lifecycle hooks at script load, before Initialize.

-- Install the lightweight child windows once after the signed Buddy update.
local setupPending,setupRetry,setupDone=false,0,false
local function ensurePokemonWindows()
    if setupDone or setupPending or os.time()<setupRetry then return end
    local root=SKIN:GetVariable("CURRENTPATH").."FormdayPokemon\\"
    local function exists(path)
        local f=io.open(path,"rb")
        if not f then return false end
        f:close();return true
    end
    local ready=exists(root.."roam.lua")
    for i=1,6 do ready=ready and exists(root.."Slot"..i.."\\Pokemon.ini") end
    if ready then setupDone=true;return end
    if not SKIN:GetMeasure("PokemonSetup") then return end
    setupPending=true
    SKIN:Bang("!CommandMeasure","PokemonSetup","Run")
end
function FinishPokemonSetup()
    setupPending=false
    setupRetry=os.time()+60
    local measure=SKIN:GetMeasure("PokemonSetup")
    if measure and measure:GetStringValue():match("^%s*ROAM_READY%s*$") then
        setupDone=true
        SKIN:Bang("!RefreshApp")
    end
end

function Update() ensurePokemonWindows();return forward("Update") end
function Finalize() if env and env.Finalize then return env.Finalize() end end
