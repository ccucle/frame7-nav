-- Local cache of authenticated Geo state. Contains no credential or Notion content.
local G={}
local function integer(v) return type(v)=="number" and v>=0 and v<=100000000 and v==math.floor(v) end
local function key(v) return type(v)=="string" and #v<=80 and v:match("^[a-zA-Z0-9_-]+$") end
function G.levelForXp(xp) return 1+math.floor(xp/30) end
function G.validate(d)
    if type(d)~="table" or d.format~=2 or d.avatar~="formday-geo" or not key(d.owner)
        or (d.connection~="connected" and d.connection~="disconnected") or not integer(d.revision) or type(d.fetched_at)~="number" then return nil end
    local b=d.balance
    if type(b)~="table" then return nil end
    for _,k in ipairs({"base_xp","earned_count","total_xp","powder","level","xp_into_level"}) do if not integer(b[k]) then return nil end end
    if b.total_xp~=b.base_xp+b.earned_count*2 or b.level~=G.levelForXp(b.total_xp)
        or b.xp_into_level~=b.total_xp%30 then return nil end
    if type(b.stones)~="table" or type(b.forms)~="table" then return nil end
    for k,v in pairs(b.stones) do if not key(k) or not integer(v) then return nil end end
    for k,v in pairs(b.forms) do if not key(k) or v~=true then return nil end end
    return d
end
function G.read(folder,json)
    local f=io.open(folder.."geo-live.json","rb")
    if not f then return nil end
    local raw=f:read(65537);f:close()
    if not raw or #raw>65536 then return nil end
    local ok,d=pcall(json.decode,raw)
    return ok and G.validate(d) or nil
end
function G.fresh(d) return d and d.connection=="connected" and math.abs(os.time()-d.fetched_at)<120 end
-- A missing snapshot is normal offline. A known *different* owner cannot use this wallet.
function G.matchesWalletOwner(wallet, snapshot)
    return not wallet or not snapshot or wallet.owner == snapshot.owner
end
function G.pin(data,d)
    if not d then return false end
    local p=data.."geo-owner-v1.txt"
    local f=io.open(p,"rb")
    local owner,revision
    if f then
        for line in f:lines() do
            local o,r=line:match("^([a-zA-Z0-9_-]+)|(%d+)$")
            if o then owner,revision=o,tonumber(r) end
        end
        f:close()
        if not owner or owner~=d.owner or d.revision<revision then return false end
        if d.revision==revision then return true end
    end
    f=io.open(p,"ab");if not f then return false end
    local written=f:write(d.owner.."|"..string.format("%.0f",d.revision).."\n");local closed=f:close()
    return written~=nil and closed
end

-- Geo XP still comes from the account. The stone inventory is now this PC's local wallet.
-- A cloud snapshot seeds it once; only new earned-check counts add powder thereafter.
-- Full-state receipts are committed one at a time by a no-replace rename on Windows.
local ledgers={}
function G.walletPath(skin)
    local path=skin:GetVariable("UnlockDataPath")
    if path and path~="" then return path end
    return skin:GetVariable("CURRENTPATH")
end
function G.wallet(data,json)
    if ledgers[data] then return ledgers[data] end
    local last,seq,broken=nil,0,false
    local prefix=data.."geo-local-wallet-v1-"
    local pending=prefix..tostring({}):gsub("[^a-zA-Z0-9]","").."-"..os.time()..".tmp"
    local function nextPath() return prefix..string.format("%08d",seq+1)..".json" end
    local function decode(f)
        local bytes=f:read(65537);f:close()
        if not bytes or #bytes>65536 then return nil end
        local ok,r=pcall(json.decode,bytes)
        if not ok or type(r)~="table" or r.sequence~=seq+1 or not key(r.owner)
            or not integer(r.earned) or not integer(r.xp) or type(r.powder)~="number" or r.powder<0 or r.powder>9007199254740991 or r.powder~=math.floor(r.powder)
            or type(r.stones)~="table" or type(r.forms)~="table" then return nil end
        if last and (r.owner~=last.owner or r.earned<last.earned or r.xp<last.xp) then return nil end
        for k,v in pairs(r.stones) do if not key(k) or not integer(v) then return nil end end
        for k,v in pairs(r.forms) do if not key(k) or v~=true then return nil end end
        return r
    end
    local function read()
        if broken then return nil,"write" end
        while true do
            local f=io.open(nextPath(),"rb")
            if not f then return last end
            local value=decode(f)
            if not value then broken=true;return nil,"write" end
            last=value;seq=value.sequence
        end
    end
    local function shallow(t)
        local copy={}
        for k,v in pairs(t) do copy[k]=v end
        return copy
    end
    local function transact(build)
        for _=1,5 do
            local prev,err=read()
            if err then return nil,err end
            local r,reason=build(prev)
            if not r then return prev,reason end
            r.sequence=seq+1
            local target=nextPath()
            local f=io.open(pending,"wb")
            if not f then return prev,"write" end
            local written=f:write(json.encode(r))
            local closed=f:close()
            if not written or not closed then os.remove(pending);return prev,"write" end
            if os.rename(pending,target) then
                last=r;seq=r.sequence
                return r,"committed"
            end
            os.remove(pending)
            local conflict=io.open(target,"rb")
            if not conflict then return prev,"write" end
            conflict:close()
        end
        return last,"write"
    end
    local L={read=read}
    function L.ingest(d,folder,award)
        local row, reason=transact(function(prev)
            if not G.matchesWalletOwner(prev, d) then return nil,"owner-mismatch" end
            if not d or not G.pin(data,d) then return nil,prev and "unchanged" or "offline" end
            local b=d.balance
            if not prev then
                local old=io.open(folder.."geo-request.json","rb")
                if old then old:close();return nil,"legacy" end
                return {owner=d.owner,earned=b.earned_count,xp=b.total_xp,powder=b.powder,stones=shallow(b.stones),forms=shallow(b.forms)}
            end
            if b.earned_count<=prev.earned and b.total_xp<=prev.xp then return nil,"unchanged" end
            local delta=math.max(0,b.total_xp-prev.xp)
            if delta>0 and not award then return nil,"unchanged" end
            local extra=delta>0 and award(delta) or 0
            if extra>9007199254740991-prev.powder then return nil,"write" end
            local r=shallow(prev)
            r.powder=prev.powder+extra
            if delta>0 then
                local event=type(d.reward_activity)=="table" and d.reward_activity.last_award
                r.lastAwardAt=type(event)=="table" and tonumber(event.at) or nil
                r.lastAwardPowder=type(event)=="table" and event.xp==2 and award(2) or nil
            end
            r.xp=math.max(prev.xp,b.total_xp);r.earned=math.max(prev.earned,b.earned_count)
            return r
        end)
        -- transact returns the prior row on a no-op. Do not expose it as a spending session on mismatch.
        if reason=="owner-mismatch" then return nil,"unavailable" end
        return row,reason
    end
    function L.craft(stone)
        return transact(function(prev)
            if not prev then return nil,"offline" end
            if prev.powder<30 then return nil,"low" end
            local r=shallow(prev);r.stones=shallow(prev.stones)
            r.powder=prev.powder-30;r.stones[stone]=(r.stones[stone] or 0)+1
            return r
        end)
    end
    function L.evolve(target,rule,owns)
        return transact(function(prev)
            if not prev then return nil,"offline" end
            if not rule or not owns(rule.parent) or prev.forms[target] or owns(target)
                or (prev.stones[rule.stone] or 0)<rule.cost then return nil,"unavailable" end
            local r=shallow(prev);r.stones=shallow(prev.stones);r.forms=shallow(prev.forms)
            r.stones[rule.stone]=r.stones[rule.stone]-rule.cost;r.forms[target]=true
            return r
        end)
    end
    ledgers[data]=L
    return L
end
return G
