-- Pixel button backgrounds are painted on existing Shape meters so older hosts
-- receive the same controls through a catalog-only update.
local palette={
    idle={"66,83,75","231,229,203","253,249,223"},
    selected={"43,78,66","161,211,174","211,238,197"},
    action={"95,68,37","246,196,113","255,226,162"},
    dark={"24,44,46","70,103,99","96,137,127"},
    muted={"152,158,141","219,220,205","234,234,220"},
    owned={"82,115,89","225,237,211","247,248,222"},
    locked={"141,152,138","230,229,217","247,244,228"}
}
local painted={}
local function paint(meter,first,x,y,w,h,style)
    local key=meter..":"..first
    local signature=table.concat({x,y,w,h,style or "none"},",")
    if painted[key]==signature then return end
    painted[key]=signature
    local function shape(i,value)
        local n=first+i
        setting(meter,n==1 and "Shape" or "Shape"..n,value)
    end
    if not style then
        for i=0,2 do shape(i,"Rectangle 0,0,0,0 | StrokeWidth 0") end
        return
    end
    local colors=palette[style]
    local function stepped(i,dx,dy,ww,hh,corner,color)
        local left,top=x+dx,y+dy
        local right,bottom=left+ww,top+hh
        local p=string.format("%d,%d",left+corner,top)
        for _,point in ipairs({{right-corner,top},{right-corner,top+corner},{right,top+corner},
            {right,bottom-corner},{right-corner,bottom-corner},{right-corner,bottom},
            {left+corner,bottom},{left+corner,bottom-corner},{left,bottom-corner},
            {left,top+corner},{left+corner,top+corner}}) do
            p=p..string.format(" | LineTo %d,%d",point[1],point[2])
        end
        local name="PixelPath"..(first+i)
        setting(meter,name,p.." | ClosePath 1")
        shape(i,"Path "..name.." | StrokeWidth 0 | Fill Color "..color)
    end
    stepped(0,0,0,w,h,3,colors[1])
    stepped(1,1,1,w-2,h-4,2,colors[2])
    shape(2,string.format("Rectangle %d,%d,%d,1 | StrokeWidth 0 | Fill Color %s",x+4,y+2,w-8,colors[3]))
end

local buttonLayout={
    {"GalleryBack",155,9,72,25},{"GalleryClose",270,9,46,25},
    {"GalleryPrev",105,415,29,25},{"GalleryPageNumber",137,415,62,25},
    {"GalleryNext",202,415,29,25},{"GalleryUpdates",237,415,79,25}
}
local function placeButtons()
    for _,b in ipairs(buttonLayout) do
        local name,x,y,w,h=unpack(b)
        setting(name,"X",panelX+x+math.floor(w/2))
        setting(name,"Y",panelY+y)
        setting(name,"W",w)
        setting(name,"H",h-4)
        setting(name,"Padding","0,4,0,0")
        setting(name,"StringAlign","Center")
        setting(name,"FontSize",9)
        setting(name,"SolidColor","0,0,0,1")
        setting(name,"FontColor",y<40 and "255,250,225" or "44,61,53")
    end
end
local function drawButtons(isDetail,pageNumber,pageCount,follow,canEvolve,hasRule)
    for i=1,3 do
        paint("GalleryCard",4+(i-1)*3,13+(i-1)*103,54,96,30,i==tab and "selected" or "idle")
        setting("GalleryTabBg"..i,"SolidColor","0,0,0,1")
    end
    local styles={"dark","dark",not isDetail and pageNumber>1 and "idle",
        isDetail and (follow and "selected" or hasRule and (canEvolve and "action" or "muted"))
            or not isDetail and pageCount>1 and "idle",
        not isDetail and pageNumber<pageCount and "idle",not generationMenuOpen and "idle"}
    for i,b in ipairs(buttonLayout) do
        paint("GalleryCard",13+(i-1)*3,b[2],b[3],b[4],b[5],styles[i])
    end
end
