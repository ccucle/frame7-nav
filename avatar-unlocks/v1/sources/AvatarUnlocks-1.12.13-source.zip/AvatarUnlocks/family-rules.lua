-- Shared family settings. Each document advances its own revision independently.
local function isIntegerInRange(value, minimum, maximum)
    return type(value) == "number" and value >= minimum and value <= maximum
        and value == math.floor(value)
end

local function isNewFamilyDocument(document, previousRevision)
    return type(document) == "table"
        and document.schema == 1
        and isIntegerInRange(document.revision, 1, 2147483647)
        and document.revision > (previousRevision or 0)
end

function M.applyCostRules(document)
    if not isNewFamilyDocument(document, M.costRevision)
        or type(document.overrides) ~= "table"
        or not isIntegerInRange(document.first, 1, 999)
        or not isIntegerInRange(document.second, 1, 999) then
        return false
    end
    for edge, cost in pairs(document.overrides) do
        if type(edge) ~= "string" or #edge > 98
            or not edge:match("^[a-z0-9_-]+/[a-z0-9_-]+$")
            or not isIntegerInRange(cost, 1, 999) then
            return false
        end
    end
    -- Validate the entire document before changing any active evolution cost.
    for target, rule in pairs(M.evolutions) do
        rule.stage = rule.stage or rule.cost
        local defaultCost = rule.stage == 1 and document.first or document.second
        rule.cost = document.overrides[rule.parent .. "/" .. target] or defaultCost
    end
    M.costRevision = document.revision
    return true
end

M.powderPerXp = 5

function M.applyPowderRules(document)
    if not isNewFamilyDocument(document, M.powderRevision)
        or not isIntegerInRange(document.powderPerXp, 0, 999) then
        return false
    end
    M.powderPerXp = document.powderPerXp
    M.powderRevision = document.revision
    return true
end

-- Only base Pokémon, pets and outfits can receive a level override.
M.levelKinds = {}
M.familyLevels = {}
for _, item in ipairs(M.gallery) do
    if item.kind ~= "pokemon" or not M.evolutions[item.id] then
        M.levelKinds[item.id] = item.kind
    end
end

function M.applyLevelRules(document)
    if not isNewFamilyDocument(document, M.levelRevision) or type(document.levels) ~= "table" then
        return false
    end
    local levels = {}
    for id, level in pairs(document.levels) do
        if type(id) ~= "string" or #id > 48 or not id:match("^[a-z0-9_-]+$")
            or not isIntegerInRange(level, 1, 999) then
            return false
        end
        local kind = M.levelKinds[id]
        if kind then
            if kind == "pokemon" and level > 20 then return false end
            levels[id] = level
        elseif M.evolutions[id] then
            return false
        end
        -- Unknown IDs can belong to a newer catalog. Leave them out of this catalog.
    end
    M.familyLevels = levels
    M.levelRevision = document.revision
    return true
end

function M.withFamilyLevels(items)
    if not next(M.familyLevels) then return items end
    local result, existing = {}, {}
    for _, item in ipairs(items) do
        local level = M.familyLevels[item.id]
        if level then
            result[#result + 1] = { id = item.id, kind = item.kind, level = level, name = item.name }
        else
            result[#result + 1] = item
        end
        existing[item.id] = true
    end
    for id, level in pairs(M.familyLevels) do
        if not existing[id] then
            result[#result + 1] = { id = id, kind = M.levelKinds[id], level = level }
        end
    end
    return result
end
