"""End-to-end recovery checks using only public program files and generated game data."""
import argparse
import hashlib
import json
import os
import re
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
TOOL = HERE.parent / "avatar_backup.py"
MODULES = ("json.lua", "progress.lua", "geo-state.lua", "avatarprofiles.lua")
BUDDY_HASH = "1df594c67925544606c36fee7c7144a51a4b5cadef66fa7342f4b94047a0761b"
CATALOG_HASH = "ea1a44b33168aa65c3b263a61e987438b6742fcde347b61fdd8948dbc5590704"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(*args, ok=True):
    result = subprocess.run([sys.executable, str(TOOL), *map(str, args)], capture_output=True, text=True)
    if (result.returncode == 0) != ok:
        raise RuntimeError(result.stdout + result.stderr)
    return result.stdout


def write(folder, name, obj):
    (folder / name).write_text(json.dumps(obj), encoding="utf-8")


def fixtures(host, sync, rules):
    events = [{"id": label, "type": "meal", "repeat": "none", "date": "2026-11-01",
               "completed": True} for label in ("old", "new")]
    write(host, "formday.json", {"app": "formday", "version": 1, "events": events})
    write(host, "start.json", {"format": 1, "checked": {"2026-11-01:old": True}})
    write(sync, "buddy-start.json", {"format": 1, "uid": "fixture-buddy", "keys": ["old"]})
    for kind, fields in (("unlock-levels", {"levels": {"kirby": 1, "octopus": 4}}),
                         ("powder", {"powderPerXp": 5}), ("evolution", {"first": 2, "second": 4, "overrides": {}})):
        for rev, suffix in ((2, ""), (1, ".previous")):
            write(rules, "family-" + kind + ".json" + suffix, {"schema": 1, "revision": rev, **fields})
    for folder, name in [(host, "preferences.ini"), (rules, "family-editor-pin-v1.json"),
                         (sync, "geo-live.json"), (host, "unrelated.txt")]:
        (folder / name).write_text("synthetic excluded entry")


def files(folder):
    return {p.relative_to(folder): (digest(p), p.stat().st_mtime_ns)
            for p in folder.rglob("*") if p.is_file()}


def run_case(root, resources, engine, split):
    source = root / "source"
    host = source / "host"
    records = source / ("records" if split else "host")
    sync, rules = source / "sync", source / "rules"
    for p in {host, records, sync, rules}:
        p.mkdir(parents=True)
    fixtures(host, sync, rules)

    def replay(mode, h, r, s, f):
        subprocess.run([os.environ.get("FORMDAY_TEST_LUA", "texlua"), str(HERE / "replay.lua"), str(resources), str(engine),
                        str(h), str(r), str(s), str(f), mode], check=True)

    replay("seed", host, records, sync, rules)
    before = files(source)
    version = re.fullmatch(rb"-- avatar-unlocks/v1 ([0-9.]+)", engine.read_bytes().splitlines()[0]).group(1).decode("ascii")
    pack = ["--host", host, "--records", records, "--sync", sync, "--rules", rules,
            "--buddy-version", "0.6.27", "--catalog-version", version]
    archive, target = root / "snapshot.zip", root / "recovery"
    command("pack", archive, *pack, "--include-legacy-calendar")
    original_archive_hash = digest(archive)
    command("pack", archive, *pack, ok=False)
    assert digest(archive) == original_archive_hash
    command("verify", archive)
    command("restore", archive, target)
    assert files(source) == before
    extracted = target / "records"
    with zipfile.ZipFile(archive) as z:
        doc = json.loads(z.read("manifest.json"))
        assert doc["folders"]["records"] == ("records" if split else "host")
        expected = {str(p).replace("\\", "/"): h for p, (h, _) in before.items()
                    if p.name not in {"preferences.ini","family-editor-pin-v1.json","geo-live.json","unrelated.txt"}}
        assert doc["files"] == expected
        for name, hashed in expected.items():
            assert digest(extracted / name) == hashed
    mapped = [extracted / doc["folders"][k] for k in ("host","records","sync","rules")]
    unchanged = files(extracted)
    replay("verify", *mapped)
    assert files(extracted) == unchanged
    command("restore", archive, target, ok=False)
    assert files(extracted) == unchanged
    replay("advance", *mapped)
    assert files(source) == before
    replay("advance", host, records, sync, rules)
    # Geo JSON uses unordered Lua tables: compare records structurally for independently produced events.
    restored_files = files(extracted)
    current_source = files(source)
    assert set(restored_files) == set(current_source) - (set(before) - set(unchanged))
    for name, (value, _) in restored_files.items():
        if name.suffix == ".json":
            assert json.loads((source / name).read_bytes()) == json.loads((extracted / name).read_bytes())
        else:
            assert digest(source / name) == value
    default_archive = root / "personal.zip"
    command("pack", default_archive, *pack)
    with zipfile.ZipFile(default_archive) as z:
        assert not any(n.endswith("/formday.json") for n in z.namelist())
    with zipfile.ZipFile(archive) as old, zipfile.ZipFile(root / "damaged.zip", "w") as bad:
        for name in old.namelist():
            body = old.read(name)
            bad.writestr(name, body + b"!" if name.endswith("avatar-progress-v1.txt") else body)
    command("verify", root / "damaged.zip", ok=False)
    command("restore", root / "damaged.zip", root / "failed-recovery", ok=False)
    assert not (root / "failed-recovery").exists()
    pending = sync / "geo-request.json"
    pending.write_text('{"synthetic":true}')
    command("pack", root / "pending.zip", *pack, ok=False)
    assert not (root / "pending.zip").exists()
    pending.unlink()
    receipt = next(records.glob("*wallet-000000002.txn"))
    receipt.unlink()
    command("pack", root / "gap.zip", *pack, ok=False)
    assert not (root / "gap.zip").exists()
    print(f"PASS {'separate' if split else 'shared'} folders: {len(expected)} files restored byte for byte", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("buddy_zip", type=Path)
    parser.add_argument("catalog", type=Path)
    parser.add_argument("--candidate-resources", type=Path, help="use these prepared Buddy Lua modules")
    parser.add_argument("--candidate-catalog", type=Path, help="use this assembled catalog in the replay")
    args = parser.parse_args()
    if digest(args.buddy_zip) != BUDDY_HASH or digest(args.catalog) != CATALOG_HASH:
        raise ValueError("Expected released Buddy 0.6.27 ZIP and catalog 1.12.4 Lua")
    with tempfile.TemporaryDirectory() as temp:
        root = Path(temp)
        resources = root / "modules"
        resources.mkdir()
        with zipfile.ZipFile(args.buddy_zip) as z:
            for name in MODULES:
                (resources / name).write_bytes(z.read(name))
        if args.candidate_resources:
            for name in MODULES:
                path = args.candidate_resources / name
                if path.is_file():
                    shutil.copyfile(path, resources / name)
        for split in (False, True):
            run_case(root / str(split), resources, (args.candidate_catalog or args.catalog).resolve(), split)


if __name__ == "__main__":
    main()
