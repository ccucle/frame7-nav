-- Exercise the actual progress, catalog and two wallet implementations in a fresh Lua process.
local resources, catalogFile, host, data, sync, rules, mode = table.unpack(arg)
local function module(name) return dofile(resources.."/"..name..".lua") end
local json, engine = module("json"), dofile(catalogFile)
local profiles, geo, progress = module("avatarprofiles"), module("geo-state"), module("progress")
local function document(folder, name)
    local file=assert(io.open(folder.."/"..name,"rb"))
    local raw=file:read("*a")
    file:close()
    return json.decode(raw)
end
assert(engine.applyLevelRules(document(rules,"family-unlock-levels.json")))
assert(engine.applyCostRules(document(rules,"family-evolution.json")))
assert(engine.applyPowderRules(document(rules,"family-powder.json")))
local points=progress.calculate(document(host,"formday.json"), document(host,"start.json").checked)
assert(points.count==2 and points.xp==3, "legacy calendar credited an old meal")
local localStart=document(sync,"buddy-start.json")
assert(localStart.format==1 and localStart.uid=="fixture-buddy" and #localStart.keys==1)
profiles.init(host.."/")
local buddy, rabbit="formday-buddy","formday-geo"
local owner=engine.connect(data.."/",buddy,"owner",{})
local guest=engine.connect(data.."/",buddy,"guest",{})
local gbook=engine.connect(data.."/",rabbit,"owner",{})
local ledger=geo.wallet(data.."/",json)
local count=mode=="advance" and 1 or 0
local geoXP=90+count*2
local snapshot={format=2,avatar=rabbit,owner="fixture-geo",connection="connected",revision=1+count,
    fetched_at=1700000000,balance={base_xp=90,earned_count=count,total_xp=geoXP,powder=150,
    level=1+math.floor(geoXP/30),xp_into_level=geoXP%30,stones={leaf=3},forms={}}}
assert(geo.validate(snapshot))
if mode=="seed" then
    assert(profiles.observe("localraw",75))
    assert(profiles.server(snapshot.balance))
    assert(profiles.select(rabbit))
    assert(geo.pin(host.."/",snapshot))
    owner:sync(4)
    guest:sync(1)
    gbook:sync(4)
    owner:select("pet","kirby")
    gbook:select("pet","octopus")
    owner:select("outfit","hoodie")
    gbook:select("outfit","tracksuit")
    assert(owner:togglePokemon("bulbasaur") and gbook:togglePokemon("charmander"))
    assert(owner:earn(75) and guest:earn(9))
    local rule=engine.evolutions.ivysaur
    for i=1,rule.cost do assert(owner:craft(rule.stone)) end
    assert(owner:evolve("ivysaur"))
    assert(ledger.ingest(snapshot,sync.."/",engine.powderAward))
    local _,craft=ledger.craft("leaf")
    assert(craft=="committed")
    local _,evolve=ledger.evolve("ivysaur",rule,function(id) return gbook:owns(id) end)
    assert(evolve=="committed")
end
local previous=assert(ledger.read())
if mode=="advance" then
    assert(owner:earn(77))
    assert(profiles.observe("localraw",77))
    assert(profiles.server(snapshot.balance))
    assert(geo.pin(host.."/",snapshot))
end
local current, reason=ledger.ingest(snapshot,sync.."/",engine.powderAward)
assert(current and (mode=="advance" and reason=="committed" or mode~="advance" and reason=="unchanged"))
assert(profiles.id()==rabbit and profiles.xp()==geoXP)
assert(profiles.observe("localraw",mode=="advance" and 77 or 75))
assert(profiles.server(snapshot.balance))
local buddyXP=mode=="advance" and 77 or 75
assert(not owner:earn(buddyXP) and not guest:earn(9))
local again=assert(ledger.ingest(snapshot,sync.."/",engine.powderAward))
assert(current.sequence==again.sequence)
assert(owner.wallet.xp==buddyXP and owner.wallet.powder==buddyXP*5-60 and owner.wallet.forms.ivysaur)
assert(guest.wallet.xp==9 and guest.wallet.powder==45 and guest:selected("pet")==nil)
assert(owner:selected("pet")=="kirby" and table.concat(owner:roster(),",")=="bulbasaur")
assert(gbook:selected("pet")=="octopus" and table.concat(gbook:roster(),",")=="charmander")
assert(current.xp==geoXP and current.powder==120+count*10 and current.stones.leaf==2 and current.forms.ivysaur)
assert(current.owner=="fixture-geo")
assert(owner:selected("outfit")=="hoodie" and gbook:selected("outfit")=="tracksuit")
assert(owner:owns("bulbasaur") and owner:owns("ivysaur") and gbook:owns("bulbasaur"))
local progressFile=assert(io.open(host.."/avatar-progress-v1.txt","rb"))
local lastLine
for line in progressFile:lines() do if line~="" then lastLine=line end end
progressFile:close()
local active,buddyTotal,geoTotal=lastLine:match("^1|([^|]+)|(%d+)|(%d+)|")
assert(active==rabbit and tonumber(buddyTotal)==buddyXP and tonumber(geoTotal)==geoXP)
if mode=="advance" then assert(current.sequence==previous.sequence+1) end
print("PASS "..mode..": XP, powder, stones, evolution, selected pets, roster, baselines, replay")
