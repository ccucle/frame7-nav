"""Capture supported Formday desktop records and restore a verified copy to a new directory."""
import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import tempfile
from zipfile import BadZipFile, ZIP_DEFLATED, ZipFile

FORMAT = "formday-avatar-records/1"
KEY = r"[a-z0-9][a-z0-9_-]{0,47}"
PERSONAL = re.compile(rf"unlock~{KEY}~{KEY}~(?:{KEY}\.(?:owned|selection)|wallet-[0-9]{{9,}}\.txn)")
GEO = re.compile(r"geo-local-wallet-v1-[0-9]{8,}\.json")
RULE_FILES = {f"family-{kind}.json{suffix}" for kind in ("unlock-levels", "evolution", "powder")
              for suffix in ("", ".previous")}
FIXED = {"host": {"avatar-progress-v1.txt", "start.json", "geo-owner-v1.txt"},
         "records": {"geo-owner-v1.txt"}, "sync": {"buddy-start.json"}, "rules": RULE_FILES, "calendar": {"formday.json"}}
MANIFEST = "manifest.json"


def accepts(role, name):
    return (name in FIXED[role] or
            role == "records" and (PERSONAL.fullmatch(name) or GEO.fullmatch(name)))


def layout(paths):
    folders, roles = {}, {}
    for role, path in paths.items():
        if path is None:
            continue
        path = path.resolve(strict=True)
        if not path.is_dir():
            raise ValueError(f"{role} must name an existing directory")
        group = folders.setdefault(path, role)
        roles[role] = group
    return folders, roles


def inventory(folders, roles):
    entries = {}
    for folder, group in folders.items():
        active = [role for role in roles if roles[role] == group]
        if "sync" in active and (folder / "geo-request.json").exists():
            raise ValueError("Legacy pending Geo request present. Resolve its state before capturing this set.")
        for path in folder.iterdir():
            if any(accepts(role, path.name) for role in active):
                info = path.lstat()
                if not stat.S_ISREG(info.st_mode) or getattr(info, "st_file_attributes", 0) & 1024:
                    raise ValueError(f"Expected a regular data file: {path.name}")
                entries[f"{group}/{path.name}"] = path
    return entries


def transfer(source, destination=None):
    digest = hashlib.sha256()
    for chunk in iter(lambda: source.read(1024 * 1024), b""):
        digest.update(chunk)
        if destination is not None:
            destination.write(chunk)
    return digest.hexdigest()


def check_sequences(names):
    sequences = defaultdict(list)
    for name in names:
        match = re.fullmatch(r"(.+(?:~wallet-|/geo-local-wallet-v1-))([0-9]+)\.(?:txn|json)", name)
        if match:
            number = int(match[2])
            width = 9 if name.endswith(".txn") else 8
            if number == 0 or f"{number:0{width}d}" != match[2]:
                raise ValueError(f"Unsupported receipt number: {name}")
            sequences[match[1]].append(number)
    for prefix, sequence in sequences.items():
        if any(value != index for index, value in enumerate(sorted(sequence), 1)):
            raise ValueError(f"Missing or duplicate receipt in {prefix}")


def validate_manifest(doc, names):
    if not isinstance(doc, dict) or doc.get("format") != FORMAT:
        raise ValueError("Unsupported backup format")
    roles, files = doc.get("folders"), doc.get("files")
    if not isinstance(roles, dict) or not {"host", "records"} <= roles.keys() <= FIXED.keys():
        raise ValueError("Invalid folder mapping")
    if any(not isinstance(dest, str) or dest not in roles or roles[dest] != dest for dest in roles.values()):
        raise ValueError("Invalid shared directory mapping")
    if "calendar" in roles and roles["calendar"] != roles["host"]:
        raise ValueError("Legacy calendar must be located with host Data")
    if not isinstance(files, dict) or not files or set(names) != set(files) | {MANIFEST}:
        raise ValueError("Archive and manifest contents differ")
    has_personal = False
    for key, digest in files.items():
        group, sep, name = key.partition("/")
        scoped = [role for role in roles if roles[role] == group]
        if not sep or not any(accepts(role, name) for role in scoped):
            raise ValueError(f"Unrecognized entry: {key}")
        if not isinstance(digest, str) or not re.fullmatch(r"[a-f0-9]{64}", digest):
            raise ValueError(f"Invalid digest for {key}")
        has_personal |= any(role != "rules" and accepts(role, name) for role in scoped)
    if not has_personal:
        raise ValueError("No personal progress, ownership, selections or wallet records found")
    check_sequences(files)


def verified_copy(archive, target=None):
    with ZipFile(archive) as z:
        names = z.namelist()
        if MANIFEST not in names or len(set(names)) != len(names):
            raise ValueError("Missing manifest or duplicate archive entry")
        doc = json.loads(z.read(MANIFEST))
        validate_manifest(doc, names)
        if target is not None:
            for group in set(doc["folders"].values()):
                (target / group).mkdir()
        for name, expected in doc["files"].items():
            with z.open(name) as source:
                if target is None:
                    actual = transfer(source)
                else:
                    with (target / name).open("xb") as destination:
                        actual = transfer(source, destination)
            if expected != actual:
                raise ValueError(f"SHA-256 mismatch: {name}")
    return doc


def pack(paths, archive, buddy_version, catalog_version):
    folders, roles = layout(paths)
    if archive.is_symlink() or archive.exists():
        raise FileExistsError(archive)
    entries = inventory(folders, roles)
    check_sequences(entries)
    hashes = {}
    with tempfile.TemporaryDirectory(dir=archive.parent, prefix=".avatar-capture-") as temp:
        staged = Path(temp) / "snapshot.zip"
        with ZipFile(staged, "w", compression=ZIP_DEFLATED) as z:
            for name, path in sorted(entries.items()):
                with path.open("rb") as source, z.open(name, "w", force_zip64=True) as destination:
                    hashes[name] = transfer(source, destination)
            doc = {"format": FORMAT, "created_utc": datetime.now(timezone.utc).isoformat(),
                   "operator_versions": {"buddy": buddy_version, "catalog": catalog_version},
                   "folders": roles, "files": hashes}
            z.writestr(MANIFEST, json.dumps(doc, indent=2, sort_keys=True))
        if inventory(folders, roles) != entries:
            raise ValueError("Files changed during capture; retry with writers paused")
        for name, path in entries.items():
            with path.open("rb") as source:
                if transfer(source) != hashes[name]:
                    raise ValueError(f"Record changed during capture: {name}")
        verified_copy(staged)
        # Same-volume publication, without replacing even a concurrently created backup.
        if os.name == "nt":
            os.rename(staged, archive)  # Windows refuses an existing destination.
        else:
            os.link(staged, archive)
    return doc


def restore(archive, target):
    # Reserve a new destination. Existing files and directories, including empty ones, belong to the user.
    target.mkdir()
    try:
        with tempfile.TemporaryDirectory(dir=target, prefix=".restore-") as temp:
            staged = Path(temp) / "records"
            staged.mkdir()
            doc = verified_copy(archive, staged)
            staged.rename(target / "records")
    except BaseException:
        # This removes only our empty reservation. Never recursively delete a user destination.
        if not any(target.iterdir()):
            target.rmdir()
        raise
    return doc


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="action", required=True)
    create = commands.add_parser("pack")
    create.add_argument("archive", type=Path)
    create.add_argument("--host", required=True, type=Path, help="skin's Data directory")
    create.add_argument("--records", type=Path, help="effective UnlockDataPath; defaults to --host")
    create.add_argument("--include-legacy-calendar", action="store_true",
                        help="include host Data/formday.json (may contain personal health records)")
    create.add_argument("--sync", type=Path, help="effective SyncFolder (local Connect baseline)")
    create.add_argument("--rules", type=Path, help="family cache directory")
    create.add_argument("--buddy-version", required=True)
    create.add_argument("--catalog-version", required=True)
    verify = commands.add_parser("verify")
    verify.add_argument("archive", type=Path)
    recover = commands.add_parser("restore")
    recover.add_argument("archive", type=Path)
    recover.add_argument("new_directory", type=Path)
    args = parser.parse_args()
    if args.action == "pack":
        result = pack({"host": args.host, "records": args.records or args.host,
                       "sync": args.sync, "rules": args.rules,
                       "calendar": args.host if args.include_legacy_calendar else None}, args.archive,
                      args.buddy_version, args.catalog_version)
    elif args.action == "restore":
        result = restore(args.archive, args.new_directory)
    else:
        result = verified_copy(args.archive)
    print(f"{args.action}: {len(result['files'])} files")
    for role, group in result["folders"].items():
        count = sum(1 for key in result["files"] if key.startswith(group + "/")
                    and accepts(role, key.partition("/")[2]))
        print(f"  {role} -> {group} ({count} matched files)")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, BadZipFile, RuntimeError) as error:
        raise SystemExit(str(error))
