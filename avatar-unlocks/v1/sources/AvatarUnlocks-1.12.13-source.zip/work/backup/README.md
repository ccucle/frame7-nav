# ④ 아바타 개인 기록 백업·복원

관리 시스템 인계 DM-20261127-06. 공개 Buddy 0.6.27, 도감 1.12.4, 그리고 ③ 소스 변경안의 복원 동작을 가상 자료로 검수했다. `avatar_backup.py`는 로컬 파일 단위로 사본을 만드는 독립 검수 도구다. 실행 환경은 Python 3.8 이상이다. 정식 스킨과 자동 업데이트에는 포함되지 않는다.

## 어떤 파일을 읽는가

| 입력 | 원본 코드가 사용하는 위치 | 수집하는 자료 |
| --- | --- | --- |
| `--host` | 스킨의 `#CURRENTPATH#Data\` | `avatar-progress-v1.txt`의 선택 아바타·두 XP·처리 기준, `start.json`의 수동 캘린더 최초 기준, `geo-owner-v1.txt`의 본체 계정 확인 기록 |
| `--records` | 유효한 `UnlockDataPath`. 기본 설치는 위 Data 폴더다. 스킨 설정이 빈 문자열이면 도감은 `#CURRENTPATH#`를 사용한다. | 아바타·프로필별 `.owned`, `.selection`, 뿔동이 거래 `.txn`. 지오 로컬 지갑의 `geo-local-wallet-v1-########.json`과 `geo-owner-v1.txt` |
| `--sync` | 실제 `SyncFolder`. 공개 설정 기본값은 `%USERPROFILE%\FormdayBuddy\Data` | Connect가 기기 기준 모드에서 쓰는 `buddy-start.json`. 계정 기준 모드는 별도로 서버의 `formday_sync/buddy`를 사용한다. |
| `--rules` | `%LOCALAPPDATA%\FormdayAvatar\Unlocks\v1` | `family-unlock-levels.json`, `family-evolution.json`, `family-powder.json`과 각 파일에 존재하는 `.previous` 사본 |
| `--include-legacy-calendar` | 호스트의 `Data/formday.json` | 명시한 경우에만 구형 수동 캘린더 원천을 함께 담는다. 개인 운동·식단 정보가 포함될 수 있다. |

`--records`를 생략하면 도구는 `--host` 경로를 사용한다. 실제 설정이 다르면 유효한 폴더를 지정한다. `--sync`와 `--rules`는 지정한 폴더만 검사한다. 같은 폴더를 여러 역할에 지정하면 한 번만 보관하며, 원래 어떤 역할이 폴더를 공유했는지 목록에 기록한다. 입력 파일 목록은 `FIXED`, 개인 기록의 파일명 규칙은 `PERSONAL`과 `GEO`에서 관리한다.

ZIP에는 파일별 SHA-256, 폴더 역할, UTC 생성 시각, 실행자가 입력한 본체·도감 버전이 들어간다. 버전은 도구가 PC에서 자동 판독한 값이 아니다. ZIP은 암호화되지 않으며 로컬 계정 식별자와 지급 기록을 포함할 수 있다. 서버 원장·인증 정보·브라우저 권한·실시간 수신 캐시·기기 설정은 수집 범위 밖이다.

## 검수용 사본 만들기

아래 경로는 예시다. 운영 복구에 앞서 사본에서 사용한다. 실제 PC에서 일관된 기준 시점이 필요하면 스킨과 연결 탭의 파일 쓰기를 잠시 멈춘 상태에서 캡처한다.

```powershell
py -3 avatar_backup.py pack D:\Review\avatar-test.zip --host D:\Fixture\SkinData --records D:\Fixture\Wallet --sync D:\Fixture\Sync --rules D:\Fixture\Rules --buddy-version 0.6.27 --catalog-version 1.12.4
py -3 avatar_backup.py verify D:\Review\avatar-test.zip
py -3 avatar_backup.py restore D:\Review\avatar-test.zip D:\Review\Restored-01
```

출력 ZIP의 상위 폴더가 있어야 한다. 복원 대상 경로는 **새 이름**이어야 한다. 복원 자료는 그 안의 `records/` 아래에 역할별로 놓인다. 도구는 완료 전 파일 목록과 내용을 다시 대조하고, 원장 번호가 중간에 비거나 기존 파일의 내용이 달라진 백업을 거부한다. 기존 백업·복원 폴더를 지정하면 중단한다. 구형 지오 요청 `geo-request.json`이 지정한 동기화 폴더에 남아 있는 경우에도 기존 요청의 상태를 확인하도록 중단한다. 여러 PC 사이의 병합이나 이전 백업으로 운영 데이터를 덮어쓰는 기능은 제공하지 않는다.

## 검수 재현

Linux의 Python 3 및 texlua에서 아래 명령으로 공개 원본을 재현할 수 있다. 두 입력의 SHA-256을 확인하고 실제 Lua 모듈을 가상 폴더에서 실행한다.

```sh
python3 checks/check.py /path/to/buddy-0.6.27.zip /path/to/1.12.4.lua
```

③ 작업 사본도 확인하려면 같은 명령에 `--candidate-resources /path/to/host-resources --candidate-catalog /path/to/assembled.lua`를 추가한다. 호스트 모듈 중 후보 경로에 있는 파일만 교체하고 나머지는 공개 본체에서 사용한다.

| 검수 | 결과 |
| --- | --- |
| 기본 폴더 및 별도 지갑 폴더 | 원본·③ 사본 모두 각각 74개·75개의 경로와 내용이 일치했다. 폴더를 분리하면 본체와 지갑 폴더에 각각 계정 확인 기록이 존재해 1개 늘었다. |
| 복원 뒤 새 프로세스에서 재조회 | 선택 아바타·두 아바타의 XP, 뿔동이 소유자/게스트 지갑, 지오 원장, 돌·진화 형태, 의상·펫·동행, 캘린더 최초 기준과 가족 규칙이 시험 기대값과 일치했다. |
| 기존·신규 이벤트 | 동일 XP 재입력 전후 복원 파일의 내용과 수정시각이 같았다. 다음 이벤트 적용 결과도 원본 사본과 복원본이 일치했다. |
| 실패 처리 | 손상된 ZIP 내용과 중간 거래 누락을 감지했다. 실패 시 완성된 복원 폴더나 백업을 남기지 않았다. 이미 존재하는 백업·복원 경로는 보존했다. |
| 포함 경계 | 에디터 PIN 파일·실시간 수신 자료·무관한 파일을 제외했다. 구형 캘린더는 요청한 시험에서만 포함했다. |

기존 스킨의 ‘백업 연결’은 캘린더 v1 JSON을 읽어 진행 상황을 계산한다. 공개 저장소의 웹 백업 구현은 브라우저 기록을 내보낸다. 위 로컬 검수는 Windows 설치·공개 서명·실사용 PC 간 복원이나 Google Drive 자동 백업 검증을 포함하지 않는다.

[바이블 11장](https://app.notion.com/p/425b1c033c1c8164853ad6bc15ffc305) · [검수 기준 커밋](https://github.com/ccucle/frame7-nav/commit/988193a4faf85dae5efb4e7db7b6cdc1da640fd4)
