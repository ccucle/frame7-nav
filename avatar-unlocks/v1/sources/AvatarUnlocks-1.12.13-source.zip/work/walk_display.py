"""Assemble the two directional animation strips used by the Gen I desktop renderer."""
from io import BytesIO
import json
import math

from PIL import Image


def rgba(image):
    result = image.convert("RGBA")
    # Transparent RGB values do not affect the sprite and must agree when deduplicating.
    result.paste((0, 0, 0, 0), mask=result.getchannel("A").point(lambda alpha: 255 if alpha == 0 else 0))
    return result


def build_display(assets):
    rows = json.loads((assets / "walk-rows.json").read_text(encoding="utf-8"))
    tiers = json.loads((assets / "pokemon-sizes.json").read_text(encoding="utf-8"))["tiers"]
    density = max(1, math.ceil(max(tier["scale"] for tier in tiers.values())))
    densities, sequences, strips, offsets = [], {}, [], {}
    total_height = 0
    for row in rows:
        source = row.get("walkSequence") or row["walkMaster"]
        name, scale = row["id"], row["density"]
        durations = row["frameDurations"]
        w, h = row["crop"][2:]
        if name in sequences or min([scale, w, h, *durations]) < 1 or not durations:
            raise ValueError(f"Invalid motion row: {name}")
        with Image.open(assets / source) as original:
            if original.width % len(durations) or original.height % 2:
                raise ValueError(f"Frame grid mismatch: {source}")
            strip = rgba(original.resize((len(durations)*w*scale, 2*h*scale), Image.Resampling.NEAREST))
        key = (strip.size, strip.tobytes())
        if key not in offsets:
            offsets[key] = total_height
            strips.append(strip)
            total_height += strip.height
        densities.append(scale)
        sequences[name] = (offsets[key], durations)
    sheet = Image.new("RGBA", (max(strip.width for strip in strips), total_height))
    y = 0
    for strip in strips:
        sheet.paste(strip, (0, y))
        y += strip.height
    # Reuse the team's optimized PNG only when this build rendered exactly its pixels.
    cache = assets / "walk-display.png"
    with Image.open(cache) as released:
        if sheet.size == released.size and sheet.tobytes() == rgba(released).tobytes():
            return density, cache.read_bytes(), densities, sequences
    buffer = BytesIO()
    sheet.save(buffer, format="PNG", optimize=True)
    return density, buffer.getvalue(), densities, sequences
