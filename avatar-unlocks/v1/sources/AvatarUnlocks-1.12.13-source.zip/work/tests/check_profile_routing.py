"""Run the profile-routing regression suite in fresh directories with synthetic identities."""
import argparse
import hashlib
import os
import re
import json
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

CHECKS = Path(__file__).resolve().parent
RESOURCES = ("desktop.lua", "geo-unlocks.lua", "geo-state.lua", "geo-panel.lua",
             "avatarprofiles.lua", "json.lua", "unlock-catalog.json", "unlock-engine.lua")
CASES = ("switch", "path", "geo-path", "fallback", "offline-path", "foreign",
         "offline", "foreign-restart", "desktop-owner", "desktop-path", "geo-workshop-fallback")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare(root, host, engine):
    resources = root / "DesktopSkin" / "@Resources"
    resources.mkdir(parents=True)
    local_engine = root / "catalog.lua"
    shutil.copyfile(engine, local_engine)
    for name in RESOURCES:
        shutil.copyfile(host / name, resources / name)
    # texlua reads UTF-8 source. The delivered Windows file retains its original encoding.
    desktop = (resources / "desktop.lua").read_bytes()
    encoding = "utf-16" if desktop.startswith(b"\xff\xfe") else "utf-8-sig"
    (resources / "desktop-test.lua").write_text(desktop.decode(encoding), encoding="utf-8")
    resources.rename(root / "res")
    return local_engine


def snapshot(owner, count=0):
    xp = 90 + count * 2
    return {
        "format": 2, "avatar": "formday-geo", "owner": owner, "connection": "connected",
        "revision": count + 1, "fetched_at": int(time.time()),
        "balance": {"base_xp": 90, "earned_count": count, "total_xp": xp, "powder": 200,
                    "level": 1 + xp // 30, "xp_into_level": xp % 30,
                    "stones": {"leaf": 12}, "forms": {}},
    }


def setup_case(folder, engine, version):
    cache = folder / "cache/FormdayAvatar/Unlocks/v1"
    cache.mkdir(parents=True)
    for name in ("sync", "skin", "data", "other"):
        (folder / name).mkdir()
    shutil.copyfile(engine, cache / (version + ".lua"))
    (cache / "active.txt").write_text(version)
    rules = {
        "family-unlock-levels": {"levels": {"kirby": 1, "octopus": 4}},
        "family-powder": {"powderPerXp": 5},
        "family-evolution": {"first": 5, "second": 10, "overrides": {}},
    }
    for name, doc in rules.items():
        (cache / (name + ".json")).write_text(json.dumps({"schema": 1, "revision": 3, **doc}))
    for name, doc in (("initial", snapshot("account-one")), ("next", snapshot("account-one", 1)),
                      ("foreign", snapshot("account-two", 5))):
        (folder / (name + ".json")).write_text(json.dumps(doc))
    shutil.copyfile(folder / "initial.json", folder / "sync/geo-live.json")


def run_case(root, case, mode, version):
    subprocess.run([os.environ.get("FORMDAY_TEST_LUA", "texlua"), str(CHECKS / "profile-routing.lua"), str(root),
                    case, "formday-buddy", "4", mode, version], cwd=root, check=True)


def records(folder):
    return {p.name: (digest(p), p.stat().st_mtime_ns) for p in folder.iterdir() if p.is_file()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("host", type=Path, help="integrated Buddy resource directory")
    parser.add_argument("engine", type=Path, help="assembled catalog Lua")
    args = parser.parse_args()
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        engine = prepare(root, args.host, args.engine)
        version = re.fullmatch(r"-- avatar-unlocks/v1 ([0-9]+\.[0-9]+\.[0-9]+)", engine.read_bytes().splitlines()[0].decode("ascii")).group(1)
        for case in CASES:
            folder = root / case
            setup_case(folder, engine, version)
            if case == "foreign-restart":
                run_case(root, case, "offline", version)
            run_case(root, case, case, version)
            if case == "switch":
                before = records(folder / "data")
                run_case(root, case, "restart", version)
                if before != records(folder / "data"):
                    raise AssertionError("Restart changed a record, selection or modification time")
                print(f"PASS {len(before)} identical records after process restart", flush=True)


if __name__ == "__main__":
    main()
