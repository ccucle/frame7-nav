-- Run against an assembled catalog, for example: lua work/tests/family-rules.lua path/to/catalog.lua
local M = assert(loadfile(assert(arg[1], "expected an assembled catalog Lua path")))()

local function document(revision, fields)
    fields.schema = 1
    fields.revision = revision
    return fields
end

local function levelFor(avatar, id)
    for _, item in ipairs(M.catalogFor(avatar, {})) do
        if item.id == id then return item.level end
    end
end

local function checkPets(kirby, octopus)
    for _, avatar in ipairs({ "formday-buddy", "formday-geo" }) do
        assert(levelFor(avatar, "kirby") == kirby, avatar .. " kirby")
        assert(levelFor(avatar, "octopus") == octopus, avatar .. " octopus")
    end
end

local function costs(revision, overrides)
    return document(revision, { first = 3, second = 4, overrides = overrides or {} })
end

checkPets(2, 5)
assert(M.powderPerXp == 5)
assert(M.applyLevelRules(document(3, { levels = { kirby = 1, octopus = 4 } })))
checkPets(1, 4)

-- The three files have separate revision sequences.
assert(M.applyCostRules(costs(1, { ["ivysaur/venusaur"] = 7 })))
assert(M.evolutions.ivysaur.cost == 3 and M.evolutions.venusaur.cost == 7)
assert(M.applyPowderRules(document(1, { powderPerXp = 0 })))
assert(M.powderPerXp == 0)
for _, revision in ipairs({ 0, -1, 1.5, "4", 2147483648 }) do
    assert(not M.applyLevelRules(document(revision, { levels = {} })))
    assert(not M.applyCostRules(costs(revision)))
    assert(not M.applyPowderRules(document(revision, { powderPerXp = 5 })))
end
for _, bad in ipairs({ false, "bad", {}, { schema = 2, revision = 4, levels = {}, first = 1, second = 2, overrides = {}, powderPerXp = 5 } }) do
    assert(not M.applyCostRules(bad) and not M.applyLevelRules(bad) and not M.applyPowderRules(bad))
end
assert(not M.applyLevelRules(document(3, { levels = { kirby = 7 } })))
assert(not M.applyLevelRules(document(2, { levels = {} })))
assert(not M.applyCostRules(costs(1)))
assert(not M.applyPowderRules(document(1, { powderPerXp = 100 })))

-- If any field is invalid, the previous rules and revision survive together.
for _, levels in ipairs({
    { kirby = 0 }, { kirby = 1000 }, { kirby = 2.5 }, { [1] = 1 },
    { kirby = 8, ivysaur = 2 }, { bulbasaur = 21 }, { ["bad id"] = 1 }
}) do
    assert(not M.applyLevelRules(document(4, { levels = levels })))
    assert(M.levelRevision == 3)
    checkPets(1, 4)
end
assert(not M.applyCostRules(costs(2, { invalid = 2 })))
assert(M.costRevision == 1 and M.evolutions.venusaur.cost == 7)
for _, rate in ipairs({ -1, 1000, 2.5, "5" }) do
    assert(not M.applyPowderRules(document(2, { powderPerXp = rate })))
end
assert(M.powderRevision == 1 and M.powderPerXp == 0)

-- Forward-compatible unknown IDs are ignored. A valid empty rule restores the catalog defaults.
assert(M.applyLevelRules(document(4, { levels = { bulbasaur = 20, kirby = 999, ["future-item"] = 2 } })))
assert(levelFor("formday-buddy", "bulbasaur") == 20)
assert(levelFor("formday-buddy", "future-item") == nil)
checkPets(999, 5)
assert(M.applyLevelRules(document(2147483647, { levels = {} })))
checkPets(2, 5)
assert(M.applyCostRules(costs(2)))
assert(M.evolutions.venusaur.cost == 4)
assert(M.applyPowderRules(document(2, { powderPerXp = 999 })))
assert(M.powderPerXp == 999)
print("PASS family rules: defaults, overrides, validation, independent revisions and reset")
