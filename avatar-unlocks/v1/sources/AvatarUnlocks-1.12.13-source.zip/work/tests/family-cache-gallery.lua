-- Run with a built catalog and the matching json.lua from the source tree.
-- Only Rainmeter's display calls are simulated. No user files are read or written.
local M = assert(loadfile(assert(arg[1], "expected catalog.lua")))()
local decode = assert(loadfile(assert(arg[2], "expected json.lua")))().decode
local content = decode(M.contentJson)
local avatar, ownsPet = "formday-geo", false
local options = {}
unpack = unpack or table.unpack
SKIN = {
    GetVariable = function(_, key)
        if key == "UnlockAvatar" then return avatar end
    end,
    Bang = function(_, command, meter, key, value)
        if command == "!SetOption" then
            options[meter] = options[meter] or {}
            options[meter][key] = value
        end
    end,
}
CanWearOutfit = function() return false end
M.imageFile = function() return "preview.png" end
local session = {
    owns = function(_, id) return ownsPet and id == "octopus" end,
    selected = function() return nil end,
    wallet = { stones = {} },
}
local g = M.createGallery()
g.init("", "", content.families, content.sizes, content.galleryPositions)
local function bind()
    g.bind(M, M.catalogFor(avatar, {}), session)
end
local function native(text)
    -- Korean labels are emitted as Rainmeter character references.
    return (text:gsub("([\224-\239])([\128-\191])([\128-\191])", function(a,b,c)
        local code = (a:byte()-224)*4096 + (b:byte()-128)*64 + c:byte()-128
        return string.format("[\\x%04x]", code)
    end))
end
local function contains(meter, key, expected)
    local text = assert(options[meter] and options[meter][key], meter)
    assert(text:find(native(expected), 1, true), meter.." does not show "..expected)
end
bind()
g.open(0,0)
g.tab(2)
local pending = "가족 해금 레벨 확인 대기"
contains("GalleryCell2", "ToolTipText", pending)
assert(not M.isFamilyRuleReady(avatar, M.levelRevision))
ownsPet = true
g.refresh()
contains("GalleryCell2", "ToolTipText", "클릭하여 바탕화면에 꺼내기")
ownsPet = false
g.tab(3)
g.select(1)
contains("GalleryCount", "Text", pending)
contains("GalleryEvolution1", "Text", pending)
g.member(2)
contains("GalleryCount", "Text", "가족 진화 비용 확인 대기")
assert(options.GalleryPageNumber.LeftMouseUpAction == "")
local evolves = 0
session.evolve = function() evolves = evolves + 1 end
g.evolve()
assert(evolves == 0)
assert(M.applyCostRules({schema=1, revision=1, first=1, second=2, overrides={}}))
g.evolve()
assert(evolves == 1)
g.back()
avatar = "other-avatar"
assert(M.isFamilyRuleReady(avatar, M.levelRevision))
bind()
g.tab(2)
contains("GalleryCell2", "ToolTipText", "해금 레벨 미정")
avatar = "formday-buddy"
assert(not M.isFamilyRuleReady(avatar, M.levelRevision))
assert(not M.applyLevelRules({schema=1, revision=2, levels={octopus=0}}))
assert(not M.isFamilyRuleReady(avatar, M.levelRevision))
assert(M.applyLevelRules({schema=1, revision=3, levels={octopus=4}}))
assert(M.isFamilyRuleReady(avatar, M.levelRevision) and M.isFamilyRuleReady("formday-geo", M.levelRevision))
bind()
contains("GalleryCell2", "ToolTipText", "필요 레벨 4")
print("PASS family rule readiness across gallery, details, restored and unrelated profiles")
