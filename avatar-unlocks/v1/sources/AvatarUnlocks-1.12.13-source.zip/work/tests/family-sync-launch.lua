-- Run with Lua 5.3+, the assembled catalog Lua and its expected routing mode.
-- "legacy" covers the previous published catalog; "quiet" covers the new catalog and host seed.
local catalogPath, routing = assert(arg[1]), assert(arg[2])
assert(routing == "legacy" or routing == "quiet")
local file = assert(io.open(catalogPath, "rb"))
local catalog = file:read("*a")
file:close()
local client = assert(catalog:match("\n(local costHelper, costCache, costDecode.-)\nlocal sizes\n"),
    "family sync client missing from the assembled catalog")

local folder = "C:\\Family Test\\규칙\\"
local function check(hasMeasure, avatar, mode, assetsReady)
    local calls = {}
    local engine = {version = "1.2.3", costScript = "script", costRoutes = "routes", levelItems = "levels"}
    function engine.isFamilyAvatar(id) return id == "formday-buddy" or id == "formday-geo" end
    local skin = {}
    function skin:GetVariable(key) assert(key == "UnlockAvatar"); return avatar end
    function skin:GetMeasure(name) assert(name == "FamilyRuleSync"); return hasMeasure and {} or nil end
    function skin:Bang(...) table.insert(calls, {...}) end
    local expectedAssets = {
        [folder.."evolution-1.2.3.ps1"] = "\239\187\191script",
        [folder.."evolution-1.2.3.json"] = "routes",
        [folder.."evolution-1.2.3.levels.json"] = "levels"
    }
    local env = setmetatable({SKIN=skin, engine=engine, shared=folder}, {__index=_G})
    env.os = {getenv=function(key) assert(key == "SystemRoot"); return "C:\\Windows" end}
    env.io = {open=function(path, access)
        if not assetsReady then return nil end
        assert(access == "rb" and expectedAssets[path], path)
        return {read=function() return expectedAssets[path] end, close=function() return true end}
    end}
    local launch = assert(load(client.."\ncostHelper={}\nreturn launchCosts", "@family-sync-client", "t", env))()
    if not assetsReady then assert(not launch(mode) and #calls == 0); return end
    assert(launch(mode))
    local args = '-NoProfile -NonInteractive -STA -ExecutionPolicy RemoteSigned -WindowStyle Hidden -File "'..
        folder..'evolution-1.2.3.ps1" -Mode '..mode..(engine.isFamilyAvatar(avatar) and ' -FamilyAvatar' or '')
    if routing == "quiet" and hasMeasure and mode == "Sync" then
        assert(#calls == 3)
        assert(table.concat(calls[1],"|") == "!SetOption|FamilyRuleSync|Parameter|"..args)
        assert(table.concat(calls[2],"|") == "!UpdateMeasure|FamilyRuleSync")
        assert(table.concat(calls[3],"|") == "!CommandMeasure|FamilyRuleSync|Run")
    else
        assert(#calls == 1 and #calls[1] == 1)
        assert(calls[1][1] == '["C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe" '..args..']')
    end
end
for _, capable in ipairs({false,true}) do
    for _, avatar in ipairs({"formday-buddy","formday-geo","other"}) do
        for _, mode in ipairs({"Sync","Editor"}) do
            check(capable,avatar,mode,true)
            check(capable,avatar,mode,false)
        end
    end
end
print("PASS sync and manual editor routing, host capability, family flag and helper-write failure: "..routing)
