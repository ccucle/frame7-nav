local root, machine, avatar, level, mode, catalogVersion = table.unpack(arg,1,6)
local base = root.."/"..machine
local shared = base.."/cache/FormdayAvatar/Unlocks/v1/"
local path = function(s) return (s:gsub("\\","/")) end
local nativeOpen, nativeRename, nativeRemove = io.open, os.rename, os.remove
local nativeLoad, nativeEnv = loadfile, os.getenv
io.open=function(p,mode) return nativeOpen(path(p),mode) end
os.rename=function(a,b) return nativeRename(path(a),path(b)) end
os.remove=function(p) return nativeRemove(path(p)) end
loadfile=function(p,...) return nativeLoad(path(p),...) end
dofile=function(p) return assert(loadfile(p))() end
os.getenv=function(k)
  if k=="LOCALAPPDATA" then return base.."/cache" end
  if k=="SystemRoot" then return base.."/simulated-windows" end
  return nativeEnv(k)
end
unpack=table.unpack
getfenv=function() return _G end
setfenv=function(fn,env)
  for i=1,64 do
    local name=debug.getupvalue(fn,i)
    if name=="_ENV" then debug.setupvalue(fn,i,env);return fn end
    if not name then break end
  end
  return fn
end
local vars={UnlockAvatar=avatar,UnlockProfile="audit",UnlockLevel=tostring(level),Level=tostring(level),UnlockEnabled="1",UnlockDataPath=base.."/data/",SyncFolder=base.."/sync",CURRENTPATH=base.."/skin/",CURRENTCONFIG="AuditSkin",["@"]=root.."/res/"}
local visible,opts={},{}
SKIN={
 GetVariable=function(_,n) return vars[n] end,
 GetMeter=function() return nil end,
 GetMeasure=function() return nil end,
 Bang=function(_,cmd,a,b,c)
   if cmd=="!SetVariable" then vars[a]=b
   elseif cmd=="!SetOption" then opts[a]=opts[a] or {};opts[a][b]=c
   elseif cmd=="!ShowMeter" or cmd=="!HideMeter" then visible[a]=cmd=="!ShowMeter" end
 end
}
SELF={GetName=function() return "AvatarUnlocks" end,GetOption=function(_,n) if n=="ResourcePath" then return root.."/res/" end end}
local function check(value, message)
    if not value then error(message, 2) end
end
local function bytes(name)
    local f=io.open(name,"rb")
    if not f then return nil end
    local body=f:read("*a");f:close();return body
end
local function write(name, body)
    local f=assert(io.open(name,"wb"))
    assert(f:write(body));assert(f:close())
end
local function loadSnapshot(name)
    write(base.."/sync/geo-live.json",assert(bytes(base.."/"..name..".json")))
end
local function hasPet(avatarId, profile, pet, directory)
    return bytes((directory or base.."/data/").."unlock~"..avatarId.."~"..profile.."~"..pet..".owned")==pet.."\n"
end
local function ledgerCount(prefix,fmt)
    local i=0
    while bytes(prefix..string.format(fmt,i+1)) do i=i+1 end
    return i
end
local function geoCount(folder)
    return ledgerCount(folder.."geo-local-wallet-v1-","%08d.json")
end
local function buddyCount(folder,profile)
    return ledgerCount(folder.."unlock~formday-buddy~"..profile.."~wallet-","%09d.txn")
end
local data=base.."/data/"
local alt=base.."/other/"
local buddy,geo="formday-buddy","formday-geo"
local function start(a,profile,total)
    vars.UnlockAvatar,vars.UnlockProfile,vars.Total=a,profile,tostring(total)
    vars.Level,vars.UnlockLevel="4","4"
    dofile(root.."/res/geo-unlocks.lua")
    Initialize();Update();Update()
    check(vars.UnlockSystemVersion==catalogVersion,"current catalog did not load")
end
local function switch(a,profile,total)
    vars.UnlockAvatar,vars.UnlockProfile,vars.Total=a,profile,tostring(total)
    RefreshWallet()
end
local function upvalue(fn, key, ...)
    for index=1,64 do
        local name,value=debug.getupvalue(fn,index)
        if name==key then
            if select("#",...)>0 then debug.setupvalue(fn,index,...) end
            return value
        end
        if not name then break end
    end
    error("desktop fixture dependency missing: "..key)
end

local function desktopPanel()
    dofile(root.."/res/desktop-test.lua")
    local json=dofile(root.."/res/json.lua")
    local geoState=dofile(root.."/res/geo-state.lua")
    local profiles=dofile(root.."/res/avatarprofiles.lua")
    local panel=dofile(root.."/res/geo-panel.lua")
    profiles.init(data)
    check(profiles.observe("localraw",75),"Buddy initial XP")
    local refresh=upvalue(GeoTransportFinished,"refreshRecord")
    upvalue(refresh,"geoState",geoState)
    upvalue(refresh,"dataDir",data)
    upvalue(refresh,"syncDir",base.."/sync/")
    upvalue(refresh,"json",json)
    upvalue(refresh,"avatarProfiles",profiles)
    upvalue(refresh,"geoPanel",panel)
    upvalue(refresh,"lastDay",os.date("!%Y-%m-%d",os.time()+9*3600))
    upvalue(refresh,"loadRecord",function() end)
    upvalue(refresh,"applyInfoMode",nil)
    local paint=upvalue(refresh,"paintAvatarProgress")
    upvalue(paint,"progress",{perLevel=25})
    upvalue(SelectAvatar,"settingsOpen",true)
    upvalue(SelectAvatar,"geoLaunch",{open=function() end})
    upvalue(SelectAvatar,"showAvatarChoice",function() end)
    vars.GeoLocalPowderPrefix="local powder "
    local function seed(folder)
        return assert(geoState.wallet(folder,json).ingest(geoState.read(base.."/sync/",json),base.."/sync/",nil))
    end
    seed(data)
    GeoTransportFinished()
    check(vars.GeoUI_powder=="local powder 200" and vars.GeoConnected=="1","initial panel")
    SelectAvatar(geo)
    check(vars.UnlockAvatar==geo and profiles.xp()==90,"Geo XP on switch")
    check(profiles.observe("localraw",77) and profiles.xp()==90,"calendar XP belongs to Buddy")
    SelectAvatar(buddy)
    check(vars.UnlockAvatar==buddy and profiles.xp()==77,"Buddy XP on return")
    local recovered=dofile(root.."/res/avatarprofiles.lua")
    recovered.init(data)
    check(recovered.id()==buddy and recovered.xp()==77,"saved avatar and Buddy XP")
    if mode=="desktop-path" then
        vars.UnlockDataPath=alt
        seed(alt)
        local _,reason=geoState.wallet(alt,json).craft("leaf")
        check(reason=="committed","test setup alternate balance")
        GeoTransportFinished()
        if vars.GeoUI_powder~="local powder 170" then print("OBSERVED panel reading original folder");os.exit(23) end
        vars.UnlockDataPath=data;GeoTransportFinished()
        check(vars.GeoUI_powder=="local powder 200","original balance on return")
    else
        os.remove(base.."/sync/geo-live.json");GeoTransportFinished()
        check(vars.GeoUI_powder=="local powder 200" and vars.GeoConnected=="0","offline original balance")
        loadSnapshot("foreign");GeoTransportFinished()
        if vars.GeoUI_powder=="local powder 200" then print("OBSERVED foreign snapshot showing previous balance");os.exit(22) end
        check(vars.GeoConnected=="0" and vars.GeoUI_powder=="가루 —","foreign panel")
        os.remove(data.."geo-owner-v1.txt");GeoTransportFinished()
        check(not bytes(data.."geo-owner-v1.txt"),"foreign owner pinned over prior wallet")
        loadSnapshot("initial");GeoTransportFinished()
        check(vars.GeoUI_powder=="local powder 200" and vars.GeoConnected=="1","original panel recovered")
    end
    print("PASS desktop avatar selection, XP routing, saved avatar and panel: "..mode)
end

local function run()
    if mode=="desktop-owner" or mode=="desktop-path" then
        desktopPanel()
    elseif mode=="geo-workshop-fallback" then
        vars.UnlockDataPath=""
        start(geo,"owner",90)
        local folder=base.."/skin/"
        local count=geoCount(folder)
        vars.WorkshopOpen="1";GeoCraftClick(1)
        if geoCount(folder)~=count+1 then print("OBSERVED workshop ignored fallback folder");os.exit(24) end
        check(geoCount(data)==0 and vars.GeoCraftStatus=="done","fallback workshop wallet")
        print("PASS workshop uses same fallback folder as the catalog")
    elseif mode=="switch" or mode=="restart" then
        start(buddy,"owner",75)
        if mode=="switch" then
            Choose("pet","kirby");Choose("pokemon","bulbasaur")
            check(hasPet(buddy,"owner","kirby"),"Buddy ownership")
            switch(geo,"owner",90);Choose("pet","octopus");Choose("pokemon","charmander")
            check(hasPet(geo,"owner","octopus"),"Geo ownership")
            loadSnapshot("next");Update();Update()
        end
        switch(buddy,"owner",75)
        check(vars.UnlockPet=="kirby" and vars.UnlockCompanionCount=="1","Buddy selections")
        switch(geo,"owner",92)
        check(vars.UnlockPet=="octopus" and vars.UnlockCompanionCount=="1","Geo selections")
        check(buddyCount(data,"owner")==1 and geoCount(data)==2,"duplicate credits")
        check(not bytes(data.."unlock~formday-geo~owner~wallet-000000001.txn"),"misdirected Geo wallet")
        switch(buddy,"guest",9)
        check(vars.UnlockPet=="" and vars.UnlockCompanionCount=="0","selections crossed Buddy profile")
        check(buddyCount(data,"guest")==1,"guest wallet")
        switch(buddy,"owner",75);check(vars.UnlockPet=="kirby","Buddy choice did not return")
        local bp=assert(bytes(data.."unlock~formday-buddy~owner~pokemon-roster.selection"))
        local gp=assert(bytes(data.."unlock~formday-geo~owner~pokemon-roster.selection"))
        check(bp:match("=bulbasaur!%s*$") and gp:match("=charmander!%s*$"),"rosters crossed")
        print("PASS avatar switch, local Buddy profiles, distinct ledgers, rosters, repeated XP and session restart")
    elseif mode=="path" or mode=="geo-path" or mode=="fallback" then
        local isGeo=mode=="geo-path"
        local a=isGeo and geo or buddy
        start(a,"owner",75)
        Choose("pet","kirby")
        local count=isGeo and geoCount(data) or buddyCount(data,"owner")
        if mode=="fallback" then alt=base.."/skin/";vars.UnlockDataPath=""
        else vars.UnlockDataPath=alt end
        vars.Total="77"
        -- This callback can run before the regular Update tick.
        FollowerTick();RefreshWallet()
        local rebound=hasPet(a,"owner","kirby",alt)
        if not rebound then print("OBSERVED stale-session old folder retained");os.exit(20) end
        check((isGeo and geoCount(data) or buddyCount(data,"owner"))==count,"original ledger modified")
        check(vars.UnlockPet=="","old pet selection carried across data folders")
        Choose("pet","octopus");check(vars.UnlockPet=="octopus","new folder selection")
        vars.UnlockDataPath=data;vars.Total="75";RefreshWallet()
        check(vars.UnlockPet=="kirby","original folder selection was overwritten")
        print("PASS rebind on directory-only switch and return ("..mode..")")
    elseif mode=="offline-path" then
        vars.UnlockEnabled="0";vars.CatalogSavedLevel="4"
        start(buddy,"owner",75)
        Choose("pet","kirby");vars.UnlockDataPath=alt;RefreshWallet()
        if not hasPet(buddy,"owner","kirby",alt) then print("OBSERVED stale offline session");os.exit(20) end
        check(vars.UnlockPet=="" and buddyCount(data,"owner")==0,"stale offline selection or credit")
        print("PASS offline saved-level session rebinds without XP credit")
    elseif mode=="foreign" or mode=="offline" or mode=="foreign-restart" then
        if mode~="foreign-restart" then start(geo,"owner",90) end
        if mode=="offline" then os.remove(base.."/sync/geo-live.json")
        else loadSnapshot("foreign") end
        vars.UnlockEnabled="0";vars.WorkshopOpen="1"
        if mode=="foreign-restart" then start(geo,"owner",90) else RefreshWallet() end
        local count=geoCount(data)
        GeoCraftClick(1)
        if mode=="offline" then
            check(geoCount(data)==count+1,"legitimate offline craft failed")
            print("PASS no snapshot, original offline owner can craft")
        else
            if geoCount(data)~=count then print("OBSERVED foreign snapshot allowed spend against old owner");os.exit(21) end
            check(bytes(data.."geo-owner-v1.txt"):match("account%-one|"),"original owner lost")
            check(vars.GeoCraftStatus=="unavailable","missing ownership-mismatch UI state")
            OpenPanel();GalleryTab(3);GallerySelect(1);GalleryMember(2);GalleryEvolve()
            check(geoCount(data)==count,"foreign snapshot allowed an evolution debit")
            loadSnapshot("initial");RefreshWallet();GeoCraftClick(1)
            check(geoCount(data)==count+1,"failed to resume original owner")
            print("PASS foreign owner held, same owner resumed")
        end
    else error("unknown scenario") end
end
local ok,reason=xpcall(run,debug.traceback)
if not ok then io.stderr:write(reason,"\n");os.exit(1) end
