-- One catalog policy for every avatar. Storage adapters never contain prices.
M.purchaseReceiptVersion=1
M.specialPrices={articuno=8000,zapdos=8000,moltres=8000,mew=13000,mewtwo=18000}
function M.requiredForGeneration(id) return M.specialPrices[id]==nil end
function M.levelRewardAllowed(id)
    return not M.specialShopEnabled or M.requiredForGeneration(id)
end
function M.purchaseDecision(wallet,owns,id)
    local price=M.specialPrices[id]
    if not price then return nil,"unavailable" end
    if owns(id) then return nil,"owned" end
    if not wallet or wallet.error then return nil,"unavailable" end
    if wallet.powder<price then return nil,"low" end
    return price,"ready"
end
function M.attachShop(session)
    function session:purchaseStatus(id)
        if not M.specialPrices[id] then return nil,"unavailable" end
        if self:owns(id) then return M.specialPrices[id],"owned" end
        if not M.specialShopEnabled or not self.commitPurchase then return M.specialPrices[id],"update" end
        local _,status=M.purchaseDecision(self.wallet,function(target)return self:owns(target) end,id)
        return M.specialPrices[id],status
    end
    function session:purchase(id)
        if not M.specialShopEnabled or not self.commitPurchase then return false,"update" end
        -- Storage calls the shared decision again after every conflicting commit.
        return self:commitPurchase(function(wallet)
            local price,reason=M.purchaseDecision(wallet,function(target)
                return wallet.forms[target] or self:owns(target)
            end,id)
            return price and {id=id,cost=price} or nil,reason
        end)
    end
end
