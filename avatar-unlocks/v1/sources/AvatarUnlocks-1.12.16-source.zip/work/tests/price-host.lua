local root, machine, avatar, level, mode, catalogVersion = table.unpack(arg,1,6)
local base = root.."/"..machine
local shared = base.."/cache/FormdayAvatar/Unlocks/v1/"
local path = function(s) return (s:gsub("\\","/")) end
local nativeOpen, nativeRename, nativeRemove = io.open, os.rename, os.remove
local nativeLoad, nativeEnv = loadfile, os.getenv
io.open=function(p,mode) return nativeOpen(path(p),mode) end
os.rename=function(a,b) return nativeRename(path(a),path(b)) end
os.remove=function(p) return nativeRemove(path(p)) end
loadfile=function(p,...) return nativeLoad(path(p),...) end
dofile=function(p) return assert(loadfile(p))() end
os.getenv=function(k)
  if k=="LOCALAPPDATA" then return base.."/cache" end
  if k=="SystemRoot" then return base.."/simulated-windows" end
  return nativeEnv(k)
end
unpack=table.unpack
getfenv=function() return _G end
setfenv=function(fn,env)
  for i=1,64 do
    local name=debug.getupvalue(fn,i)
    if name=="_ENV" then debug.setupvalue(fn,i,env);return fn end
    if not name then break end
  end
  return fn
end
local vars={UnlockAvatar=avatar,UnlockProfile="audit",UnlockLevel=tostring(level),Level=tostring(level),UnlockEnabled="1",UnlockDataPath=base.."/data/",SyncFolder=base.."/sync",CURRENTPATH=base.."/skin/",CURRENTCONFIG="AuditSkin",["@"]=root.."/res/"}
local visible,opts={},{}
SKIN={
 GetVariable=function(_,n) return vars[n] end,
 GetMeter=function() return nil end,
 GetMeasure=function() return nil end,
 Bang=function(_,cmd,a,b,c)
   if cmd=="!SetVariable" then vars[a]=b
   elseif cmd=="!SetOption" then opts[a]=opts[a] or {};opts[a][b]=c
   elseif cmd=="!ShowMeter" or cmd=="!HideMeter" then visible[a]=cmd=="!ShowMeter" end
 end
}
SELF={GetName=function() return "AvatarUnlocks" end,GetOption=function(_,n) if n=="ResourcePath" then return root.."/res/" end end}
local function check(value, message)
    if not value then error(message, 2) end
end
local function bytes(name)
    local f=io.open(name,"rb")
    if not f then return nil end
    local body=f:read("*a");f:close();return body
end
local function write(name, body)
    local f=assert(io.open(name,"wb"))
    assert(f:write(body));assert(f:close())
end
local function loadSnapshot(name)
    write(base.."/sync/geo-live.json",assert(bytes(base.."/"..name..".json")))
end
local function hasPet(avatarId, profile, pet, directory)
    return bytes((directory or base.."/data/").."unlock~"..avatarId.."~"..profile.."~"..pet..".owned")==pet.."\n"
end
local function ledgerCount(prefix,fmt)
    local i=0
    while bytes(prefix..string.format(fmt,i+1)) do i=i+1 end
    return i
end
local function geoCount(folder)
    return ledgerCount(folder.."geo-local-wallet-v1-","%08d.json")
end
local function buddyCount(folder,profile)
    return ledgerCount(folder.."unlock~formday-buddy~"..profile.."~wallet-","%09d.txn")
end
local data=base.."/data/"
local alt=base.."/other/"
local buddy,geo="formday-buddy","formday-geo"
local function start(a,profile,total)
    vars.UnlockAvatar,vars.UnlockProfile,vars.Total=a,profile,tostring(total)
    vars.Level,vars.UnlockLevel="4","4"
    dofile(root.."/res/geo-unlocks.lua")
    Initialize();Update();Update()
    check(vars.UnlockSystemVersion==catalogVersion,"current catalog did not load")
end
local function switch(a,profile,total)
    vars.UnlockAvatar,vars.UnlockProfile,vars.Total=a,profile,tostring(total)
    RefreshWallet()
end

local function eq(a,b,label) check(a==b,(label or "value")..": "..tostring(a).." ~= "..tostring(b)) end
local function native(s)
 return (s:gsub("[\128-\255][\128-\191]*",function(c)
 local a,b,d=c:byte(1,3);local n=#c==2 and (a-192)*64+b-128 or ((a-224)*64+b-128)*64+d-128
 return string.format("[\\x%04x]",n) end))
end
local function text(m,s) check(opts[m].Text:find(native(s),1,true),m.." missing "..s..": "..opts[m].Text) end
local function number(m,s) check(opts[m].Text:find(s,1,true),m.." missing "..s) end
local function click(m)
 local action=opts[m].LeftMouseUpAction
 local token=action:match('GalleryPurchase%((%d+)%)')
 check(token,"no purchase action: "..action)
 GalleryPurchase(tonumber(token));return tonumber(token)
end
local function findZapdos()
 GalleryTab(3);for i=1,16 do GalleryPage(1) end
 -- Dex 145 is first card on page 17. 144 Articuno is last on page 16.
 text("GalleryName1","썬더");number("GalleryName1","8,000")
 GallerySelect(1);text("GalleryTitle","썬더")
end

local target,dex,price,balance=arg[7],tonumber(arg[8]),tonumber(arg[9]),tonumber(arg[10])
local selectedAvatar=avatar
local function formatted(n) return tostring(n):reverse():gsub("(%d%d%d)","%1,"):reverse():gsub("^,","") end
local function selectTarget()
 GalleryTab(3)
 for i=1,math.floor((dex-1)/9) do GalleryPage(1) end
 local card=(dex-1)%9+1
 number("GalleryName"..card,formatted(price))
 GallerySelect(card)
 number("GalleryCount",formatted(price))
end
local J=dofile(root.."/res/json.lua")
local function state(a)
 if a==buddy then
  local M=assert(loadfile(root.."/catalog.lua"))()
  local s=M.connect(data,buddy,"owner",{})
  return s.wallet.powder,s:owns(target),s.wallet.sequence
 end
 local G=dofile(root.."/res/geo-state.lua")
 local row=assert(G.wallet(data,J).read())
 return row.powder,row.forms[target]==true,row.sequence
end
-- Saved X records set exact integer balances without changing the production award rule.
write(data.."unlock~formday-buddy~owner~wallet-000000001.txn","X "..balance.." 1\n")
start(buddy,"owner",0);OpenPanel()
if selectedAvatar==geo then switch(geo,"owner",90) end
selectTarget()
local before,owned,seq=state(selectedAvatar);eq(before,balance);check(not owned,"unexpected pre-owned")
if balance==price-1 then
 eq(opts.GalleryPageNumber.LeftMouseUpAction,"","one-short purchase button")
 GalleryPurchase(0)
 -- The backend must reject one-short balances even without the disabled UI button.
 local M=assert(loadfile(root.."/catalog.lua"))();M.specialShopEnabled=true
 local direct
 if selectedAvatar==buddy then direct=M.connect(data,buddy,"owner",{})
 else
  local G=dofile(root.."/res/geo-state.lua");local w=G.wallet(data,J)
  direct={wallet=w.read(),owns=function(self,id)return self.wallet.forms[id]==true end}
  function direct:commitPurchase(plan)
   local row,why=w.purchase(plan);self.wallet=row;return why=="committed",why
  end
  M.attachShop(direct)
 end
 local ok,why=direct:purchase(target);eq(ok,false,"one-short backend");eq(why,"low")
 local after,held,count=state(selectedAvatar)
 eq(after,balance);eq(held,false);eq(count,seq)
else
 eq(balance,price)
 local token=click("GalleryPageNumber")
 local after,held,count=state(selectedAvatar)
 eq(after,0,"exact debit");eq(held,true);eq(count,seq+1)
 GalleryPurchase(token)
 local again,_,same=state(selectedAvatar);eq(again,0);eq(same,count)
 start(buddy,"owner",0);OpenPanel()
 if selectedAvatar==geo then switch(geo,"owner",90) end
 selectTarget()
 eq(select(1,state(selectedAvatar)),0);eq(select(2,state(selectedAvatar)),true)
 check(not opts.GalleryPageNumber.LeftMouseUpAction:find("GalleryPurchase",1,true),"owned species must not charge again")
end
-- Same item in the other avatar still has the original balance and is not owned.
local other=selectedAvatar==buddy and geo or buddy
switch(other,"owner",other==geo and 90 or 0)
selectTarget()
eq(select(1,state(other)),balance,"other avatar balance")
eq(select(2,state(other)),false,"ownership crossed avatars")
print("PASS price UI "..selectedAvatar.." "..target.." balance="..balance..": card/detail price, debit/one-short, restart/duplicate, independent other avatar")
