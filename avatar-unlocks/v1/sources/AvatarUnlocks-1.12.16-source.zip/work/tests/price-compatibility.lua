-- Old public-price receipts must replay their saved cost, never today's price.
local catalog,base,resources,oldCatalog=unpack(arg)
local M=assert(loadfile(catalog))();M.specialShopEnabled=true
local O=assert(loadfile(oldCatalog))();O.specialShopEnabled=true
local J=dofile(resources.."json.lua")
local G=dofile(resources.."geo-state.lua")
local cases={{"articuno",8000,20000},{"zapdos",8000,20000},{"moltres",8000,20000},{"mew",13000,30000},{"mewtwo",18000,40000}}
local function eq(a,b,msg) assert(a==b,(msg or "value")..": "..tostring(a).." ~= "..tostring(b)) end
local function generic(engine,profile) return engine.connect(base,"formday-buddy",profile,{}) end
local function geo(folder,powder,engine)
 local w=G.wallet(base..folder.."/",J)
 if not w.read() then
  local seed={format=2,avatar="formday-geo",owner="price-owner",connection="connected",revision=1,fetched_at=os.time(),balance={base_xp=90,earned_count=0,total_xp=90,powder=powder,level=4,xp_into_level=0,stones={leaf=3},forms={bulbasaur=true}}}
  local _,why=w.ingest(seed,base..folder.."/",engine.powderAward);eq(why,"committed")
 end
 local s={wallet=w.read(),owns=function(self,id)return self.wallet.forms[id]==true end}
 function s:commitPurchase(plan)
  local row,why=w.purchase(plan);self.wallet=row;return why=="committed",why
 end
 engine.attachShop(s);return s
end
local b=generic(O,"historic-all");assert(b:earn(40000))
local g=geo("historic-all",200000,O)
for _,c in ipairs(cases) do
 eq(O.specialPrices[c[1]],c[3]);eq(M.specialPrices[c[1]],c[2])
 assert(b:purchase(c[1]));assert(g:purchase(c[1]))
end
eq(b.wallet.powder,70000);eq(g.wallet.powder,70000)
rememberPriceFiles(base)
local reread=generic(M,"historic-all")
local rereadGeo=geo("historic-all",0,M)
for _,c in ipairs(cases) do
 assert(reread:owns(c[1]) and rereadGeo:owns(c[1]))
 assert(not reread:purchase(c[1]) and not rereadGeo:purchase(c[1]))
end
eq(reread.wallet.powder,70000);eq(rereadGeo.wallet.powder,70000)
assertPriceFilesPreserved()
-- Old and new prices coexist in each operational ledger. Old public readers retain the saved amount.
local mix=generic(O,"historic-mix");assert(mix:earn(40000));assert(mix:purchase("mew"))
local mixGeo=geo("historic-mix",200000,O);assert(mixGeo:purchase("mew"))
rememberPriceFiles(base)
mix=generic(M,"historic-mix");mixGeo=geo("historic-mix",0,M)
assert(mix:purchase("zapdos"));assert(mixGeo:purchase("zapdos"))
eq(mix.wallet.powder,162000);eq(mixGeo.wallet.powder,162000)
eq(generic(O,"historic-mix").wallet.powder,162000);eq(geo("historic-mix",0,O).wallet.powder,162000)
assertPriceFilesPreserved()
print("PASS historical prices: all five old purchases unchanged; mixed old/new costs; old public reader; bytes and mtimes; no refunds or duplicate debit")
