"""Destructive mutations only inside disposable copies; never production data."""
import contextlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from unittest.mock import patch
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / "work"), str(ROOT / "work/test-deps")]
from architecture_gate import BoundaryError, check_sources, check_pair, read_zip
import build_review
from lupa.lua51 import LuaRuntime

assert os.name == "nt" and ROOT == Path(r"C:\Users\ccucl\Projects\Geo-UnlockDex-Shop")
OUT = ROOT / "work/shop/qa"
results = []


def rejects(name, action, expected):
    try:
        action()
    except Exception as exc:
        assert expected in str(exc), (name, str(exc))
        results.append(name)
        print("PASS rejected:", name, flush=True)
    else:
        raise AssertionError("Invalid input accepted: " + name)


with tempfile.TemporaryDirectory(prefix="boundary-", dir=OUT) as directory:
    base = Path(directory)
    # Minimal independent input tree; executable allow-list is checked before any asset load.
    fixture = base / "fixture"
    contract = check_sources()
    for name in contract["modules"]:
        target = fixture / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / name, target)
    work = fixture / "work"
    work.mkdir()
    for name in ("architecture_gate.py", "package_skin.py", "build_review.py"):
        shutil.copy2(ROOT / "work" / name, work / name)
    (work / "architecture").mkdir()
    shutil.copy2(ROOT / "work/architecture/contract.json", work / "architecture/contract.json")
    unknown = fixture / "AvatarUnlocks/future-learning.lua"
    unknown.write_text('io.open("wallet", "wb")')
    rejects("unregistered future module", lambda: check_sources(fixture), "Unregistered")
    unknown.unlink()
    host = fixture / "DesktopSkin/@Resources/geo-unlocks.lua"
    original = host.read_bytes()
    host.write_bytes(original + b'\nio.open("other-profile-wallet","wb")\n')
    rejects("host bypass of approved storage boundary", lambda: check_sources(fixture), "Unreviewed")
    # The real public build CLI must fail before creating its final output.
    final = base / "must-not-exist"
    command = subprocess.run([sys.executable, "-B", str(work / "build_review.py"), str(final)],
                             cwd=fixture, capture_output=True, text=True)
    assert command.returncode != 0 and "Unreviewed" in command.stderr
    assert not final.exists()
    results.append("actual build CLI refuses unauthorized module without final output")
    host.write_bytes(original)
    policy = fixture / "AvatarUnlocks/special-shop.lua"
    original_policy = policy.read_bytes()
    policy.write_bytes(original_policy + b'\nio.open("wallet","wb")\n')
    rejects("policy acquired storage access", lambda: check_sources(fixture), "Unreviewed")
    policy.write_bytes(original_policy)
    catalog = ROOT / "work/architecture/review-1/AvatarUnlocks-review.lua"
    buddy = ROOT / "work/architecture/review-1/FormdayBuddy-review.zip"
    badzip = base / "split-engine.zip"
    entries = read_zip(buddy)
    entries["unlock-engine.lua"] += b"\n-- divergent engine\n"
    with ZipFile(badzip, "w", compression=ZIP_DEFLATED) as z:
        for name, body in entries.items():
            z.writestr(name, body)
    rejects("host and common engine diverged", lambda: check_pair(catalog, badzip), "Unapproved host artifact")
    # Exercise the isolation assertion itself, not merely the source seal.
    body = catalog.read_text(encoding="utf-8")
    changed, count = re.subn(r'avatar\s*\.\.\s*"~"\s*\.\.\s*profile\s*\.\.\s*"~"',
                            '"shared~owner~"', body, count=1)
    assert count == 1, "Isolation mutation no longer matches; update the intentional fault"
    mutant = base / "profile-leak.lua"
    mutant.write_text(changed, encoding="utf-8")
    wallets = base / "wallets"
    wallets.mkdir()
    lua = LuaRuntime()
    lua.globals().arg = lua.table_from([str(mutant), str(wallets) + "/"])
    rejects("behavioral profile collision", lambda: lua.execute(
        (ROOT / "work/tests/architecture-profiles.lua").read_text()), "fresh profile inherited data")
    # Tests are required before final rename, even when all bytes and sources are valid.
    with patch.object(build_review, "run_regressions", side_effect=RuntimeError("injected regression failure")):
        rejects("failed regression prevents final packaging",
                lambda: build_review.build(base / "rejected-final"), "injected regression failure")
    assert not (base / "rejected-final").exists()
    # Use the real publication-layout CLI on a corrupted feed. No signing/upload API exists here.
    release = base / "release"
    for name in ("buddy/feed.txt", "avatar-unlocks/v1/feed.txt",
                 "buddy/releases/0.6.32.zip", "avatar-unlocks/v1/releases/1.12.15.lua"):
        target = release / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / "work/shop/release/publish-1" / name, target)
    with (release / "buddy/releases/0.6.32.zip").open("ab") as f:
        f.write(b"wrong artifact")
    proc = subprocess.run([sys.executable, "-B", str(ROOT / "work/release_gate.py"), str(release)],
                          cwd=ROOT, capture_output=True, text=True)
    assert proc.returncode != 0 and "Feed/artifact digest mismatch" in proc.stderr
    results.append("actual release preflight CLI refuses mismatched feed/artifact")
    # Restore the valid official tree, then alter only the connect-kit adapter.
    for name in ("buddy/releases/0.6.32.zip", "buddy/installers/FormdayBuddy-0.6.32.rmskin",
                 "avatar-unlocks/v1/connect-kit.zip"):
        target = release / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / "work/shop/release/publish-1" / name, target)
    kitpath = release / "avatar-unlocks/v1/connect-kit.zip"
    kit = read_zip(kitpath)
    kit["AvatarUnlocks/unlock-adapter.lua"] += b"\n-- unreviewed alternate binding\n"
    with ZipFile(kitpath, "w", compression=ZIP_DEFLATED) as z:
        for name, body in kit.items():
            z.writestr(name, body)
    proc = subprocess.run([sys.executable, "-B", str(ROOT / "work/release_gate.py"), str(release)],
                          cwd=ROOT, capture_output=True, text=True)
    assert proc.returncode != 0 and "Unreviewed connect-kit binding" in proc.stderr, proc.stderr
    results.append("actual release preflight CLI refuses changed host binding")

print(json.dumps({"passed": results, "count": len(results)}, indent=2), flush=True)
