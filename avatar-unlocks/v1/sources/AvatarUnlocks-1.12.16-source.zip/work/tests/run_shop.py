"""Local Windows-only, isolated shop + existing regression suites (requires lupa/Pillow)."""
import os, sys, time, json, contextlib, argparse, hashlib, re
from zipfile import ZipFile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
assert os.name=="nt" and ROOT==Path(r"C:\Users\ccucl\Projects\Geo-UnlockDex-Shop")
sys.path[:0]=[str(ROOT/"work"),str(ROOT/"work/test-deps"),str(ROOT/"work/tests")]
from package_skin import unlock_engine
from lupa.lua51 import LuaRuntime as Lua51
from lupa.lua53 import LuaRuntime as Lua53
import check_profile_routing as routing
OUT=ROOT/"work/shop/qa"/("run-"+str(time.time_ns()))
OUT.mkdir(parents=True)
CATALOG=OUT/"catalog.lua"
parser=argparse.ArgumentParser()
parser.add_argument("--catalog",type=Path)
parser.add_argument("--host-bundle",type=Path)
options=parser.parse_args()
assembled=unlock_engine()
if options.catalog:
    assert options.catalog.read_bytes()==assembled, "Test input differs from current shared engine"
CATALOG.write_bytes(assembled)
assert CATALOG.stat().st_size<=2097152
VERSION=re.match(rb"-- avatar-unlocks/v1 ([0-9.]+)",assembled).group(1).decode()

def run(script,args,runtime=Lua51):
    lua=runtime()
    saved={}
    def remember(folder):
        selected=Path(folder).resolve()
        assert selected.is_relative_to(OUT.resolve())
        saved.clear()
        for p in selected.rglob("*"):
            if p.is_file(): saved[p]=(p.read_bytes(),p.stat().st_mtime_ns)
    def preserved():
        for p,(body,stamp) in saved.items():
            assert p.read_bytes()==body and p.stat().st_mtime_ns==stamp, str(p)
    lua.globals().rememberPriceFiles=remember
    lua.globals().assertPriceFilesPreserved=preserved
    lua.globals().arg=lua.table_from([str(x) for x in args])
    # A failed assertion must raise in Python, never terminate the runner silently.
    lua.execute('os.exit=function(code) error("exit "..tostring(code)) end')
    lua.execute(Path(script).read_text(encoding="utf-8"))

run(ROOT/"work/tests/architecture-profiles.lua",[CATALOG,str(OUT)+"/"])
wallet=OUT/"wallet"
(wallet/"geo").mkdir(parents=True)
run(ROOT/"work/tests/special-shop.lua",[CATALOG,str(wallet)+"/",str(ROOT/"DesktopSkin/@Resources")+"/",str(ROOT/"work/shop/baseline")+"/"])
prices=OUT/"prices"
for folder in ("historic-all","historic-mix"):
    (prices/folder).mkdir(parents=True)
old_prices=ROOT/"work/shop/release/publish-1/avatar-unlocks/v1/releases/1.12.15.lua"
assert hashlib.sha256(old_prices.read_bytes()).hexdigest()=="dbdb30a5315e8918c428c96dee674fc8b940fe98ce355bccbca32fd4f6d60250"
run(ROOT/"work/tests/price-compatibility.lua",[CATALOG,str(prices)+"/",str(ROOT/"DesktopSkin/@Resources")+"/",old_prices])
for name in ("family-rules","family-cache-gallery","pokemon-generations"):
    run(ROOT/"work/tests"/(name+".lua"),[CATALOG,ROOT/"DesktopSkin/@Resources/json.lua"])
run(ROOT/"work/tests/family-sync-launch.lua",[CATALOG,"quiet"],Lua53)
route=OUT/"routing"
route.mkdir()
host=ROOT/"DesktopSkin/@Resources"
HOST_VERSION=VERSION
if options.host_bundle:
    host=OUT/"deployed-host";host.mkdir()
    with ZipFile(options.host_bundle) as z:
        assert len(z.namelist())==len(set(z.namelist()))
        for name in z.namelist():
            target=(host/name).resolve();assert target.is_relative_to(host.resolve())
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
    HOST_VERSION=re.match(rb"-- avatar-unlocks/v1 ([0-9.]+)",(host/"unlock-engine.lua").read_bytes()).group(1).decode()
engine=routing.prepare(route,host,CATALOG)
if not options.host_bundle:
    (route/"res/unlock-engine.lua").write_bytes(CATALOG.read_bytes())
oldcwd=Path.cwd()
try:
    os.chdir(route)
    def case(name,mode):
        run(ROOT/"work/tests/profile-routing.lua",[route,name,"formday-buddy","4",mode,VERSION],Lua53)
    for name in routing.CASES:
        routing.setup_case(route/name,engine,VERSION)
        if name=="foreign-restart": case(name,"offline")
        case(name,name)
        if name=="switch":
            before=routing.records(route/name/"data")
            case(name,"restart")
            assert before==routing.records(route/name/"data")
    routing.setup_case(route/"shop",engine,VERSION)
    seed=json.loads((route/"shop/sync/geo-live.json").read_text())
    seed["balance"]["powder"]=15000
    (route/"shop/sync/geo-live.json").write_text(json.dumps(seed))
    run(ROOT/"work/tests/shop-host.lua",[route,"shop","formday-buddy","4","shop",VERSION],Lua53)
    for ident,dex,price in (("articuno",144,8000),("zapdos",145,8000),("moltres",146,8000),("mew",151,13000),("mewtwo",150,18000)):
        for avatar in ("formday-buddy","formday-geo"):
            for balance in (price-1,price):
                name=f"price-{avatar}-{ident}-{balance}"
                routing.setup_case(route/name,engine,VERSION)
                seed_path=route/name/"sync/geo-live.json"
                seed=json.loads(seed_path.read_text());seed["balance"]["powder"]=balance
                seed_path.write_text(json.dumps(seed))
                run(ROOT/"work/tests/price-host.lua",[route,name,avatar,"4","prices",VERSION,ident,dex,price,balance],Lua53)
    routing.setup_case(route/"reader-guard",engine,VERSION)
    guard=route/"reader-guard/cache/FormdayAvatar/Unlocks/v1"
    older=(ROOT/"work/shop/baseline/catalog.lua").read_bytes().replace(b"1.12.14",b"99.0.0")
    (guard/"99.0.0.lua").write_bytes(older)
    (guard/"active.txt").write_text("99.0.0")
    run(ROOT/"work/tests/profile-routing.lua",[route,"reader-guard","formday-buddy","4","switch",HOST_VERSION],Lua53)
finally:
    os.chdir(oldcwd)
print("PASS all suites; artifacts:",OUT,flush=True)
