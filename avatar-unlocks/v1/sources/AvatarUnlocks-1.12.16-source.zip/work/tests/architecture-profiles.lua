-- The exact shared session/storage contract, including a hypothetical new host.
local catalog,base=unpack(arg)
local M=assert(loadfile(catalog))()
M.specialShopEnabled=true
local function session(a,p) return M.connect(base,a,p,{}) end
local profiles={{"formday-buddy","owner"},{"formday-buddy","other"},
 {"formday-geo","owner"},{"synthetic-new","owner"}}
local sessions={}
for i,key in ipairs(profiles) do
 local s=session(unpack(key));sessions[i]=s
 assert(s.wallet.powder==0 and not s:owns("zapdos"),"fresh profile inherited data")
 assert(s:earn(6000+i));assert(s.wallet.powder==30000+i*5,"independent earned balance")
end
for i,s in ipairs(sessions) do
 assert(s:purchase("zapdos"),"profile could not independently purchase")
 local again=session(unpack(profiles[i]))
 assert(again:owns("zapdos") and again.wallet.powder==22000+i*5,"restart/profile isolation")
 assert(not again:purchase("zapdos"),"duplicate purchase")
 for j,key in ipairs(profiles) do
  if j>i then assert(not session(unpack(key)):owns("zapdos"),"ownership leaked across profile") end
 end
end
print("PASS architecture: one session contract, 4 independent identities, restart and duplicate debit")
