local root, machine, avatar, level, mode, catalogVersion = table.unpack(arg,1,6)
local base = root.."/"..machine
local shared = base.."/cache/FormdayAvatar/Unlocks/v1/"
local path = function(s) return (s:gsub("\\","/")) end
local nativeOpen, nativeRename, nativeRemove = io.open, os.rename, os.remove
local nativeLoad, nativeEnv = loadfile, os.getenv
io.open=function(p,mode) return nativeOpen(path(p),mode) end
os.rename=function(a,b) return nativeRename(path(a),path(b)) end
os.remove=function(p) return nativeRemove(path(p)) end
loadfile=function(p,...) return nativeLoad(path(p),...) end
dofile=function(p) return assert(loadfile(p))() end
os.getenv=function(k)
  if k=="LOCALAPPDATA" then return base.."/cache" end
  if k=="SystemRoot" then return base.."/simulated-windows" end
  return nativeEnv(k)
end
unpack=table.unpack
getfenv=function() return _G end
setfenv=function(fn,env)
  for i=1,64 do
    local name=debug.getupvalue(fn,i)
    if name=="_ENV" then debug.setupvalue(fn,i,env);return fn end
    if not name then break end
  end
  return fn
end
local vars={UnlockAvatar=avatar,UnlockProfile="audit",UnlockLevel=tostring(level),Level=tostring(level),UnlockEnabled="1",UnlockDataPath=base.."/data/",SyncFolder=base.."/sync",CURRENTPATH=base.."/skin/",CURRENTCONFIG="AuditSkin",["@"]=root.."/res/"}
local visible,opts={},{}
SKIN={
 GetVariable=function(_,n) return vars[n] end,
 GetMeter=function() return nil end,
 GetMeasure=function() return nil end,
 Bang=function(_,cmd,a,b,c)
   if cmd=="!SetVariable" then vars[a]=b
   elseif cmd=="!SetOption" then opts[a]=opts[a] or {};opts[a][b]=c
   elseif cmd=="!ShowMeter" or cmd=="!HideMeter" then visible[a]=cmd=="!ShowMeter" end
 end
}
SELF={GetName=function() return "AvatarUnlocks" end,GetOption=function(_,n) if n=="ResourcePath" then return root.."/res/" end end}
local function check(value, message)
    if not value then error(message, 2) end
end
local function bytes(name)
    local f=io.open(name,"rb")
    if not f then return nil end
    local body=f:read("*a");f:close();return body
end
local function write(name, body)
    local f=assert(io.open(name,"wb"))
    assert(f:write(body));assert(f:close())
end
local function loadSnapshot(name)
    write(base.."/sync/geo-live.json",assert(bytes(base.."/"..name..".json")))
end
local function hasPet(avatarId, profile, pet, directory)
    return bytes((directory or base.."/data/").."unlock~"..avatarId.."~"..profile.."~"..pet..".owned")==pet.."\n"
end
local function ledgerCount(prefix,fmt)
    local i=0
    while bytes(prefix..string.format(fmt,i+1)) do i=i+1 end
    return i
end
local function geoCount(folder)
    return ledgerCount(folder.."geo-local-wallet-v1-","%08d.json")
end
local function buddyCount(folder,profile)
    return ledgerCount(folder.."unlock~formday-buddy~"..profile.."~wallet-","%09d.txn")
end
local data=base.."/data/"
local alt=base.."/other/"
local buddy,geo="formday-buddy","formday-geo"
local function start(a,profile,total)
    vars.UnlockAvatar,vars.UnlockProfile,vars.Total=a,profile,tostring(total)
    vars.Level,vars.UnlockLevel="4","4"
    dofile(root.."/res/geo-unlocks.lua")
    Initialize();Update();Update()
    check(vars.UnlockSystemVersion==catalogVersion,"current catalog did not load")
end
local function switch(a,profile,total)
    vars.UnlockAvatar,vars.UnlockProfile,vars.Total=a,profile,tostring(total)
    RefreshWallet()
end

local function eq(a,b,label) check(a==b,(label or "value")..": "..tostring(a).." ~= "..tostring(b)) end
local function native(s)
 return (s:gsub("[\128-\255][\128-\191]*",function(c)
 local a,b,d=c:byte(1,3);local n=#c==2 and (a-192)*64+b-128 or ((a-224)*64+b-128)*64+d-128
 return string.format("[\\x%04x]",n) end))
end
local function text(m,s) check(opts[m].Text:find(native(s),1,true),m.." missing "..s..": "..opts[m].Text) end
local function number(m,s) check(opts[m].Text:find(s,1,true),m.." missing "..s) end
local function click(m)
 local action=opts[m].LeftMouseUpAction
 local token=action:match('GalleryPurchase%((%d+)%)')
 check(token,"no purchase action: "..action)
 GalleryPurchase(tonumber(token));return tonumber(token)
end
local function findZapdos()
 GalleryTab(3);for i=1,16 do GalleryPage(1) end
 -- Dex 145 is first card on page 17. 144 Articuno is last on page 16.
 text("GalleryName1","썬더");number("GalleryName1","8,000")
 GallerySelect(1);text("GalleryTitle","썬더")
end
start(buddy,"owner",6000);OpenPanel();findZapdos()
text("GalleryPageNumber","구매");number("GalleryCount","30,000")
local token=click("GalleryPageNumber")
text("GalleryPageNumber","꺼내기");text("GalleryCount","구매 완료")
eq(buddyCount(data,"owner"),2);GalleryPurchase(token);eq(buddyCount(data,"owner"),2)
GalleryCompanion();eq(vars.UnlockCompanionCount,"1","summon");check(bytes(data.."unlock~formday-buddy~owner~pokemon-roster.selection"):find("=zapdos!",1,true),"roster")
GalleryBack();findZapdos();text("GalleryPageNumber","돌려보내기")
-- Restart reads purchase; preserved independent Geo balance is 15,000.
start(buddy,"owner",6000);OpenPanel();findZapdos();text("GalleryPageNumber","돌려보내기")
switch(geo,"owner",90);findZapdos();number("GalleryCount","15,000");click("GalleryPageNumber")
eq(geoCount(data),2);text("GalleryPageNumber","꺼내기");eq(buddyCount(data,"owner"),2)
GalleryBack();GalleryPage(-1);GallerySelect(9);text("GalleryTitle","프리져");text("GalleryPageNumber","부족");eq(opts.GalleryPageNumber.LeftMouseUpAction,"")
-- Stale quote cannot debit a different profile after a live switch.
switch(buddy,"rich",6000);findZapdos();local stale=tonumber(opts.GalleryPageNumber.LeftMouseUpAction:match('GalleryPurchase%((%d+)%)'))
vars.UnlockProfile="poor";vars.Total="0";GalleryPurchase(stale);eq(buddyCount(data,"poor"),0);eq(buddyCount(data,"rich"),1)
-- Future avatar uses this exact module, same UI, separate receipt prefix.
switch("synthetic-new","owner",6000);findZapdos();text("GalleryPageNumber","구매");click("GalleryPageNumber")
eq(bytes(data.."unlock~synthetic-new~owner~wallet-000000002.txn"),"P zapdos 8000\n")
eq(buddyCount(data,"owner"),2);eq(geoCount(data),2)
print("PASS host UI function path: Buddy + Geo + synthetic avatar, price/status, buy, restart, duplicate, insufficient, summon, stale-profile quote")
