﻿[CmdletBinding()]
param(
 [Parameter(Mandatory)][ValidatePattern('^[0-9a-f]{40}$')][string]$SourceCommit,
 [Parameter(Mandatory)][string]$BuddyBundle,
 [Parameter(Mandatory)][string]$CatalogBundle,
 [Parameter(Mandatory)][string]$BuddyFeed,
 [Parameter(Mandatory)][string]$CatalogFeed,
 [Parameter(Mandatory)][string]$PublicKey
)
$ErrorActionPreference='Stop'
function HashFile([string]$p) {
 $h=[Security.Cryptography.SHA256]::Create()
 $f=[IO.File]::OpenRead($p)
 try {return [BitConverter]::ToString($h.ComputeHash($f)).Replace('-','').ToLowerInvariant()}
 finally {$f.Dispose();$h.Dispose()}
}
if((HashFile $PublicKey) -ne 'dbdf0a7785dde4ed57ce8d49e9fc8428beed042a721f335d0862814000b48cd3') {throw 'Unexpected public key'}
$rsa=[Security.Cryptography.RSACryptoServiceProvider]::new()
$rsa.PersistKeyInCsp=$false
try {
 $rsa.FromXmlString([IO.File]::ReadAllText($PublicKey))
 $catalogBytes=[IO.File]::ReadAllBytes($CatalogFeed+'.attestation.json')
 $catalogSig=[Convert]::FromBase64String([IO.File]::ReadAllText($CatalogFeed+'.attestation.sig'))
 if(-not $rsa.VerifyData($catalogBytes,'SHA256',$catalogSig)) {throw 'Invalid catalog attestation'}
 $catalogRecord=[Text.Encoding]::UTF8.GetString($catalogBytes) | ConvertFrom-Json
 $items=@(@('buddy',$BuddyFeed,$BuddyBundle),@('avatar-unlocks/v1',$CatalogFeed,$CatalogBundle))
 if($catalogRecord.release_scope -eq 'catalog-only') {
  if($catalogRecord.checks.deployed_host -ne 'passed') {throw 'Deployed host check missing'}
  $buddyLines=[IO.File]::ReadAllLines($BuddyFeed)
  if($buddyLines.Length -ne 2 -or -not $rsa.VerifyData([Text.Encoding]::ASCII.GetBytes($buddyLines[0]),'SHA256',[Convert]::FromBase64String($buddyLines[1]))) {throw 'Invalid unchanged Buddy feed'}
  if($buddyLines[0] -ne ($catalogRecord.versions.buddy+'|'+(HashFile $BuddyBundle))) {throw 'Buddy feed differs from checked deployed host'}
  $items=@(,@('avatar-unlocks/v1',$CatalogFeed,$CatalogBundle))
 }
 foreach($item in $items) {
  $channel,$feed,$bundle=$item
  $bytes=[IO.File]::ReadAllBytes($feed+'.attestation.json')
  $signature=[Convert]::FromBase64String([IO.File]::ReadAllText($feed+'.attestation.sig'))
  if(-not $rsa.VerifyData($bytes,'SHA256',$signature)) {throw 'Invalid check attestation signature'}
  $record=[Text.Encoding]::UTF8.GetString($bytes) | ConvertFrom-Json
  if($record.schema -ne 1 -or $record.repository -ne 'ccucle/frame7-nav' -or $record.branch -ne 'formday-buddy-updates') {throw 'Wrong publication target'}
  if($record.source_commit -ne $SourceCommit) {throw 'Different source commit'}
  if($record.channel -ne $channel) {throw 'Different channel'}
  if($record.verifier_sha256 -ne '493f11b3a65198a07f5017f54531e1c3d199868692ee8cbaf9c18bea9ea274bb' -or $record.source_manifest_sha256 -ne 'e780a308de54f993833564cc2fa83e63abe9c337110c7485d4e28aac55530aea') {throw 'Untrusted verification revision'}
  if($record.checks.architecture -ne 'passed' -or $record.checks.package -ne 'passed' -or $record.checks.profiles_and_shop -ne 'passed') {throw 'Required check missing/failed'}
  if((HashFile $BuddyBundle) -ne $record.artifacts.buddy_sha256 -or (HashFile $CatalogBundle) -ne $record.artifacts.catalog_sha256) {throw 'Artifacts changed after checks'}
  $lines=[IO.File]::ReadAllLines($feed)
  if($lines.Length -ne 2 -or -not $rsa.VerifyData([Text.Encoding]::ASCII.GetBytes($lines[0]),'SHA256',[Convert]::FromBase64String($lines[1]))) {throw 'Invalid feed signature'}
  $expected=$record.feed_version+'|'+(HashFile $bundle)
  if($channel -ne 'buddy') {$expected=$channel+'|'+$expected}
  if($lines[0] -ne $expected) {throw 'Feed does not match checked artifact'}
 }
 Write-Output 'PASS_LOCAL_PUBLICATION_EVIDENCE_ONLY'
} finally {$rsa.Dispose()}
