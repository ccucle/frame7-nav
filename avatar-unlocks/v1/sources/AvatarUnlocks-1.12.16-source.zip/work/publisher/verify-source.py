"""Trusted Windows publisher verifier. No key or GitHub credentials are handled here."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

ROOT = Path(r"C:\Users\ccucl\Projects\Geo-UnlockDex-Shop")
def fail(message):
    raise RuntimeError(message)
def sha(body):
    return hashlib.sha256(body).hexdigest()
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--source-commit",required=True)
    ap.add_argument("--buddy",type=Path,required=True)
    ap.add_argument("--catalog",type=Path,required=True)
    ap.add_argument("--result",type=Path,required=True)
    a=ap.parse_args()
    if not re.fullmatch("[0-9a-f]{40}",a.source_commit): fail("Exact source commit required")
    trusted=json.loads(Path(__file__).with_name("source-manifest.json").read_text())
    if sha(a.buddy.read_bytes())!=trusted["artifacts"]["buddy_sha256"] or sha(a.catalog.read_bytes())!=trusted["artifacts"]["catalog_sha256"]:
        fail("Artifact differs from reviewed exact SHA-256")
    # The signer holds non-writable file handles for these inputs throughout this process.
    for name,expected in trusted["files"].items():
        if sha((ROOT/name).read_bytes())!=expected: fail("Source differs from trusted input: "+name)
    archive=subprocess.run(["git","-C",str(ROOT),"archive","--format=zip",a.source_commit],
                           check=True,capture_output=True).stdout
    with ZipFile(io.BytesIO(archive)) as z:
        for name,expected in trusted["files"].items():
            try: body=z.read(name)
            except KeyError: fail("Source commit misses checked input: "+name)
            if sha(body)!=expected: fail("Source commit differs from checked input: "+name)
    sys.path.insert(0,str(ROOT/"work"))
    from architecture_gate import check_pair, check_catalog_update
    scope=trusted.get("release_scope","paired")
    if scope not in ("paired","catalog-only"): fail("Unknown trusted release scope")
    hashes=check_catalog_update(a.catalog,a.buddy) if scope=="catalog-only" else check_pair(a.catalog,a.buddy)
    # Run the actual package regression entry point; capture evidence in the signed record.
    command=[sys.executable,"-B",str(ROOT/"work/tests/run_shop.py"),"--catalog",str(a.catalog)]
    if scope=="catalog-only": command += ["--host-bundle",str(a.buddy)]
    test=subprocess.run(command,cwd=ROOT,capture_output=True)
    if test.returncode:
        sys.stderr.buffer.write(test.stdout+test.stderr)
        fail("Mandatory regressions failed")
    sys.stdout.buffer.write(test.stdout)
    for name,expected in trusted["files"].items():
        if sha((ROOT/name).read_bytes())!=expected: fail("Source changed during checks: "+name)
    if hashes["buddy_sha256"]!=sha(a.buddy.read_bytes()) or hashes["catalog_sha256"]!=sha(a.catalog.read_bytes()):
        fail("Artifact changed during checks")
    result=dict(schema=1, release_scope=scope, repository="ccucle/frame7-nav",branch="formday-buddy-updates",
                source_commit=a.source_commit,
                source_manifest_sha256=sha(Path(__file__).with_name("source-manifest.json").read_bytes()),
                verifier_sha256=sha(Path(__file__).read_bytes()),
                source_inputs_sha256=sha(json.dumps(trusted["files"],sort_keys=True,separators=(",",":")).encode()),
                artifacts=hashes,versions=trusted["versions"],
                checks={"architecture":"passed","package":"passed","profiles_and_shop":"passed","deployed_host":"passed" if scope=="catalog-only" else "paired"},
                regression_log_sha256=sha(test.stdout+test.stderr))
    a.result.write_text(json.dumps(result,sort_keys=True,separators=(",",":")),encoding="utf-8")
if __name__=="__main__":main()
