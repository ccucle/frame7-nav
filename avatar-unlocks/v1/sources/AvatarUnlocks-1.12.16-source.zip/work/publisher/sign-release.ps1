﻿[CmdletBinding()]
param(
 [Parameter(Mandatory)][string]$Bundle,
 [Parameter(Mandatory)][string]$Version,
 [Parameter(Mandatory)][string]$Feed,
 [Parameter(Mandatory)][string]$PublicKey,
 [ValidateSet('buddy','avatar-unlocks/v1')][string]$Channel='buddy',
 [Parameter(Mandatory)][ValidatePattern('^[0-9a-f]{40}$')][string]$SourceCommit,
 [Parameter(Mandatory)][string]$BuddyBundle,
 [Parameter(Mandatory)][string]$CatalogBundle
)
$ErrorActionPreference='Stop'
$root='C:\Users\ccucl\Projects\Geo-UnlockDex-Shop'
$python='C:\Users\ccucl\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$verifier=Join-Path $PSScriptRoot 'gate\verify-source.py'
$manifest=Join-Path $PSScriptRoot 'gate\source-manifest.json'
$cloudPaths=@{
 'C:\Users\ccucl\iCloudDrive'='0x9000301a'
 'C:\Users\ccucl\iCloudDrive\AI'='0x9000601a'
 'C:\Users\ccucl\iCloudDrive\AI\AI 2026 자동화 매매매도 시스템'='0x9000601a'
 'C:\Users\ccucl\iCloudDrive\AI\AI 2026 자동화 매매매도 시스템\FormdayPet'='0x9000601a'
 'C:\Users\ccucl\iCloudDrive\AI\AI 2026 자동화 매매매도 시스템\FormdayPet\work'='0x9000601a'
 'C:\Users\ccucl\iCloudDrive\AI\AI 2026 자동화 매매매도 시스템\FormdayPet\work\publisher'='0x9000601a'
 'C:\Users\ccucl\iCloudDrive\AI\AI 2026 자동화 매매매도 시스템\FormdayPet\work\publisher\gate'='0x9000601a'
 'C:\Users\ccucl\iCloudDrive\AI\AI 2026 자동화 매매매도 시스템\FormdayPet\work\publisher\gate\source-manifest.json'='0x9000601a'
 'C:\Users\ccucl\iCloudDrive\AI\AI 2026 자동화 매매매도 시스템\FormdayPet\work\publisher\gate\verify-source.py'='0x9000601a'
 'C:\Users\ccucl\iCloudDrive\AI\AI 2026 자동화 매매매도 시스템\FormdayPet\work\publisher\publisher.dpapi'='0x9000601a'
}
$locks=[Collections.Generic.List[IO.FileStream]]::new()
$created=[Collections.Generic.List[string]]::new()
$rsa=$null
$result=$null
function HashFile([string]$p) {
 $h=[Security.Cryptography.SHA256]::Create()
 $f=[IO.File]::OpenRead($p)
 try {return [BitConverter]::ToString($h.ComputeHash($f)).Replace('-','').ToLowerInvariant()}
 finally {$f.Dispose();$h.Dispose()}
}
function LockFile([string]$p) {
 $full=[IO.Path]::GetFullPath($p)
 $walk=$full
 while($walk) {
  if(([IO.File]::GetAttributes($walk) -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
   if(-not $cloudPaths.ContainsKey($walk)) {throw "Unreviewed reparse path rejected: $walk"}
   $metadata=& "$env:SystemRoot\System32\fsutil.exe" reparsepoint query $walk 2>&1
   if($LASTEXITCODE -ne 0) {throw 'Reparse metadata unavailable'}
   $tag=[regex]::Match(($metadata -join ' '),'0x[0-9a-fA-F]{8}').Value.ToLowerInvariant()
   if($tag -ne $cloudPaths[$walk]) {throw "Changed reparse tag rejected: $walk"}
  }
  $walk=[IO.Path]::GetDirectoryName($walk)
 }
 $stream=[IO.File]::Open($full,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
 $locks.Add($stream)
 return $full
}
function NewFile([string]$path,[byte[]]$bytes) {
 $stream=[IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
 $created.Add($path)
 try {$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)} finally {$stream.Dispose()}
}
try {
 $null=LockFile $verifier; $null=LockFile $manifest
 if((HashFile $verifier) -ne '493f11b3a65198a07f5017f54531e1c3d199868692ee8cbaf9c18bea9ea274bb' -or (HashFile $manifest) -ne 'e780a308de54f993833564cc2fa83e63abe9c337110c7485d4e28aac55530aea') {throw 'Untrusted publisher verifier/configuration'}
 $inputs=Get-Content -LiteralPath $manifest -Raw | ConvertFrom-Json
 if($inputs.release_scope -eq 'catalog-only' -and $Channel -ne 'avatar-unlocks/v1') {throw 'Catalog-only release cannot sign Buddy'}
 foreach($entry in $inputs.files.PSObject.Properties) {
  $p=LockFile (Join-Path $root $entry.Name)
  if((HashFile $p) -ne $entry.Value) {throw "Reviewed source input changed: $($entry.Name)"}
 }
 $BuddyBundle=LockFile $BuddyBundle
 $CatalogBundle=LockFile $CatalogBundle
 $Bundle=[IO.Path]::GetFullPath($Bundle)
 $expected=if($Channel -eq 'buddy') {$BuddyBundle} else {$CatalogBundle}
 if($Bundle -ne $expected) {throw 'Bundle is not the checked channel artifact'}
 $expectedVersion=if($Channel -eq 'buddy') {$inputs.versions.buddy} else {$inputs.versions.catalog}
 if($Version -ne $expectedVersion) {throw 'Version differs from reviewed source'}
 $PublicKey=LockFile $PublicKey
 if((HashFile $PublicKey) -ne 'dbdf0a7785dde4ed57ce8d49e9fc8428beed042a721f335d0862814000b48cd3') {throw 'Unexpected official public key'}
 $Feed=[IO.Path]::GetFullPath($Feed)
 foreach($path in @($Feed,($Feed+'.attestation.json'),($Feed+'.attestation.sig'))) {
  if(Test-Path -LiteralPath $path) {throw "Refusing to overwrite output: $path"}
 }
 $result=Join-Path ([IO.Path]::GetDirectoryName($Feed)) ([Guid]::NewGuid().ToString('N')+'.gate-result.json')
 Write-Output 'GATE_LOCKED'
 & $python -I -B $verifier --source-commit $SourceCommit --buddy $BuddyBundle --catalog $CatalogBundle --result $result
 if($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $result)) {throw 'Mandatory release verification failed'}
 $record=Get-Content -LiteralPath $result -Raw | ConvertFrom-Json
 if($record.source_commit -ne $SourceCommit -or $record.checks.profiles_and_shop -ne 'passed') {throw 'Incomplete check receipt'}
 if($inputs.release_scope -eq 'catalog-only' -and ($record.release_scope -ne 'catalog-only' -or $record.checks.deployed_host -ne 'passed')) {throw 'Deployed host compatibility check missing'}
 if((HashFile $BuddyBundle) -ne $record.artifacts.buddy_sha256 -or (HashFile $CatalogBundle) -ne $record.artifacts.catalog_sha256) {throw 'Artifact changed after verification'}
 # Only this point can access the existing key. No key creation, export, migration or rotation.
 Add-Type -AssemblyName System.Security
 $secret=LockFile (Join-Path $PSScriptRoot 'publisher.dpapi')
 $rsa=[Security.Cryptography.RSACryptoServiceProvider]::new(2048)
 $rsa.PersistKeyInCsp=$false
 $raw=[Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($secret),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
 try {$rsa.ImportCspBlob($raw)} finally {[Array]::Clear($raw,0,$raw.Length)}
 if([IO.File]::ReadAllText($PublicKey) -ne $rsa.ToXmlString($false)) {throw 'Publisher key mismatch'}
 $record | Add-Member -NotePropertyName channel -NotePropertyValue $Channel
 $record | Add-Member -NotePropertyName feed_version -NotePropertyValue $Version
 $record | Add-Member -NotePropertyName checked_at_utc -NotePropertyValue ([DateTime]::UtcNow.ToString('o'))
 $recordBytes=[Text.UTF8Encoding]::new($false).GetBytes(($record | ConvertTo-Json -Depth 12 -Compress))
 $recordSignature=$rsa.SignData($recordBytes,'SHA256')
 $message=$Version+'|'+(HashFile $Bundle)
 if($Channel -ne 'buddy') {$message=$Channel+'|'+$message}
 $signature=$rsa.SignData([Text.Encoding]::ASCII.GetBytes($message),'SHA256')
 NewFile ($Feed+'.attestation.json') $recordBytes
 NewFile ($Feed+'.attestation.sig') ([Text.Encoding]::ASCII.GetBytes([Convert]::ToBase64String($recordSignature)))
 NewFile $Feed ([Text.Encoding]::ASCII.GetBytes($message+"`r`n"+[Convert]::ToBase64String($signature)+"`r`n"))
 $created.Clear()
 Write-Output 'SIGNED_CHECKED_ARTIFACT'
} catch {
 foreach($path in $created) {[IO.File]::Delete($path)}
 throw
} finally {
 if($rsa) {$rsa.Dispose()}
 foreach($handle in $locks) {$handle.Dispose()}
 if($result -and (Test-Path -LiteralPath $result)) {[IO.File]::Delete($result)}
}
