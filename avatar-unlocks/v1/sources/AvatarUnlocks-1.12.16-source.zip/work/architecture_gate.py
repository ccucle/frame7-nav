"""Mandatory local module boundary and artifact checks; no network or live data access."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
CONTRACT = ROOT / "work/architecture/contract.json"
CODE_SUFFIXES = {".lua", ".ps1", ".template", ".inc", ".ini", ".py", ".bat", ".cmd",
                 ".exe", ".dll", ".js", ".vbs", ".psm1", ".psd1"}


class BoundaryError(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise BoundaryError(message)


def digest(body):
    return hashlib.sha256(body).hexdigest()


def check_sources(root=ROOT):
    """Reviewed legacy capabilities are sealed, not inferred with a bypassable I/O regex."""
    root = Path(root)
    contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
    require(contract["schema"] == 1, "Unsupported module contract")
    modules = contract["modules"]
    actual = {p.relative_to(root).as_posix()
              for base in ("AvatarUnlocks", "DesktopSkin/@Resources")
              for p in (root / base).rglob("*")
              if p.is_file() and p.suffix.lower() in CODE_SUFFIXES
              and p.relative_to(root).as_posix() != "DesktopSkin/@Resources/unlock-engine.lua"}
    registered_code = {n for n in modules if Path(n).suffix.lower() in CODE_SUFFIXES}
    require(actual == registered_code,
            f"Unregistered/missing executable module: {sorted(actual ^ registered_code)}")
    for name, spec in modules.items():
        p = root / name
        require(p.is_file() and digest(p.read_bytes()) == spec["sha256"],
                f"Unreviewed {spec['role']} implementation: {name}. Review contract and isolation evidence.")
    policy = (root / contract["policy_owner"]).read_text(encoding="utf-8")
    # Additional independent ownership constraints, even if a seal is accidentally refreshed.
    require(not re.search(r"\b(?:io|os|SKIN|loadfile|dofile|require|loadstring|debug)\b", policy),
            "Purchase policy cannot access host/storage/runtime capabilities")
    require("formday-buddy" not in policy and "formday-geo" not in policy,
            "Shared purchase policy cannot branch on avatar identities")
    owners = []
    for name in registered_code:
        if Path(name).suffix == ".lua":
            raw = (root / name).read_bytes()
            text = raw.decode("utf-16" if raw.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig")
            if re.search(r"\bM\.specialPrices\s*=", text):
                owners.append(name)
    require(owners == [contract["policy_owner"]], f"Purchase policy must have one owner: {owners}")
    for name, sha in contract["verification_tools"].items():
        require((root / name).is_file() and digest((root / name).read_bytes()) == sha,
                f"Unreviewed build/check implementation: {name}")
    return contract


def read_zip(path):
    with ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), f"Duplicate ZIP members: {path}")
        require(archive.testzip() is None, f"Corrupt ZIP: {path}")
        return {n: archive.read(n) for n in names if not n.endswith("/")}


def check_pair(catalog, buddy_zip, root=ROOT):
    """One generated engine plus exact approved host bindings, not only equal version strings."""
    check_sources(root)
    from package_skin import unlock_engine
    generated = unlock_engine()
    body = Path(catalog).read_bytes()
    require(len(body) <= 2097152, "Catalog exceeds updater 2 MiB limit")
    require(body == generated, "Catalog differs from assembled shared engine")
    require((Path(root) / "DesktopSkin/@Resources/unlock-engine.lua").read_bytes() == generated,
            "Bundled engine is stale or differs from shared engine")
    inventory = (Path(root) / "work/buddy-files.txt").read_text().splitlines()
    require(inventory and len(inventory) == len(set(inventory)), "Invalid Buddy inventory")
    entries = read_zip(buddy_zip)
    require(set(entries) == set(inventory), "Buddy package inventory differs")
    for name in inventory:
        path = (Path(root) / "DesktopSkin/@Resources" / name).resolve()
        require(path.is_relative_to((Path(root) / "DesktopSkin/@Resources").resolve()),
                f"Unsafe package path: {name}")
        expected = generated if name == "unlock-engine.lua" else path.read_bytes()
        require(entries[name] == expected, f"Unapproved host artifact: {name}")
    return {"catalog_sha256": digest(body), "buddy_sha256": digest(Path(buddy_zip).read_bytes())}


def run_regressions(catalog):
    # Always a separate process. Failure/absent dependencies cannot be mistaken for a skipped test.
    subprocess.run([sys.executable, "-B", str(ROOT / "work/tests/run_shop.py"),
                    "--catalog", str(Path(catalog).resolve())], cwd=ROOT, check=True)


def check_release(directory):
    """Validate the actual two-feed, update-ZIP, installer, connect-kit and source layout.
    This is a local prerequisite; it neither signs nor uploads.
    """
    directory = Path(directory).resolve()
    def feed(relative, channel=None):
        lines = (directory / relative).read_text().splitlines()
        require(len(lines) >= 2 and lines[1], f"Missing signed feed: {relative}")
        parts = lines[0].split("|")
        require(len(parts) == (3 if channel else 2), f"Invalid feed: {relative}")
        if channel:
            require(parts.pop(0) == channel, "Wrong catalog channel")
        version, sha = parts
        require(re.fullmatch(r"\d+\.\d+\.\d+", version) is not None, "Unsafe version")
        require(re.fullmatch(r"[0-9a-f]{64}", sha) is not None, "Invalid feed hash")
        return version, sha
    bv, bh = feed("buddy/feed.txt")
    cv, ch = feed("avatar-unlocks/v1/feed.txt", "avatar-unlocks/v1")
    catalog = directory / f"avatar-unlocks/v1/releases/{cv}.lua"
    buddy = directory / f"buddy/releases/{bv}.zip"
    require(digest(catalog.read_bytes()) == ch and digest(buddy.read_bytes()) == bh,
            "Feed/artifact digest mismatch")
    result = check_pair(catalog, buddy)
    resources = read_zip(buddy)
    installer = read_zip(directory / f"buddy/installers/FormdayBuddy-{bv}.rmskin")
    for slot in ("A", "B"):
        prefix = f"Skins/FormdayBuddy/@Resources/{slot}/"
        actual = {n[len(prefix):]: b for n,b in installer.items() if n.startswith(prefix)}
        require(actual == resources, f"Installer slot {slot} differs from checked update")
    bindings = check_sources()["artifact_bindings"]
    bootstrap = {n:digest(b) for n,b in installer.items()
                 if not n.startswith(("Skins/FormdayBuddy/@Resources/A/", "Skins/FormdayBuddy/@Resources/B/"))}
    require(bootstrap == bindings["installer_bootstrap"], "Unreviewed installer bootstrap")
    kit = read_zip(directory / "avatar-unlocks/v1/connect-kit.zip")
    require({n:digest(b) for n,b in kit.items() if n != "AvatarUnlocks/unlock-engine.lua"}
            == bindings["connect_kit"], "Unreviewed connect-kit binding")
    require(kit.get("AvatarUnlocks/unlock-engine.lua") == catalog.read_bytes(),
            "Connect-kit engine differs")
    source = read_zip(directory / f"avatar-unlocks/v1/sources/AvatarUnlocks-{cv}-source.zip")
    for name in check_sources()["modules"]:
        require(source.get(name) == (ROOT / name).read_bytes(), f"Source artifact differs: {name}")
    # Only reads/checks staged artifacts. Existing platform signature verification remains mandatory.
    run_regressions(catalog)
    return dict(result, buddy_version=bv, catalog_version=cv,
                signature_verification="separate existing publisher/updater requirement")

def check_catalog_update(catalog, buddy_zip, root=ROOT):
    """Catalog-only release: byte-exact unchanged deployed host; only price table/version delta."""
    check_sources(root)
    from package_skin import unlock_engine
    body = Path(catalog).read_bytes()
    require(body == unlock_engine() and len(body) <= 2097152, "Catalog assembly/size mismatch")
    entries = read_zip(buddy_zip)
    require(digest(Path(buddy_zip).read_bytes()) ==
            "af048b43cac301af574362b21a93d366c0f7b306dda757d4df56e4ccd1fdb225",
            "Catalog-only release changed deployed Buddy")
    old = entries["unlock-engine.lua"]
    require(digest(old) == "dbdb30a5315e8918c428c96dee674fc8b940fe98ce355bccbca32fd4f6d60250",
            "Unexpected deployed catalog baseline")
    old_version = re.search(rb"^-- avatar-unlocks/v1 ([0-9.]+)",old).group(1)
    version = re.search(rb"^-- avatar-unlocks/v1 ([0-9.]+)",body).group(1)
    require(tuple(map(int,version.split(b"."))) > tuple(map(int,old_version.split(b"."))),
            "Catalog version must increase")
    pattern = rb"M\.specialPrices=\{[^}]+\}"
    old_price = re.findall(pattern,old);new_price = re.findall(pattern,body)
    require(len(old_price)==len(new_price)==1, "Price owner ambiguous")
    require(old.count(old_version)==2, "Unexpected baseline version references")
    expected = old.replace(old_version,version).replace(old_price[0],new_price[0],1)
    require(body==expected, "Catalog-only release changes more than shared prices/version")
    inventory=(Path(root)/"work/buddy-files.txt").read_text().splitlines()
    require(set(entries)==set(inventory), "Deployed host inventory mismatch")
    for name in inventory:
        if name!="unlock-engine.lua":
            require(entries[name]==(Path(root)/"DesktopSkin/@Resources"/name).read_bytes(),
                    "Catalog-only release changes host resource: "+name)
    return {"catalog_sha256":digest(body),"buddy_sha256":digest(Path(buddy_zip).read_bytes())}
