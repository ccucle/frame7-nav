"""Fail-closed local release-layout preflight. Does not sign, install or publish."""
import argparse
import json
from pathlib import Path
from architecture_gate import check_release

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path, help="staged official two-component publication tree")
    args = parser.parse_args()
    print(json.dumps(check_release(args.directory), indent=2))
