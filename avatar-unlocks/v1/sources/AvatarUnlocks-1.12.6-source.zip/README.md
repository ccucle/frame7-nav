# Formday 아바타 통합 편집 소스

본체 0.6.28과 도감 1.12.6의 Windows 제작 소스다. 아래 빌드 명령은 같은 소스에서 로컬 검수용 파일을 만든다.

| 수정 대상 | 편집 위치 |
| --- | --- |
| 가족 해금 레벨·가루·진화 규칙의 검증과 적용 | `AvatarUnlocks/family-rules.lua` |
| 도감 실행과 세션 전환, 가족 규칙 수신 | `AvatarUnlocks/runtime.lua`, `AvatarUnlocks/evolution-client.lua` |
| 도감 화면과 지갑 | `AvatarUnlocks/gallery.lua`, `AvatarUnlocks/wallet.lua` |
| 본체에서 캐릭터·프로필별 기록을 여는 경로 | `DesktopSkin/@Resources/desktop.lua`, `geo-unlocks.lua`, `geo-state.lua` |
| 포켓몬 산책 애니메이션과 표시 크기 | `AvatarUnlocks/walk-rows.json`이 종마다 지정하는 PNG, `roam-manager.lua` |
| 데이터 백업·격리 복원 | `work/backup/avatar_backup.py`와 같은 폴더의 사용 설명서 |

## 검수본 빌드

Python 3.10 이상과 Pillow가 필요하다. 이 폴더에서 새 출력 폴더를 지정한다.

```powershell
python -B work/build_review.py ..\Formday-review
```

생성물은 `FormdayBuddy-review.zip`과 `AvatarUnlocks-review.lua`다. 본체에 새 리소스를 추가할 때는 `work/buddy-files.txt`에 패키지 안의 상대 경로도 추가한다. 기존 본체의 `unlock-engine.lua`는 독립 업데이트에 쓰이는 번들 사본이다. 별도로 업데이트하는 최신 도감은 `AvatarUnlocks`에서 빌드한다.

산책 시트는 등록한 159개 행의 프레임과 시간을 기준으로 조립한다. 같은 픽셀일 때 기존 팀의 압축 PNG를 재사용한다. 22개 행은 공개 시트에서 복원한 표시용 스트립을 가리킨다. 해당 행의 프레임을 바꿀 때는 `walk-rows.json`에 지정한 파일을 수정한다.

## 회귀 시험

`work/tests`에 가족 규칙·도감 화면·프로필 전환 검사가 있다. 프로필 검사는 본체 리소스 폴더와 빌드한 도감 파일을 인수로 받는다. 백업·복원 검사는 `work/backup/checks/check.py --help`에서 입력을 확인한다. Python 검사기는 기본적으로 `texlua`를 사용하며 `FORMDAY_TEST_LUA`로 Lua 5.3 호환 실행기를 지정할 수 있다.
