"""Build the two merged packages in a new local review directory."""
import argparse
import hashlib
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from package_skin import unlock_engine

ROOT = Path(__file__).resolve().parents[1]
RESOURCES = ROOT / "DesktopSkin" / "@Resources"


def build(output):
    output = output.resolve()
    if output.exists() or output.is_relative_to(RESOURCES) or output.is_relative_to(ROOT / "AvatarUnlocks"):
        raise ValueError("Choose a new output directory outside the resource inputs.")
    catalog = unlock_engine()
    if len(catalog) > 1048576:
        raise ValueError("The catalog exceeds the installed updater's 1 MiB limit.")
    inventory = Path(__file__).with_name("buddy-files.txt").read_text(encoding="utf-8").splitlines()
    if not inventory or len(inventory) != len(set(inventory)):
        raise ValueError("Empty or duplicate Buddy release entries.")
    output.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=output.parent) as staging:
        review = Path(staging) / "review"
        review.mkdir()
        (review / "AvatarUnlocks-review.lua").write_bytes(catalog)
        with ZipFile(review / "FormdayBuddy-review.zip", "x") as archive:
            for name in inventory:
                source = (RESOURCES / name).resolve()
                if not source.is_relative_to(RESOURCES) or source.relative_to(RESOURCES).as_posix() != name:
                    raise ValueError(f"Invalid Buddy resource path: {name}")
                entry = ZipInfo(name, (2026, 11, 24, 0, 0, 0))
                entry.create_system = 3
                entry.external_attr = 0o100644 << 16
                archive.writestr(entry, source.read_bytes(), compress_type=ZIP_DEFLATED, compresslevel=9)
        with ZipFile(review / "FormdayBuddy-review.zip") as archive:
            if archive.testzip() or archive.namelist() != inventory:
                raise ValueError("Buddy package verification failed.")
        review.rename(output)
    for path in sorted(output.iterdir()):
        print(path.name, path.stat().st_size, hashlib.sha256(path.read_bytes()).hexdigest())


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="new directory for both unsigned review packages")
    build(parser.parse_args().output)
