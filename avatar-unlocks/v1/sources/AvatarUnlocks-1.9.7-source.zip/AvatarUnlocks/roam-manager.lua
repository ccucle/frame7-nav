-- Single roster policy; one existing Rainmeter process and one shared atlas.
local P={}
local root=SKIN:GetVariable("CURRENTPATH").."FormdayPokemon\\"
local prefix=SKIN:GetVariable("CURRENTCONFIG").."\\FormdayPokemon\\Slot"
local slots,atlas={},nil
local keys,generation={},0
local function write(path,body)
 local f=io.open(path,"wb"); if not f then return false end
 local ok=f:write(body); return f:close() and ok
end
local childScript=[===[-- Lightweight 10 Hz, bounded desktop movement.
local values,atlas,x,y,lastX,lastY,dx,dy,left,pause,distance,lastCrop,dir
local token,hovered,settle=nil,false,0
local privatePath
local dirs={{-1,0},{1,0},{0,1},{0,-1},{1,1},{-1,1},{1,-1},{-1,-1}}
local function var(n) return tonumber(SKIN:ReplaceVariables("#"..n.."#")) or 0 end
local function bounds()
 local l,t=var("WORKAREAX"),var("WORKAREAY")
 return l,t,math.max(l,l+var("WORKAREAWIDTH")-values[3]),math.max(t,t+var("WORKAREAHEIGHT")-values[4])
end
local function move(l,t,r,b)
 x,y=math.max(l,math.min(x,r)),math.max(t,math.min(y,b))
 local px,py=math.floor(x+0.5),math.floor(y+0.5)
 if px~=lastX or py~=lastY then SKIN:Bang("!Move",px,py);lastX,lastY=px,py end
end
local function paint(walking)
 local row,bx,by,w,h,d,g,strip,cycle=unpack(values,5,13)
 local n=walking and distance%cycle or 0
 local cx,cy
 if strip>=0 then
  local f=0
  while values[14+f] and n>=values[14+f] do f=f+1 end
  cx,cy=f*w*d,strip+(dir>0 and h*d or 0)
 else
  local f=math.floor(n/4)
  cx=math.floor(row/8)*128*g+(f*32+bx)*d
  cy=(row%8)*64*g+((dir>0 and 32 or 0)+by)*d
 end
 local crop=table.concat({cx,cy,w*d,h*d},",")
 if crop~=lastCrop then
  SKIN:Bang("!SetOption","Sprite","ImageCrop",crop); SKIN:Bang("!UpdateMeter","Sprite");lastCrop=crop
 end
end
function Hover(active)
 hovered=active==1
 if not hovered then settle=4 end
end
function RequestReturn()
 if not token then return end
 local f=io.open(privatePath.."return."..token..".txt","wb");if not f then return end
 f:write("return\n");f:close()
end
function Initialize()
 privatePath=SKIN:GetVariable("CURRENTPATH")
 local f=io.open(privatePath.."state.txt","rb");if not f then return end
 local line=f:read("*l");atlas=f:read("*l");local key=f:read("*l");f:close()
 if key and key:match("^[0-9][0-9%-]+$") then token=key end
 if not line or not atlas or not atlas:match("unlock%-walk%-%d+%.%d+%.%d+%.png$") then return end
 values={};for n in line:gmatch("[^,]+") do local v=tonumber(n);if not v then values=nil;return end;values[#values+1]=v end
 if #values<13 or values[3]<1 or values[4]<1 or values[13]<1 then values=nil;return end
 math.randomseed(os.time()+values[5]*79+values[2])
 x,y,dx,dy,left,pause,distance,dir=values[1],values[2],0,0,0,4+values[5]%11,0,1
 SKIN:Bang("!SetOption","Sprite","ImageName",atlas)
 SKIN:Bang("!SetOption","Sprite","W",values[3]);SKIN:Bang("!SetOption","Sprite","H",values[4])
 move(bounds());paint(false)
end
function Update()
 if not values then return 0 end
 local l,t,r,b=bounds()
 if token then
  local gx,gy=tonumber(SKIN:ReplaceVariables("#CURRENTCONFIGX#")),tonumber(SKIN:ReplaceVariables("#CURRENTCONFIGY#"))
  if gx and gy and (gx~=lastX or gy~=lastY) then
   x,y,lastX,lastY=gx,gy,gx,gy;settle=4
  end
  if hovered or settle>0 then
   if settle>0 then settle=settle-1 end
   paint(false);return 0
  end
 end
 if pause>0 then pause=pause-1;paint(false);return 0 end
 if left<=0 then
  local d=dirs[math.random(#dirs)]
  dx,dy=d[1],d[2];if dx~=0 then dir=dx end
  left=math.random(12,40)
 end
 local speed=1.6
 if dx~=0 and dy~=0 then speed=speed*0.7071 end
 local ox,oy=x,y;x,y=x+dx*speed,y+dy*speed
 move(l,t,r,b)
 distance=distance+math.abs(x-ox)+math.abs(y-oy)
 left=left-1
 if left<=0 or (x==ox and y==oy) then left=0;pause=math.random(5,16) end
 paint(left>0)
 return 0
end
]===]
local childSkin=string.char(239,187,191)..[===[[Rainmeter]
Update=100
DynamicWindowSize=1
ContextTitle=돌려보내기
ContextAction=[!CommandMeasure Motion "RequestReturn()"]
OnRefreshAction=[!ZPos -2][!ClickThrough 0][!Draggable 1][!KeepOnScreen 1][!SnapEdges 0]
[Motion]
Measure=Script
ScriptFile=#CURRENTPATH#..\roam.lua
[Sprite]
Meter=Image
DynamicVariables=1
MouseActionCursor=0
MouseOverAction=[!CommandMeasure Motion "Hover(1)"]
MouseLeaveAction=[!CommandMeasure Motion "Hover(0)"]
RightMouseUpAction=[!SkinCustomMenu]
]===]
local function changed(path,body)
 local f=io.open(path,"rb");if not f then return nil end
 local old=f:read("*a");f:close()
 if old==body then return true end
 if write(path,body) then return true end
 write(path,old)
 return false
end
local function get(name,default) return tonumber(SKIN:GetVariable(name)) or default end
function P.select(ids,sizes,cache,resources)
 ids=ids or {}
 if #ids>0 and not atlas then 
  atlas=M.imageFile(cache,"unlock-walk",M.walkAtlas,resources.."unlock-walk.png")
 end
 local policy=sizes.roam or {}
 local desired,assigned,wanted={},{},{}
 for _,id in ipairs(ids) do wanted[id]=true end
 for n=1,6 do
  local id=slots[n]
  if id and wanted[id] then desired[n]=id;assigned[id]=true end
 end
 for _,id in ipairs(ids) do
  if not assigned[id] then
   for n=1,6 do if not desired[n] then desired[n]=id;break end end
  end
 end
 for n=1,6 do
  local id=desired[n]
  if id~=slots[n] then
   local cfg=prefix..n
   local dir=root.."Slot"..n.."\\"
   if id then
    local row=M.walkRows[id]
    local box=row and M.walkCrops[row+1]
    if box then
     local tier=sizes.tiers[sizes.species[id] or "medium"]
     local k=tier.scale*box.referenceHeight/box.h
     local w,h=math.max(1,math.floor(box.w*k+0.5)),math.max(1,math.floor(box.h*k+0.5))
     local a=SKIN:GetMeter("Avatar")
     local x=get("CURRENTCONFIGX",300)+(a and a:GetX() or 0)
     local y=get("CURRENTCONFIGY",250)+(a and a:GetY()+a:GetH() or 100)
     local gap=policy.spawnGap or 18
     x=policy.spawnSide=="right" and x+(a and a:GetW() or 84)+gap or x-w-gap
     y=y-h+(n-1)*14
     local fields={math.floor(x+0.5),math.floor(y+0.5),w,h,row,box.x,box.y,box.w,box.h,box.density,M.walkDensity,box.stripY or -1,box.cycle or 16}
     for _,v in ipairs(box.ends or {}) do fields[#fields+1]=v end
     -- A single newline-free, numeric record with the signed engine's atlas path.
     local ready=changed(root.."roam.lua",childScript) and changed(dir.."Pokemon.ini",childSkin)
     generation=generation+1
     local key=string.format("%d-%d-%06d",os.time(),generation,math.random(0,999999))
     if ready and atlas and write(dir.."state.txt",table.concat(fields,",").."\n"..atlas.."\n"..key) then
      keys[n]=key
      SKIN:Bang("!DeactivateConfig",cfg)
      SKIN:Bang("!ActivateConfig",cfg,"Pokemon.ini")
      slots[n]=id
     end
    end
   else
    SKIN:Bang("!DeactivateConfig",cfg)
    slots[n],keys[n]=nil,nil
   end
  end
 end
end
function P.takeReturns()
 local ids={}
 for n=1,6 do
  if keys[n] and slots[n] then
   local path=root.."Slot"..n.."\\return."..keys[n]..".txt"
   local f=io.open(path,"rb")
   if f then
    local line=f:read("*l");f:close()
    if line=="return" and os.remove(path) then ids[#ids+1]=slots[n] end
   end
  end
 end
 return ids
end
function P.close()
 for n=1,6 do SKIN:Bang("!DeactivateConfig",prefix..n);slots[n],keys[n]=nil,nil end
end
return P
