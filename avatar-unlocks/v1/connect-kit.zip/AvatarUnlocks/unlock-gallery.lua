-- Native catalog view. Preview entries describe pictures; the engine owns reward eligibility.
local G={}
local kinds={"outfit","pet","pokemon"}
local tab, page, active=1,1,false
local positions={}
local compactGrid
local engine, extras, session, atlas
local bundled, cacheDir, bundledVersion
local rows, levels
local families, memberFamily = {}, {}
local sizes
local query, detail, results = "", nil, {}
local editorFile, editorRunning, focusPending, editorSequence
local editorInstance=tostring({}):gsub("[^%w]","")..os.time()
local panelX, panelY = 0, 0

local function dex(number)
    return string.format("#%04d",number)
end

local function sizeSuffix(id)
    local tier=sizes.tiers[sizes.species[id]]
    return tier and (" · "..tier.label) or ""
end

local function matches(item,needle)
    if needle=="" then return true end
    local number=needle:match("^#?(%d+)$")
    local function hit(id,name,no)
        if number then return tonumber(number)==no end
        return id:lower():find(needle,1,true) or name:lower():find(needle,1,true)
    end
    local family=families[memberFamily[item.id]]
    if not family then return hit(item.id,item.name or item.id,item.dex) end
    for _,member in ipairs(family) do
        if hit(member[2],member[3],member[1]) then return true end
    end
    return false
end

-- Lua passes strings to Rainmeter in the Windows code page. Character references
-- let the native meters render UTF-8 catalog labels on any system locale.
local function nativeText(value)
    return (value:gsub("[\128-\255][\128-\191]*",function(char)
        local a,b,c=char:byte(1,3)
        local code
        if #char==2 and a<224 then code=(a-192)*64+b-128
        elseif #char==3 and a<240 then code=((a-224)*64+b-128)*64+c-128 end
        return code and string.format("[\\x%04x]",code) or "?"
    end))
end

local function setting(meter, option, value)
    if option=="Text" or option=="ToolTipText" then value=nativeText(value) end
    SKIN:Bang("!SetOption",meter,option,tostring(value))
end

local function visible(name,yes)
    SKIN:Bang(yes and "!ShowMeter" or "!HideMeter",name)
end

local function catalogRows()
    rows={outfit={},pet={},pokemon={}}
    levels={}
    local indexed={}
    for _,item in ipairs(engine.gallery or {}) do
        if rows[item.kind] then
            table.insert(rows[item.kind],item)
            indexed[item.id]=true
        end
    end
    for _,list in ipairs({engine.catalog or {},extras}) do
        for _,item in ipairs(list) do
            if rows[item.kind] then
                levels[item.id]=item.level
                if not indexed[item.id] then
                    table.insert(rows[item.kind],item)
                    indexed[item.id]=true
                end
            end
        end
    end
    local roots={}
    for _,item in ipairs(rows.pokemon) do
        local root=memberFamily[item.id]
        if not root or item.id==root or not indexed[root] then roots[#roots+1]=item end
    end
    local function number(item)
        for _,member in ipairs(families[memberFamily[item.id]] or {}) do
            if member[2]==item.id then return member[1] end
        end
        return tonumber(item.dex) or math.huge
    end
    table.sort(roots,function(a,b)
        local left,right=number(a),number(b)
        if left==right then return a.id<b.id end
        return left<right
    end)
    rows.pokemon=roots
end

local function imagePath()
    if engine.version==bundledVersion or not engine.atlas then return bundled end
    local path=cacheDir.."unlock-gallery-"..engine.version..".png"
    local check=io.open(path,"rb")
    if check then check:close();return path end
    local temp=path.."."..tostring({}):gsub("[^a-zA-Z0-9]","")..".tmp"
    local f=io.open(temp,"wb")
    if not f then return bundled end
    local bytes=engine.atlas:gsub("%x%x",function(pair) return string.char(tonumber(pair,16)) end)
    local written=f:write(bytes)
    local closed=f:close()
    if written and closed and os.rename(temp,path) then return path end
    os.remove(temp)
    check=io.open(path,"rb")
    if check then check:close();return path end
    return bundled
end

local function rememberPositions()
    local names={"GalleryCard","GalleryBook","GalleryTitle","GalleryClose","GalleryCount","GalleryPrev",
                 "GalleryPageNumber","GalleryNext","GalleryUpdates","GallerySearchFrame","GallerySearch","GalleryClear","GalleryBack","GalleryEmpty"}
    for i=1,3 do
        names[#names+1]="GalleryTabBg"..i
        names[#names+1]="GalleryTabText"..i
    end
    for i=1,9 do
        names[#names+1]="GalleryEvolution"..i
        for _,prefix in ipairs({"GalleryCell","GalleryArt","GalleryLock","GalleryName"}) do
            names[#names+1]=prefix..i
        end
    end
    for _,name in ipairs(names) do
        local meter=SKIN:GetMeter(name)
        positions[name]={tonumber(meter:GetOption("X")) or 0,tonumber(meter:GetOption("Y")) or 0}
    end
end

local function place(x,y)
    for name,pos in pairs(positions) do
        setting(name,"X",x and x+pos[1] or 0)
        setting(name,"Y",y and y+pos[2] or 0)
    end
    compactGrid=nil
end

-- Reserve one row below the Pokémon grid without resizing the host window.
local function layoutGrid(compact)
    if compactGrid==compact then return end
    compactGrid=compact
    local size=compact and 56 or 64
    for n=1,9 do
        local cell="GalleryCell"..n
        local x=panelX+positions[cell][1]
        local y=panelY+positions[cell][2]-(compact and 12*math.floor((n-1)/3) or 0)
        setting(cell,"Y",y)
        local art="GalleryArt"..n
        setting(art,"X",x+(96-size)/2)
        setting(art,"Y",y+(compact and 3 or 5))
        setting(art,"W",size)
        setting(art,"H",size)
        setting("GalleryLock"..n,"Y",y+5)
        setting("GalleryName"..n,"Y",y+(compact and 63 or 73))
    end
end

local function cell(n,item,owned)
    local shape="Rectangle 0,0,96,"..(compactGrid and 86 or 96)..",2 | StrokeWidth 1 | "
    local colors=owned and "Fill Color 232,241,220 | Stroke Color 148,166,154"
                         or "Fill Color 229,228,218 | Stroke Color 172,175,163"
    local art,lock,name="GalleryArt"..n,"GalleryLock"..n,"GalleryName"..n
    setting("GalleryCell"..n,"Shape",shape..colors)
    visible("GalleryCell"..n,not detail and (item~=nil or tab~=3))
    local click=(tab==3 and item) and ('[!CommandMeasure AvatarUnlocks "GallerySelect('..n..')"]') or ""
    for _,meter in ipairs({"GalleryCell"..n,art,lock,name}) do
        setting(meter,"LeftMouseUpAction",click)
    end
    visible(art,item~=nil)
    visible(lock,item~=nil and not owned)
    visible(name,item~=nil)
    if not item then setting("GalleryCell"..n,"ToolTipText","");return end
    local crop="64,192,12,12"
    if type(item.icon)=="number" and item.icon>=0 then
        crop=string.format("%d,%d,64,64",item.icon%9*64,math.floor(item.icon/9)*64)
    end
    local label=item.name or item.id
    if tab==3 then
        for _,member in ipairs(families[memberFamily[item.id]] or {}) do
            if member[2]==item.id then label=dex(member[1]).." "..label;break end
        end
    end
    local hint=owned and "해금 완료" or (levels[item.id] and "필요 레벨 "..levels[item.id] or "해금 레벨 미정")
    if tab==3 then hint=hint..sizeSuffix(item.id) end
    setting(art,"ImageName",atlas)
    setting(art,"ImageCrop",crop)
    setting(art,"Greyscale",owned and 0 or 1)
    setting(art,"ImageAlpha",owned and 255 or 198)
    setting(name,"Text",label)
    for _,meter in ipairs({"GalleryCell"..n,art,lock,name}) do
        setting(meter,"ToolTipText",label.." · "..hint)
    end
end

function G.refresh()
    if not active then return end
    local entries={}
    for _,item in ipairs(rows[kinds[tab]]) do
        if tab~=3 or matches(item,query:lower()) then entries[#entries+1]=item end
    end
    results=entries
    local family=detail and (families[memberFamily[detail.id]] or {}) or {}
    local parents={}
    for _,member in ipairs(family) do parents[member[1]]=member[3] end
    local pages=math.max(1,math.ceil(#entries/9))
    page=math.max(1,math.min(page,pages))
    local owned,count={},0
    for _,item in ipairs(entries) do
        if session and session:owns(item.id) then owned[item.id]=true;count=count+1 end
    end
    local showSearch=tab==3 and not detail
    layoutGrid(showSearch)
    for i=1,3 do setting("GalleryTabBg"..i,"SolidColor",i==tab and "185,224,190" or "224,226,211") end
    for n=1,9 do
        local item=entries[(page-1)*9+n]
        cell(n,not detail and item or nil,item and owned[item.id])
        local member=family[n]
        visible("GalleryEvolution"..n,member~=nil)
        if member then
            local from=member[4] and ("    "..parents[member[4]].." → ") or ""
            setting("GalleryEvolution"..n,"Text",from..dex(member[1]).." "..member[3]..sizeSuffix(member[2]))
        end
    end
    visible("GallerySearchFrame",showSearch)
    visible("GallerySearch",showSearch)
    visible("GalleryClear",showSearch and query~="")
    visible("GalleryBack",detail~=nil)
    visible("GalleryEmpty",tab==3 and ((not detail and #entries==0) or (detail and #family==0)))
    setting("GalleryEmpty","Text",detail and "등록된 진화 정보가 없어요" or "검색 결과가 없어요")
    local caption=query=="" and "포켓몬 이름 또는 도감 번호" or query
    -- The query is display text, never a Rainmeter variable or action.
    caption=caption:gsub("[#%[%]]",function(c) return string.format("[\\x%04x]",c:byte()) end)
    setting("GallerySearch","Text",caption)
    setting("GalleryTitle","Text",detail and (detail.name or detail.id) or "해금 도감")
    setting("GalleryCount","Text",detail and "진화 계열" or "해금 "..count.." / "..#entries)
    setting("GalleryPageNumber","Text",page.." / "..pages)
    visible("GalleryPageNumber",not detail and pages>1)
    visible("GalleryPrev",not detail and page>1)
    visible("GalleryNext",not detail and page<pages)
    SKIN:Bang("!UpdateMeterGroup","UnlockGallery")
    SKIN:Bang("!Redraw")
end

function G.init(resources,path,version,pokedex,pokemonSizes)
    bundled,cacheDir,bundledVersion=resources.."unlock-gallery.png",path,version
    families=pokedex
    sizes=pokemonSizes
    for root,family in pairs(families) do
        for _,member in ipairs(family) do memberFamily[member[2]]=root end
    end
end

function G.prepare()
    if next(positions) then return end
    rememberPositions()
    place()
    SKIN:Bang("!UpdateMeterGroup","UnlockGallery")
end

function G.bind(module,localItems,profile)
    if engine~=module or extras~=localItems then
        engine,extras=module,localItems
        catalogRows()
        atlas=nil
    end
    session=profile
    if active then atlas=atlas or imagePath();G.refresh() end
end

local function stopEditing()
    focusPending=false
    if editorFile then
        os.remove(editorFile)
        editorFile=nil
        SKIN:Bang("!DisableMeasure","GallerySearchWatch")
    end
end

function G.open(x,y)
    local opening=not active
    G.prepare()
    panelX,panelY=x,y
    if not active then place(x,y) end
    active=true
    atlas=atlas or imagePath()
    SKIN:Bang("!ShowMeterGroup","UnlockGallery")
    G.refresh()
    if opening and tab==3 then G.edit() end
end

function G.hide()
    if not active then return end
    active=false
    detail=nil
    stopEditing()
    SKIN:Bang("!HideMeterGroup","UnlockGallery")
    place()
    SKIN:Bang("!UpdateMeterGroup","UnlockGallery")
end

function G.tab(index)
    if not active or not kinds[index] then return end
    if tab~=index or detail then stopEditing() end
    tab,page,detail=index,1,nil
    G.refresh()
    if tab==3 then G.edit() end
end

function G.page(delta)
    if active and not detail and (delta==1 or delta==-1) then page=page+delta;G.refresh() end
end

function G.select(slot)
    if not active or tab~=3 or detail then return end
    detail=results[(page-1)*9+slot]
    if detail then stopEditing();G.refresh() end
end

function G.back()
    detail=nil
    G.refresh()
end

function G.search(text)
    if not active or tab~=3 or detail then return end
    local value=text:match("^%s*(.-)%s*$")
    if value==query then return end
    query,page=value,1
    G.refresh()
end

function G.clear()
    stopEditing()
    G.search("")
end

function G.edit()
    if not active or tab~=3 or detail or editorFile then return end
    if editorRunning then focusPending=true;return end
    editorSequence=(editorSequence or 0)+1
    local token=editorInstance.."_"..editorSequence
    local path=os.getenv("TEMP").."\\FormdaySearch-"..token..".txt"
    local file=io.open(path,"wb")
    if not file then return end
    file:close()
    editorFile,editorRunning=path,true
    SKIN:Bang("!SetVariable","GallerySearchToken",token)
    local pos=positions.GallerySearch
    local x=tonumber(SKIN:GetVariable("CURRENTCONFIGX")) or 0
    local y=tonumber(SKIN:GetVariable("CURRENTCONFIGY")) or 0
    SKIN:Bang("!SetVariable","GallerySearchX",x+panelX+pos[1])
    SKIN:Bang("!SetVariable","GallerySearchY",y+panelY+pos[2])
    SKIN:Bang("!SetVariable","GallerySearchWidth",SKIN:GetMeter("GallerySearch"):GetW())
    local hex=query:gsub(".",function(c) return string.format("%02X",c:byte()) end)
    SKIN:Bang("!SetVariable","GallerySearchSeed",hex)
    SKIN:Bang("!UpdateMeasure","GallerySearchEditor")
    SKIN:Bang("!CommandMeasure","GallerySearchEditor","Run")
    SKIN:Bang("!EnableMeasure","GallerySearchWatch")
end

local function applyHex(hex)
    if hex and #hex%2==0 and #hex<=384 then
        G.search((hex:gsub("%x%x",function(b) return string.char(tonumber(b,16)) end)))
    end
end

function G.tick()
    if not editorFile then return end
    local file=io.open(editorFile,"rb")
    if not file then return end
    local record=file:read(393)
    file:close()
    if record then applyHex(record:match("^QUERY:(%x*)|$")) end
end

function G.edited(output)
    local reopen=focusPending
    if editorFile then applyHex(output:match("^%s*QUERY:(%x*)%s*$")) end
    stopEditing()
    editorRunning=false
    if reopen then G.edit() end
end

return G
