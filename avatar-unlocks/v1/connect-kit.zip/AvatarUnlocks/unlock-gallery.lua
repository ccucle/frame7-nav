-- Native catalog view. Preview entries describe pictures; the engine owns reward eligibility.
local G={}
local kinds={"outfit","pet","pokemon"}
local tab, page, active=1,1,false
local positions={}
local engine, extras, session, atlas
local bundled, cacheDir, bundledVersion
local rows, levels

-- Lua passes strings to Rainmeter in the Windows code page. Character references
-- let the native meters render UTF-8 catalog labels on any system locale.
local function nativeText(value)
    return (value:gsub("[\128-\255][\128-\191]*",function(char)
        local a,b,c=char:byte(1,3)
        local code
        if #char==2 and a<224 then code=(a-192)*64+b-128
        elseif #char==3 and a<240 then code=((a-224)*64+b-128)*64+c-128 end
        return code and string.format("[\\x%04x]",code) or "?"
    end))
end

local function setting(meter, option, value)
    if option=="Text" or option=="ToolTipText" then value=nativeText(value) end
    SKIN:Bang("!SetOption",meter,option,tostring(value))
end

local function visible(name,yes)
    SKIN:Bang(yes and "!ShowMeter" or "!HideMeter",name)
end

local function catalogRows()
    rows={outfit={},pet={},pokemon={}}
    levels={}
    local indexed={}
    for _,item in ipairs(engine.gallery or {}) do
        if rows[item.kind] then
            table.insert(rows[item.kind],item)
            indexed[item.id]=true
        end
    end
    for _,list in ipairs({engine.catalog or {},extras}) do
        for _,item in ipairs(list) do
            if rows[item.kind] then
                levels[item.id]=item.level
                if not indexed[item.id] then
                    table.insert(rows[item.kind],item)
                    indexed[item.id]=true
                end
            end
        end
    end
end

local function imagePath()
    if engine.version==bundledVersion or not engine.atlas then return bundled end
    local path=cacheDir.."unlock-gallery-"..engine.version..".png"
    local check=io.open(path,"rb")
    if check then check:close();return path end
    local temp=path.."."..tostring({}):gsub("[^a-zA-Z0-9]","")..".tmp"
    local f=io.open(temp,"wb")
    if not f then return bundled end
    local bytes=engine.atlas:gsub("%x%x",function(pair) return string.char(tonumber(pair,16)) end)
    local written=f:write(bytes)
    local closed=f:close()
    if written and closed and os.rename(temp,path) then return path end
    os.remove(temp)
    check=io.open(path,"rb")
    if check then check:close();return path end
    return bundled
end

local function rememberPositions()
    local names={"GalleryCard","GalleryBook","GalleryTitle","GalleryClose","GalleryCount","GalleryPrev",
                 "GalleryPageNumber","GalleryNext","GalleryUpdates"}
    for i=1,3 do
        names[#names+1]="GalleryTabBg"..i
        names[#names+1]="GalleryTabText"..i
    end
    for i=1,9 do
        for _,prefix in ipairs({"GalleryCell","GalleryArt","GalleryLock","GalleryName"}) do
            names[#names+1]=prefix..i
        end
    end
    for _,name in ipairs(names) do
        local meter=SKIN:GetMeter(name)
        positions[name]={tonumber(meter:GetOption("X")) or 0,tonumber(meter:GetOption("Y")) or 0}
    end
end

local function place(x,y)
    for name,pos in pairs(positions) do
        setting(name,"X",x and x+pos[1] or 0)
        setting(name,"Y",y and y+pos[2] or 0)
    end
end

local function cell(n,item,owned)
    local shape="Rectangle 0,0,96,96,2 | StrokeWidth 1 | "
    local colors=owned and "Fill Color 232,241,220 | Stroke Color 148,166,154"
                         or "Fill Color 229,228,218 | Stroke Color 172,175,163"
    local art,lock,name="GalleryArt"..n,"GalleryLock"..n,"GalleryName"..n
    setting("GalleryCell"..n,"Shape",shape..colors)
    visible(art,item~=nil)
    visible(lock,item~=nil and not owned)
    visible(name,item~=nil)
    if not item then setting("GalleryCell"..n,"ToolTipText","");return end
    local crop="64,192,12,12"
    if type(item.icon)=="number" and item.icon>=0 then
        crop=string.format("%d,%d,64,64",item.icon%9*64,math.floor(item.icon/9)*64)
    end
    local label=item.name or item.id
    local hint=owned and "해금 완료" or (levels[item.id] and "필요 레벨 "..levels[item.id] or "해금 레벨 미정")
    setting(art,"ImageName",atlas)
    setting(art,"ImageCrop",crop)
    setting(art,"Greyscale",owned and 0 or 1)
    setting(art,"ImageAlpha",owned and 255 or 198)
    setting(name,"Text",label)
    for _,meter in ipairs({"GalleryCell"..n,art,lock,name}) do
        setting(meter,"ToolTipText",label.." · "..hint)
    end
end

function G.refresh()
    if not active then return end
    local entries=rows[kinds[tab]]
    local pages=math.max(1,math.ceil(#entries/9))
    page=math.max(1,math.min(page,pages))
    local owned,count={},0
    for _,item in ipairs(entries) do
        if session and session:owns(item.id) then owned[item.id]=true;count=count+1 end
    end
    for i=1,3 do setting("GalleryTabBg"..i,"SolidColor",i==tab and "185,224,190" or "224,226,211") end
    for n=1,9 do
        local item=entries[(page-1)*9+n]
        cell(n,item,item and owned[item.id])
    end
    setting("GalleryCount","Text","해금 "..count.." / "..#entries)
    setting("GalleryPageNumber","Text",page.." / "..pages)
    visible("GalleryPageNumber",pages>1)
    visible("GalleryPrev",page>1)
    visible("GalleryNext",page<pages)
    SKIN:Bang("!UpdateMeterGroup","UnlockGallery")
    SKIN:Bang("!Redraw")
end

function G.init(resources,path,version)
    bundled,cacheDir,bundledVersion=resources.."unlock-gallery.png",path,version
end

function G.prepare()
    if next(positions) then return end
    rememberPositions()
    place()
    SKIN:Bang("!UpdateMeterGroup","UnlockGallery")
end

function G.bind(module,localItems,profile)
    if engine~=module or extras~=localItems then
        engine,extras=module,localItems
        catalogRows()
        atlas=nil
    end
    session=profile
    if active then atlas=atlas or imagePath();G.refresh() end
end

function G.open(x,y)
    G.prepare()
    if not active then place(x,y) end
    active=true
    atlas=atlas or imagePath()
    SKIN:Bang("!ShowMeterGroup","UnlockGallery")
    G.refresh()
end

function G.hide()
    if not active then return end
    active=false
    SKIN:Bang("!HideMeterGroup","UnlockGallery")
    place()
    SKIN:Bang("!UpdateMeterGroup","UnlockGallery")
end

function G.tab(index)
    if active and kinds[index] then tab,page=index,1;G.refresh() end
end

function G.page(delta)
    if active and (delta==1 or delta==-1) then page=page+delta;G.refresh() end
end

return G
