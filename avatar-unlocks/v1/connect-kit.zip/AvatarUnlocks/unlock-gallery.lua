-- Native catalog view. Preview entries describe pictures; the engine owns reward eligibility.
local G={}
local kinds={"outfit","pet","pokemon"}
local tab, page, active=1,1,false
local positions={}
local layoutPositions
local compactGrid
local engine, extras, session, atlas
local bundled, cacheDir
local rows, levels
local families, memberFamily, species = {}, {}, {}
local sizes,picked
local query, detail, results = "", nil, {}
local editorFile, editorRunning, focusPending, editorSequence
local focusEpoch=0
local request,retryAction
local editorInstance=tostring({}):gsub("[^%w]","")..os.time()
local panelX, panelY = 0, 0

local function dex(number)
    return string.format("#%04d",number)
end

local function sizeSuffix(id)
    local tier=sizes.tiers[sizes.species[id]]
    return tier and (" · "..tier.label) or ""
end

local function matches(item,needle)
    if needle=="" then return true end
    local number=needle:match("^#?(%d+)$")
    if number then return tonumber(number)==item.dex end
    return item.id:lower():find(needle,1,true) or (item.name or item.id):lower():find(needle,1,true)
end

-- Lua passes strings to Rainmeter in the Windows code page. Character references
-- let the native meters render UTF-8 catalog labels on any system locale.
local function nativeText(value)
    return (value:gsub("[\128-\255][\128-\191]*",function(char)
        local a,b,c=char:byte(1,3)
        local code
        if #char==2 and a<224 then code=(a-192)*64+b-128
        elseif #char==3 and a<240 then code=((a-224)*64+b-128)*64+c-128 end
        return code and string.format("[\\x%04x]",code) or "?"
    end))
end

local function setting(meter, option, value)
    if option=="Text" or option=="ToolTipText" then value=nativeText(value) end
    SKIN:Bang("!SetOption",meter,option,tostring(value))
end

local function visible(name,yes)
    SKIN:Bang(yes and "!ShowMeter" or "!HideMeter",name)
end

-- Pixel button backgrounds are painted on existing Shape meters so older hosts
-- receive the same controls through a catalog-only update.
local palette={
    idle={"66,83,75","231,229,203","253,249,223"},
    selected={"43,78,66","161,211,174","211,238,197"},
    action={"95,68,37","246,196,113","255,226,162"},
    dark={"24,44,46","70,103,99","96,137,127"},
    muted={"152,158,141","219,220,205","234,234,220"},
    owned={"82,115,89","225,237,211","247,248,222"},
    locked={"141,152,138","230,229,217","247,244,228"}
}
local painted={}
local function paint(meter,first,x,y,w,h,style)
    local key=meter..":"..first
    local signature=table.concat({x,y,w,h,style or "none"},",")
    if painted[key]==signature then return end
    painted[key]=signature
    local function shape(i,value)
        local n=first+i
        setting(meter,n==1 and "Shape" or "Shape"..n,value)
    end
    if not style then
        for i=0,2 do shape(i,"Rectangle 0,0,0,0 | StrokeWidth 0") end
        return
    end
    local colors=palette[style]
    local function stepped(i,dx,dy,ww,hh,corner,color)
        local left,top=x+dx,y+dy
        local right,bottom=left+ww,top+hh
        local p=string.format("%d,%d",left+corner,top)
        for _,point in ipairs({{right-corner,top},{right-corner,top+corner},{right,top+corner},
            {right,bottom-corner},{right-corner,bottom-corner},{right-corner,bottom},
            {left+corner,bottom},{left+corner,bottom-corner},{left,bottom-corner},
            {left,top+corner},{left+corner,top+corner}}) do
            p=p..string.format(" | LineTo %d,%d",point[1],point[2])
        end
        local name="PixelPath"..(first+i)
        setting(meter,name,p.." | ClosePath 1")
        shape(i,"Path "..name.." | StrokeWidth 0 | Fill Color "..color)
    end
    stepped(0,0,0,w,h,3,colors[1])
    stepped(1,1,1,w-2,h-4,2,colors[2])
    shape(2,string.format("Rectangle %d,%d,%d,1 | StrokeWidth 0 | Fill Color %s",x+4,y+2,w-8,colors[3]))
end

local buttonLayout={
    {"GalleryBack",155,9,72,25},{"GalleryClose",270,9,46,25},
    {"GalleryPrev",105,415,29,25},{"GalleryPageNumber",137,415,62,25},
    {"GalleryNext",202,415,29,25},{"GalleryUpdates",237,415,79,25}
}
local function placeButtons()
    for _,b in ipairs(buttonLayout) do
        local name,x,y,w,h=unpack(b)
        setting(name,"X",panelX+x+math.floor(w/2))
        setting(name,"Y",panelY+y)
        setting(name,"W",w)
        setting(name,"H",h-4)
        setting(name,"Padding","0,4,0,0")
        setting(name,"StringAlign","Center")
        setting(name,"FontSize",9)
        setting(name,"SolidColor","0,0,0,1")
        setting(name,"FontColor",y<40 and "255,250,225" or "44,61,53")
    end
end
local function drawButtons(isDetail,pageNumber,pageCount,follow,canEvolve,hasRule)
    for i=1,3 do
        paint("GalleryCard",4+(i-1)*3,13+(i-1)*103,54,96,30,i==tab and "selected" or "idle")
        setting("GalleryTabBg"..i,"SolidColor","0,0,0,1")
    end
    local styles={isDetail and "dark","dark",not isDetail and pageNumber>1 and "idle",
        isDetail and (follow and "selected" or hasRule and (canEvolve and "action" or "muted"))
            or not isDetail and pageCount>1 and "idle",
        not isDetail and pageNumber<pageCount and "idle","idle"}
    for i,b in ipairs(buttonLayout) do
        paint("GalleryCard",13+(i-1)*3,b[2],b[3],b[4],b[5],styles[i])
    end
end


local function catalogRows()
    rows={outfit={},pet={},pokemon={}}
    levels={}
    local indexed={}
    for _,item in ipairs(engine.gallery or {}) do
        if rows[item.kind] then
            table.insert(rows[item.kind],item)
            indexed[item.id]=true
        end
    end
    for _,list in ipairs({engine.catalog or {},extras}) do
        for _,item in ipairs(list) do
            if rows[item.kind] then
                levels[item.id]=item.level
                if not indexed[item.id] then
                    table.insert(rows[item.kind],item)
                    indexed[item.id]=true
                end
            end
        end
    end
    for i,item in ipairs(rows.pokemon) do
        local mon=species[item.id]
        rows.pokemon[i]={id=item.id,kind="pokemon",name=mon and mon[3] or item.name,
                         dex=mon and mon[1] or tonumber(item.dex),icon=item.icon}
    end
    table.sort(rows.pokemon,function(a,b)
        local left,right=a.dex or math.huge,b.dex or math.huge
        if left==right then return a.id<b.id end
        return left<right
    end)
end

local function imagePath()
    return engine.imageFile(cacheDir,"unlock-gallery",engine.atlas,bundled)
end

local function place(x,y)
    for name,pos in pairs(positions) do
        setting(name,"X",x and x+pos[1] or 0)
        setting(name,"Y",y and y+pos[2] or 0)
    end
    compactGrid=nil
end

-- Reserve one row below the Pokémon grid without resizing the host window.
local function layoutGrid(compact)
    if compactGrid==compact then return end
    compactGrid=compact
    local size=compact and 46 or 64
    for n=1,9 do
        local cell="GalleryCell"..n
        local x=panelX+positions[cell][1]
        local y=panelY+positions[cell][2]-(compact and 12*math.floor((n-1)/3) or 0)
        setting(cell,"Y",y)
        local art="GalleryArt"..n
        setting(art,"X",x+(96-size)/2)
        setting(art,"Y",y+(compact and 3 or 5))
        setting(art,"W",size)
        setting(art,"H",size)
        setting("GalleryName"..n,"H",compact and 34 or 20)
        setting("GalleryLock"..n,"Y",y+5)
        setting("GalleryName"..n,"Y",y+(compact and 49 or 73))
    end
end

local function cell(n,item,owned)
    paint("GalleryCell"..n,1,0,0,96,compactGrid and 86 or 96,owned and "owned" or "locked")
    local art,lock,name="GalleryArt"..n,"GalleryLock"..n,"GalleryName"..n
    visible("GalleryCell"..n,not detail and (item~=nil or tab~=3))
    local click=(tab==3 and item) and ('[!CommandMeasure AvatarUnlocks "GallerySelect('..n..')"]') or ""
    for _,meter in ipairs({"GalleryCell"..n,art,lock,name}) do
        setting(meter,"LeftMouseUpAction",click)
    end
    visible(art,item~=nil)
    visible(lock,item~=nil and not owned)
    visible(name,item~=nil)
    if not item then setting("GalleryCell"..n,"ToolTipText","");return end
    local crop="64,192,12,12"
    if type(item.icon)=="number" and item.icon>=0 then
        crop=string.format("%d,%d,64,64",item.icon%9*64,math.floor(item.icon/9)*64)
    end
    local label=item.name or item.id
    local caption=label
    if tab==3 and item.dex then
        caption=dex(item.dex).."[\\x000a]"..label
        label=dex(item.dex).." "..label
    end
    local rule=tab==3 and engine.evolutions[item.id]
    local hint=owned and "해금 완료" or (rule and (engine.stoneNames[rule.stone].." ×"..rule.cost) or
               (levels[item.id] and "필요 레벨 "..levels[item.id] or "해금 레벨 미정"))
    if tab==3 then hint=hint..sizeSuffix(item.id) end
    setting(art,"ImageName",atlas)
    setting(art,"ImageCrop",crop)
    setting(art,"Greyscale",owned and 0 or 1)
    setting(art,"ImageAlpha",owned and 255 or 198)
    setting(name,"Text",caption)
    for _,meter in ipairs({"GalleryCell"..n,art,lock,name}) do
        setting(meter,"ToolTipText",label.." · "..hint)
    end
end

function G.refresh()
    if not active then return end
    local entries={}
    for _,item in ipairs(rows[kinds[tab]]) do
        if tab~=3 or matches(item,query:lower()) then entries[#entries+1]=item end
    end
    results=entries
    local family=detail and (families[memberFamily[detail.id]] or {}) or {}
    local parents={}
    for _,member in ipairs(family) do parents[member[1]]=member[3] end
    local pages=math.max(1,math.ceil(#entries/9))
    page=math.max(1,math.min(page,pages))
    local owned,count={},0
    for _,item in ipairs(entries) do
        if session and session:owns(item.id) then owned[item.id]=true;count=count+1 end
    end
    local showSearch=tab==3 and not detail
    layoutGrid(showSearch)
    for n=1,9 do
        local item=entries[(page-1)*9+n]
        cell(n,not detail and item or nil,item and owned[item.id])
        local member=family[n]
        visible("GalleryEvolution"..n,member~=nil)
        if member then
            local id=member[2]
            local row="GalleryEvolution"..n
            local rule=engine.evolutions[id]
            local owned=session and session:owns(id)
            local status=owned and "보유" or (rule and engine.stoneNames[rule.stone].." ×"..rule.cost or "미해금")
            setting(row,"Text",dex(member[1]).." "..member[3].."   "..status)
            setting(row,"ToolTipText",(member[4] and parents[member[4]].." → " or "")..member[3]..sizeSuffix(id))
            setting(row,"SolidColor",picked==id and "185,224,190" or "0,0,0,1")
            setting(row,"W",286)
            setting(row,"LeftMouseUpAction",'[!CommandMeasure AvatarUnlocks "GalleryMember('..n..')"]')
        end
    end
    visible("GallerySearchFrame",showSearch)
    visible("GallerySearch",showSearch)
    visible("GalleryClear",showSearch and query~="")
    visible("GalleryBack",detail~=nil)
    visible("GalleryEmpty",tab==3 and ((not detail and #entries==0) or (detail and #family==0)))
    setting("GalleryEmpty","Text",detail and "등록된 진화 정보가 없어요" or "검색 결과가 없어요")
    local caption=query=="" and "포켓몬 이름 또는 도감 번호" or query
    -- The query is display text, never a Rainmeter variable or action.
    caption=caption:gsub("[#%[%]]",function(c) return string.format("[\\x%04x]",c:byte()) end)
    setting("GallerySearch","Text",caption)
    setting("GalleryTitle","Text",detail and (species[picked] and species[picked][3] or detail.name or detail.id) or "해금 도감")
    local rule=picked and engine.evolutions[picked]
    local owns=session and picked and session:owns(picked)
    local hint="진화 계열"
    local evolve=false
    if rule and not owns then
        local held=session and session.wallet.stones[rule.stone] or 0
        local parent=session and session:owns(rule.parent)
        hint=parent and (engine.stoneNames[rule.stone].." "..held.." / "..rule.cost) or "이전 포켓몬 필요"
        evolve=parent and held>=rule.cost and not session.wallet.error
    end
    setting("GalleryCount","Text",detail and hint or "해금 "..count.." / "..#entries)
    local canFollow=detail and picked and engine.walkRows[picked] and owns
    local followLabel=canFollow and (session:selected("pokemon")==picked and "돌려보내기" or "꺼내기")
    setting("GalleryPageNumber","Text",followLabel or (rule and not owns and "진화") or (page.." / "..pages))
    setting("GalleryPageNumber","LeftMouseUpAction",canFollow and "[!CommandMeasure AvatarUnlocks GalleryCompanion()]" or evolve and "[!CommandMeasure AvatarUnlocks GalleryEvolve()]" or "")
    drawButtons(detail~=nil,page,pages,canFollow,evolve,rule~=nil)
    visible("GalleryPageNumber",canFollow or (detail and rule~=nil) or (not detail and pages>1))
    visible("GalleryPrev",not detail and page>1)
    visible("GalleryNext",not detail and page<pages)
    SKIN:Bang("!UpdateMeterGroup","UnlockGallery")
    SKIN:Bang("!Redraw")
end

function G.init(resources,path,pokedex,pokemonSizes,coordinates)
    layoutPositions=coordinates
    bundled,cacheDir=resources.."unlock-gallery.png",path
    families=pokedex
    sizes=pokemonSizes
    for root,family in pairs(families) do
        for _,member in ipairs(family) do
            memberFamily[member[2]]=root
            species[member[2]]=member
        end
    end
end

function G.prepare()
    if next(positions) then return end
    positions=layoutPositions
    place()
    SKIN:Bang("!UpdateMeterGroup","UnlockGallery")
end

function G.bind(module,localItems,profile)
    if engine~=module or extras~=localItems then
        engine,extras=module,localItems
        catalogRows()
        atlas=nil
    end
    session=profile
    if active then atlas=atlas or imagePath();G.refresh() end
end

local function stopEditing()
    focusPending,retryAction=false,nil
    if editorFile then
        os.remove(editorFile)
        os.remove(editorFile..".focus")
        editorFile=nil
        SKIN:Bang("!DisableMeasure","GallerySearchWatch")
    end
end

function G.open(x,y)
    G.prepare()
    panelX,panelY=x,y
    if not active then place(x,y);placeButtons() end
    active=true
    atlas=atlas or imagePath()
    SKIN:Bang("!ShowMeterGroup","UnlockGallery")
    G.refresh()
end

function G.hide()
    if not active then return end
    active=false
    detail,picked=nil,nil
    query,page="",1
    stopEditing()
    SKIN:Bang("!HideMeterGroup","UnlockGallery")
    place()
    SKIN:Bang("!UpdateMeterGroup","UnlockGallery")
end

function G.tab(index)
    if not active or not kinds[index] then return end
    stopEditing()
    tab,page,detail,picked,query=index,1,nil,nil,""
    G.refresh()
end

function G.page(delta)
    if active and not detail and (delta==1 or delta==-1) then page=page+delta;G.refresh() end
end

function G.select(slot)
    if not active or tab~=3 or detail then return end
    detail=results[(page-1)*9+slot]
    if detail then picked=detail.id;if editorFile then request("HIDE") end;G.refresh() end
end

function G.back()
    detail,picked=nil,nil
    G.refresh()
end

function G.member(slot)
    if not active or not detail then return end
    local member=(families[memberFamily[detail.id]] or {})[slot]
    if member then picked=member[2];G.refresh() end
end

function G.evolve()
    if active and detail and session and picked then session:evolve(picked);G.refresh() end
end

function G.toggleCompanion()
    if not active or not detail or not session or not picked or not engine.walkRows[picked] or not session:owns(picked) then return end
    local id=picked
    if session:selected("pokemon")==id then id=nil end
    Choose("pokemon",id)
    ClosePanel()
end

function G.search(text)
    if not active or tab~=3 or detail then return end
    local value=text:match("^%s*(.-)%s*$")
    if value==query then return end
    query,page=value,1
    G.refresh()
end

request=function(action)
    local pos=positions.GallerySearch
    local x=(tonumber(SKIN:GetVariable("CURRENTCONFIGX")) or 0)+panelX+pos[1]
    local y=(tonumber(SKIN:GetVariable("CURRENTCONFIGY")) or 0)+panelY+pos[2]
    local width=math.max(10,SKIN:GetMeter("GallerySearch"):GetW())
    local file=io.open(editorFile..".focus","wb")
    if not file then retryAction=action;return false end
    local nextEpoch=focusEpoch+1
    local written=file:write(string.format("%d %s %d %d %d|",nextEpoch,action,x,y,width))
    local closed=file:close()
    if written and closed then focusEpoch,retryAction=nextEpoch,nil;return true end
    retryAction=action
    return false
end

function G.clear()
    G.search("")
    if editorFile then request("CLEAR") end
end

function G.edit()
    if not active or tab~=3 or detail then return end
    if editorFile then request("FOCUS");return end
    if editorRunning then focusPending=true;return end
    editorSequence=(editorSequence or 0)+1
    local token=editorInstance.."_"..editorSequence
    local path=os.getenv("TEMP").."\\FormdaySearch-"..token..".txt"
    local file=io.open(path,"wb")
    if not file then return end
    file:close()
    editorFile,editorRunning,focusEpoch=path,token,0
    request("FOCUS")
    local hex=query:gsub(".",function(c) return string.format("%02X",c:byte()) end)
    -- Installed hosts carry an older editor in their INI. Launch the editor
    -- signed with the active engine, using only a generated token and hex seed.
    local parameter=[=[-NoLogo -NoProfile -STA -Command "$token=']=]..token..[=[';$seed=']=]..hex..[=[';& ([ScriptBlock]::Create([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String(']=]..engine.searchScript..[=['))))"]=]
    SKIN:Bang("!SetVariable","GallerySearchToken",token)
    SKIN:Bang("!SetOption","GallerySearchEditor","Parameter",parameter)
    SKIN:Bang("!UpdateMeasure","GallerySearchEditor")
    SKIN:Bang("!CommandMeasure","GallerySearchEditor","Run")
    SKIN:Bang("!EnableMeasure","GallerySearchWatch")
end

function G.tick()
    if not editorFile then return end
    if retryAction and not request(retryAction) then return end
    if detail then return end
    local file=io.open(editorFile,"rb")
    if not file then return end
    local record=file:read(420)
    file:close()
    if not record then return end
    local epoch,hex=record:match("^QUERY:(%d+):(%x*)|$")
    if tonumber(epoch)==focusEpoch and #hex%2==0 and #hex<=384 then
        G.search((hex:gsub("%x%x",function(b) return string.char(tonumber(b,16)) end)))
    end
end

function G.edited(output)
    local token=output:match("CLOSED ([%w_]+)")
    if token and token~=editorRunning then return end
    local reopen=focusPending
    stopEditing()
    editorRunning=nil
    if reopen then G.edit() end
end

function G.shutdown() stopEditing() end

return G
