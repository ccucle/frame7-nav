-- Rainmeter binding for the independently versioned avatar-unlocks/v1 channel.
local engine, resources, shared, catalog, session, lastLevel
local nextPoll, running, panelOpen, updateCode = 0, false, false, 1
local currentProfile, currentAvatar
local panelPositioned=false

local function var(name, value) SKIN:Bang("!SetVariable",name,tostring(value)) end
local function option(name, fallback)
    local value=SKIN:GetVariable(name)
    if value==nil or value=="" then return fallback end
    return value
end
local function validVersion(v) return v and #v<=14 and v:match("^%d+%.%d+%.%d+$") end
local function newer(a,b)
    local ar,as,at=a:match("^(%d+)%.(%d+)%.(%d+)$")
    local br,bs,bt=b:match("^(%d+)%.(%d+)%.(%d+)$")
    if tonumber(ar)~=tonumber(br) then return tonumber(ar)>tonumber(br) end
    if tonumber(as)~=tonumber(bs) then return tonumber(as)>tonumber(bs) end
    return tonumber(at)>tonumber(bt)
end

local function display(code)
    updateCode=code
    var("UnlockUpdateCode",code)
    SKIN:Bang(code==2 and not panelOpen and "!ShowMeterGroup" or "!HideMeterGroup","UnlockUpdateBubble")
    SKIN:Bang(panelOpen and code==2 and "!ShowMeterGroup" or "!HideMeterGroup","UnlockInstall")
    SKIN:Bang(panelOpen and code==3 and "!ShowMeterGroup" or "!HideMeterGroup","UnlockRetry")
    SKIN:Bang("!UpdateMeterGroup","UnlockPanel")
    SKIN:Bang("!Redraw")
end

local function loadShared()
    local f=io.open(shared.."active.txt","rb")
    if not f then return end
    local version=f:read(32); f:close()
    if not validVersion(version) or not newer(version,engine.version) then return end
    local ok, candidate=pcall(dofile,shared..version..".lua")
    if not ok or type(candidate)~="table" or candidate.api~=1 or candidate.version~=version
        or type(candidate.connect)~="function" then return end
    engine=candidate
    session,lastLevel=nil,nil
    var("UnlockSystemVersion",engine.version)
    display(0)
end

local function run(mode)
    running=true
    var("UnlockOperation",mode)
    display(mode=="Install" and 4 or 1)
    SKIN:Bang("!UpdateMeasure","AvatarUnlockDownload")
    SKIN:Bang("!CommandMeasure","AvatarUnlockDownload","Run")
end
function Install()
    if panelOpen and not running and updateCode==2 then run("Install") end
end
function Check()
    if not running then nextPoll=os.time()+300;run("Check") end
end
function OpenPanel()
    if not panelOpen then
        if not panelPositioned then
            local x=tonumber(option("UnlockPanelX",0)) or 0
            local y=tonumber(option("UnlockPanelY",0)) or 0
            for _,name in ipairs({"UnlockPanelCard","UnlockPanelTitle","UnlockPanelClose","UnlockPanelCurrent",
                                  "UnlockPanelLatest","UnlockPanelState","UnlockInstallButton","UnlockRetryButton"}) do
                local meter=SKIN:GetMeter(name)
                SKIN:Bang("!SetOption",name,"X",x+(tonumber(meter:GetOption("X")) or 0))
                SKIN:Bang("!SetOption",name,"Y",y+(tonumber(meter:GetOption("Y")) or 0))
            end
            panelPositioned=true
        end
        panelOpen=true
        var("UnlockPanelOpen",1)
        local callback=option("UnlockOnOpen","")
        if callback~="" then SKIN:Bang(callback) end
        SKIN:Bang("!ShowMeterGroup","UnlockPanel")
    end
    display(updateCode)
    Check()
end
function ClosePanel()
    if not panelOpen then return end
    panelOpen=false
    var("UnlockPanelOpen",0)
    SKIN:Bang("!HideMeterGroup","UnlockPanel")
    local callback=option("UnlockOnClose","")
    if callback~="" then SKIN:Bang(callback) end
    display(updateCode)
end
function DownloadFinished()
    local output=SKIN:GetMeasure("AvatarUnlockDownload"):GetStringValue()
    running=false
    local status,version=output:match("^%s*(%u+) (%d+%.%d+%.%d+)%s*$")
    loadShared()
    var("UnlockLatestVersion",version or "-")
    if status=="AVAILABLE" and newer(version,engine.version) then display(2)
    elseif status and version==engine.version then display(0)
    else display(3) end
end

function Initialize()
    resources=SELF:GetOption("ResourcePath")
    var("UnlockLatestVersion","-")
    var("UnlockPanelOpen",0)
    shared=os.getenv("LOCALAPPDATA").."\\FormdayAvatar\\Unlocks\\v1\\"
    engine=dofile(resources.."unlock-engine.lua")
    var("UnlockSystemVersion",engine.version)
    local path=option("UnlockCatalog",resources.."unlock-catalog.json")
    local f=assert(io.open(path,"rb"));local source=f:read("*a");f:close()
    catalog=dofile(resources.."json.lua").decode(source).items
    assert(type(catalog)=="table","missing reward list")
    loadShared()
end

local function updateRewards()
    local avatar=option("UnlockAvatar","avatar")
    local profile=option("UnlockProfile","local")
    local enabled=SKIN:GetVariable("UnlockEnabled")~="0"
    if not enabled or not avatar or not profile or profile=="" then
        session,lastLevel=nil,nil
        var("UnlockCompanion","");var("UnlockNewItem","")
        return
    end
    local level=tonumber(option("UnlockLevel",SKIN:GetVariable("Level")))
    if not level or level<1 then return end
    if not session or currentAvatar~=avatar or currentProfile~=profile then
        session=engine.connect(option("UnlockDataPath",SKIN:GetVariable("CURRENTPATH")),avatar,profile,catalog)
        currentAvatar,currentProfile,lastLevel=avatar,profile,nil
        var("UnlockCompanion",session:selected("pokemon") or "")
        var("UnlockNewItem","")
    end
    if level==lastLevel then return end
    local gained=session:sync(level)
    lastLevel=level
    for _,id in ipairs(gained) do
        var("UnlockNewItem",id)
        local callback=SKIN:GetVariable("UnlockOnGrant") or ""
        if callback~="" then SKIN:Bang(callback) end
    end
end

function Choose(kind,id)
    updateRewards()
    if session then
        session:select(kind,id)
        if kind=="pokemon" then var("UnlockCompanion",id or "") end
    end
end
function Update()
    if not nextPoll or nextPoll==0 then
        local meter=option("UnlockAvatarMeter","Avatar")
        if SKIN:GetMeter(meter) then
            SKIN:Bang("!SetOption",meter,"LeftMouseDoubleClickAction","[!CommandMeasure AvatarUnlocks OpenPanel()]")
        end
    end
    loadShared()
    updateRewards()
    if not running and os.time()>=nextPoll then Check() end
    return 0
end
