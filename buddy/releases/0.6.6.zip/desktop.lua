-- Formday desktop skin. Only the selected local data directory is read.
local progress, json, foods, dataDir, baseline, previous, lastDay
local frame, jumpTick, nextWalk, walkLeft, facing = 0, nil, 25, 0, 1
local walkTick, walks, turnIndex, action, actionTick = 0, 0, 0, nil, 0
local actions = {"smile","lift","dance"}
local liveNames = {"Level","Total","NextXP","AllCount","Day","Done","Planned","TodayStrength","TodayCardio","TodayMeals","UnknownMeals","Kcal","Protein","BodyWeight","BodyFat","Measured"}
local dailyNames = {"Done","Planned","TodayStrength","TodayCardio","TodayMeals","UnknownMeals","Kcal","Protein"}
local liveMode = false
local syncDir, preparingFolder, copyAfterPrepare
local hovering, infoOpen, unlockOpen = false, false, false
local jumpDue
local cache = {}
local syncState = -1

local function set(name, value)
    value = tostring(value)
    if cache[name] ~= value then
        cache[name] = value
        SKIN:Bang("!SetVariable", name, value)
    end
end

local function readSmall(path)
    local file = io.open(path, "rb")
    if not file then return nil end
    local size = file:seek("end")
    if not size or size > 8*1024*1024 then file:close(); error("file size") end
    file:seek("set", 0)
    local text = file:read("*a")
    file:close()
    assert(text, "read failed")
    if text:sub(1,3) == string.char(239,187,191) then text = text:sub(4) end
    return text
end

local function firstBaseline(keys)
    local path = dataDir .. "start.json"
    local stored = readSmall(path)
    if stored then
        local saved = json.decode(stored)
        assert(saved.format == 1 and type(saved.checked) == "table", "invalid baseline")
        return saved.checked
    end
    local temp = path .. ".tmp"
    local out = assert(io.open(temp,"wb"))
    local written = out:write(json.encode({format=1, checked=keys}))
    local closed = out:close()
    assert(written and closed, "baseline write failed")
    assert(os.rename(temp,path), "baseline could not be committed")
    return keys
end

local metrics = {
    strength={"sets","reps","weight"}, cardio={"minutes","distance"},
    meal={"grams"}, weight={"weight","bodyfat"}
}
local function metric(value)
    if type(value) ~= "number" or value ~= value or value < 0 or value > 1000000 then return "-" end
    return string.format("%.2f",value):gsub("0+$",""):gsub("%.$","")
end

local function showSync(code)
    if syncState == code then return end
    syncState = code
    set("StateCode", code)
    set("UnlockEnabled",(code == 1 or code == 4 or code == 5 or code == 6) and 1 or 0)
end

local function showBody(today, measured, weight, fat)
    local empty = SKIN:GetVariable("UnmeasuredLabel")
    local hasWeight = measured == today and tonumber(weight) ~= nil
    local hasFat = measured == today and tonumber(fat) ~= nil
    set("BodyWeight", hasWeight and (weight .. " kg") or empty)
    set("BodyFat", hasFat and (fat .. "%") or empty)
    set("Measured", (hasWeight or hasFat) and today or "-")
end

local function loadRecord(today)
    local source = readSmall(syncDir .. "buddy-live.json") or readSmall(dataDir .. "buddy-live.json")
    if source then
        local doc = json.decode(source)
        assert(doc.format == 1, "unsupported summary")
        if doc.state == "account" or doc.state == "local" then
            assert(type(doc.values) == "table" and type(doc.stamp) == "number", "invalid live file")
            for _,name in ipairs(liveNames) do
                local value = doc.values[name]
                assert(type(value) == "number" or type(value) == "string", "invalid metric")
            end
            local v = doc.values
            for _,name in ipairs({"Level","Total","NextXP","AllCount"}) do set(name,v[name]) end
            for _,name in ipairs(dailyNames) do set(name, v.Day == today and v[name] or 0) end
            set("Day",today)
            showBody(today, v.Day == today and v.Measured, v.BodyWeight, v.BodyFat)
            for _,group in ipairs(progress.categories) do
                for _,suffix in ipairs({"Count","XP","Last"}) do
                    set(group..suffix, doc.values[group..suffix] or "-")
                end
            end
            liveMode = true
            local age = os.time() - doc.stamp
            showSync((v.Day ~= today or age > 75 or age < -60) and 6 or (doc.state == "account" and 4 or 5))
            return
        end
        assert(doc.state == "waiting" or doc.state == "disconnected", "invalid connection state")
        -- Never display a previous account's values during a switch or logout.
        for _,name in ipairs(liveNames) do set(name,name == "Level" and 1 or "-") end
        for _,group in ipairs(progress.categories) do
            for _,suffix in ipairs({"Count","XP","Last"}) do set(group..suffix,"-") end
        end
        liveMode, previous = false, nil
        showSync(doc.state == "waiting" and 7 or 8)
        return
    end
    if liveMode then
        previous, liveMode = nil, false
        for _,name in ipairs(liveNames) do set(name,name == "Level" and 1 or "-") end
        for _,group in ipairs(progress.categories) do
            for _,suffix in ipairs({"Count","XP","Last"}) do set(group..suffix,"-") end
        end
    end
    local raw = readSmall(dataDir .. "formday.json")
    if not raw then showSync(previous and 2 or 0); return end
    if raw == previous then showSync(1); return end
    local doc = json.decode(raw)
    if not baseline then
        local checked = progress.calculate(doc,{}).keys
        baseline = firstBaseline(checked)
    end
    local data = progress.calculate(doc,baseline)
    local day = progress.dashboard(doc,today,foods)
    set("Day",today)
    set("Done",day.done)
    set("Planned",day.planned)
    set("TodayStrength",day.strength)
    set("TodayCardio",day.cardio)
    set("TodayMeals",day.meals)
    set("UnknownMeals",day.unknown)
    set("Kcal",day.unknown==0 and math.floor(day.kcal+0.5) or "-")
    set("Protein",day.unknown==0 and metric(math.floor(day.protein*10+0.5)/10) or "-")
    showBody(today,day.measured,metric(day.weight),metric(day.bodyfat))
    for _,key in ipairs(progress.categories) do
        local group = data.groups[key]
        set(key.."Count",group.count)
        set(key.."XP",group.xp)
        set(key.."Last",group.last == "" and "-" or group.last)
        for _,field in ipairs(metrics[key]) do set(key.."_"..field,metric(group.detail[field])) end
    end
    set("Total",data.xp)
    set("Level",1+math.floor(data.xp/progress.perLevel))
    set("NextXP",progress.perLevel - data.xp%progress.perLevel)
    set("AllCount",data.count)
    previous = raw
    showSync(1)
end

local function refreshRecord()
    local today = os.date("!%Y-%m-%d",os.time()+9*3600)
    if lastDay ~= today then
        -- Roll over the display even when the connection tab is asleep or its file is unreadable.
        for _,name in ipairs(dailyNames) do set(name,0) end
        set("Day",today)
        showBody(today,nil,nil,nil)
        previous = nil
        lastDay = today
    end
    if not pcall(loadRecord,today) then showSync(3) end
end

local function prepareSyncFolder()
    if not preparingFolder then
        preparingFolder = true
        SKIN:Bang("!CommandMeasure", "PrepareDataFolder", "Run")
    end
end

local function copyPath()
    SKIN:Bang("!SetClip", SKIN:GetVariable("SyncFolder"))
    SKIN:Bang("!SetOption", "CopySyncFolder", "Text", SKIN:GetVariable("CopiedLabel"))
end

function CopySyncFolder()
    if readSmall(syncDir .. "Readme.txt") then
        copyPath()
    else
        copyAfterPrepare = true
        prepareSyncFolder()
    end
end

function SyncFolderPrepared()
    preparingFolder = false
    if copyAfterPrepare then
        copyAfterPrepare = false
        if SKIN:GetMeasure("PrepareDataFolder"):GetStringValue():match("^%s*READY%s*$") then
            copyPath()
        else
            SKIN:Bang("!SetOption", "CopySyncFolder", "Text", SKIN:GetVariable("RetryLabel"))
        end
    end
end

function Initialize()
    local resources = SKIN:GetVariable("@") .. SKIN:GetVariable("ReleaseSlot") .. "\\"
    json = dofile(resources .. "json.lua")
    progress = dofile(resources .. "progress.lua")
    foods = json.decode(assert(readSmall(resources .. "foods.json")))
    dataDir = SKIN:GetVariable("CURRENTPATH") .. "Data\\"
    syncDir = SKIN:GetVariable("SyncFolder") .. "\\"
    if not readSmall(syncDir .. "Readme.txt") then prepareSyncFolder() end
    -- Rainmeter keeps the old desktop-only Z-order on upgrade. Migrate it just once.
    local marker = dataDir .. "window-v05.txt"
    if not readSmall(marker) then
        SKIN:Bang("!ZPos","1")
        local file = io.open(marker,"wb")
        if file then file:write("1"); file:close() end
    end
    refreshRecord()
    if liveMode and syncState == 6 then
        SKIN:Bang('["https://formday-fitplan-ccucle.onrender.com/#buddy-link"]')
    end
end

function Hover(value)
    hovering = value == 1
    if hovering then walkLeft,action = 0,nil end
    nextWalk = frame + 15
end

function Jump()
    if not jumpTick then jumpTick = 0 end
    walkLeft, action, nextWalk = 0, nil, frame+35
end

function QueueJump()
    if unlockOpen then return end
    local value=tonumber(SKIN:GetMeasure("DoubleClickInterval"):GetStringValue())
    local interval=(value and value>0 and value<=5000) and value or 500
    jumpDue=frame+math.ceil(interval/50)+1
end

function UnlockOpened()
    unlockOpen,infoOpen,jumpDue,jumpTick=true,false,nil,nil
    walkLeft,action=0,nil
    SKIN:Bang("!HideMeterGroup","Info")
    SKIN:Bang("!HideMeterGroup","Compact")
end

function UnlockClosed()
    unlockOpen=false
    if not infoOpen then SKIN:Bang("!ShowMeterGroup","Compact") end
    nextWalk=frame+25
end

function ToggleInfo()
    if unlockOpen then SKIN:Bang("!CommandMeasure","AvatarUnlocks","ClosePanel()") end
    jumpDue=nil
    infoOpen = not infoOpen
    walkLeft, action, nextWalk = 0, nil, frame+25
    SKIN:Bang(infoOpen and "!HideMeterGroup" or "!ShowMeterGroup","Compact")
    SKIN:Bang(infoOpen and "!ShowMeterGroup" or "!HideMeterGroup","Info")
    SKIN:Bang("!Redraw")
end

function OpenInfo()
    if not infoOpen then ToggleInfo() end
end

local function advanceWalk()
    if hovering or infoOpen or unlockOpen or jumpTick or jumpDue or action then return false end
    if walkLeft == 0 and frame >= nextWalk then
        walks = walks+1
        walkLeft, walkTick = 160+(walks*31)%81, 0
    end
    if walkLeft == 0 then return false end
    local x = tonumber(SKIN:GetVariable("CURRENTCONFIGX")) or 0
    local y = tonumber(SKIN:GetVariable("CURRENTCONFIGY")) or 0
    local low = tonumber(SKIN:GetVariable("WORKAREAX")) or 0
    local width = tonumber(SKIN:GetVariable("CURRENTCONFIGWIDTH")) or 288
    local right = math.max(low, low + (tonumber(SKIN:GetVariable("WORKAREAWIDTH")) or 1920) - width)
    if x+facing < low or x+facing > right then facing = -facing end
    SKIN:Bang("!Move", math.floor(math.max(low,math.min(right,x+facing))), math.floor(y))
    walkTick = walkTick+1
    walkLeft = walkLeft - 1
    if walkLeft == 0 then
        nextWalk = frame+40+(walks*17)%41
        if walks%3~=0 then facing=-facing end
        if walks%2==0 then
            turnIndex=turnIndex%#actions+1
            action, actionTick=actions[turnIndex],0
        end
    end
    return true
end

function Update()
    frame = frame+1
    if jumpDue and frame>=jumpDue then jumpDue=nil;Jump() end
    if frame%60 == 0 then refreshRecord() end
    local walking = advanceWalk()
    local pose = walking and ("motion\\walk"..(math.floor((walkTick-1)/3)%8+1)) or "idle"
    local lift, flip = 0, facing
    if action and not walking then
        local stage = math.floor(actionTick/3)%8
        if action == "dance" then
            pose = "motion\\dance"
            flip = math.floor(actionTick/8)%2==0 and facing or -facing
            lift = ({0,1,3,2,0,1,3,2})[stage+1]
        else
            local sequences = {smile={"","1","2","1","","1","2","1"},lift={"","1","2","2","2","1","",""}}
            pose = "motion\\"..action..sequences[action][stage+1]
        end
        actionTick=actionTick+1
        if actionTick>=40 then action=nil end
    end
    if jumpTick then
        lift = math.floor(19*math.sin(math.pi*jumpTick/12)+0.5)
        pose = "jump"
        jumpTick = jumpTick+1
        if jumpTick > 12 then jumpTick = nil end
    end
    set("Pose",pose)
    set("Facing",flip == 1 and "None" or "Horizontal")
    set("PetY",48-lift)
    set("BadgeY",pose == "jump" and 20-lift or 20)
    return frame
end
