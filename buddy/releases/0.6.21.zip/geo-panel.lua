-- Geo-only presentation. Values come from an accepted server snapshot; no rewards are inferred.
local M={}
local function set(k,v) SKIN:Bang("!SetVariable",k,tostring(v)) end
local function n(v) return type(v)=="number" and v>=0 and v==math.floor(v) end
local function kst(t,fmt) return os.date("!"..fmt,t+9*3600) end
function M.values(d,accepted,now)
 now=now or os.time()
 local out={title="지오",level="—",xp="— / 30 XP",remaining="다음 레벨 —회",today="오늘 적립 —",powder="가루 —",last="아직 적립 없음",sync="연결 확인 중",at="마지막 성공 —",ratio=0,color="226,185,104"}
 if not d or not accepted then out.sync="연결 끊김";out.color="178,187,201";return out end
 local b=d.balance;out.level="Lv. "..b.level;out.xp=b.xp_into_level.." / 30 XP";out.remaining="다음 레벨 체크 "..math.ceil((30-b.xp_into_level)/2).."회";out.powder="가루 "..b.powder;out.ratio=b.xp_into_level/30
 local a=d.reward_activity
 if type(a)=="table" then
  if a.day_kst==kst(now,"%Y-%m-%d") and n(a.awarded_today) then out.today="오늘 적립 "..a.awarded_today.."회" end
  if type(a.last_award)=="table" and n(a.last_award.at) and a.last_award.xp==2 and a.last_award.powder==10 then out.last="최근 +2 XP · +10 가루";out.lastAt=kst(a.last_award.at,"%m/%d %H:%M")
  elseif a.last_award==nil and b.earned_count>0 then out.last="최근 보상 —" end
 elseif b.earned_count>0 then out.last="최근 보상 —" end
 local success=d.client_received_at or d.fetched_at
 if n(success) then out.at="성공 "..kst(success,"%H:%M:%S").." KST" end
 local age=now-success
 if d.connection=="disconnected" or age>120 or age< -60 then out.sync="연결 끊김";out.color="178,187,201"
 elseif age>45 or age< -5 then out.sync="연결 확인 중 · 지연";out.color="226,185,104"
 else out.sync="연결됨";out.color="124,218,177" end
 return out
end
function M.paint(d,accepted)
 local v=M.values(d,accepted)
 for k,value in pairs(v) do set("GeoUI_"..k,value) end
 set("GeoUI_bar",math.floor(v.ratio*146));set("GeoUI_lastAt",v.lastAt or "")
end
return M
