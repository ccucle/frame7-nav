-- Local cache of authenticated Geo state. Contains no credential or Notion content.
local G={}
local function integer(v) return type(v)=="number" and v>=0 and v<=100000000 and v==math.floor(v) end
local function key(v) return type(v)=="string" and #v<=80 and v:match("^[a-zA-Z0-9_-]+$") end
function G.validate(d)
    if type(d)~="table" or d.format~=2 or d.avatar~="formday-geo" or not key(d.owner)
        or (d.connection~="connected" and d.connection~="disconnected") or not integer(d.revision) or type(d.fetched_at)~="number" then return nil end
    local b=d.balance
    if type(b)~="table" then return nil end
    for _,k in ipairs({"base_xp","earned_count","total_xp","powder","level","xp_into_level"}) do if not integer(b[k]) then return nil end end
    if b.total_xp~=b.base_xp+b.earned_count*2 or b.level~=1+math.floor(b.total_xp/30)
        or b.xp_into_level~=b.total_xp%30 then return nil end
    if type(b.stones)~="table" or type(b.forms)~="table" then return nil end
    for k,v in pairs(b.stones) do if not key(k) or not integer(v) then return nil end end
    for k,v in pairs(b.forms) do if not key(k) or v~=true then return nil end end
    return d
end
function G.read(folder,json)
    local f=io.open(folder.."geo-live.json","rb")
    if not f then return nil end
    local raw=f:read(65537);f:close()
    if not raw or #raw>65536 then return nil end
    local ok,d=pcall(json.decode,raw)
    return ok and G.validate(d) or nil
end
function G.fresh(d) return d and d.connection=="connected" and math.abs(os.time()-d.fetched_at)<120 end
function G.pin(data,d)
    if not d then return false end
    local p=data.."geo-owner-v1.txt"
    local f=io.open(p,"rb")
    local owner,revision
    if f then
        for line in f:lines() do
            local o,r=line:match("^([a-zA-Z0-9_-]+)|(%d+)$")
            if o then owner,revision=o,tonumber(r) end
        end
        f:close()
        if not owner or owner~=d.owner or d.revision<revision then return false end
        if d.revision==revision then return true end
    end
    f=io.open(p,"ab");if not f then return false end
    local written=f:write(d.owner.."|"..string.format("%.0f",d.revision).."\n");local closed=f:close()
    return written~=nil and closed
end
return G
