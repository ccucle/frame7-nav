-- Host adapter. The independently updated catalog engine and its feed stay intact.
local env,engine,resources,pendingEngine
local forward
local hostEnvironment=getfenv(1)
local function loadEngine(path)
    local host=SKIN
    env=setmetatable({SELF=SELF}, {__index=getfenv(1)})
    env.SKIN=setmetatable({}, {__index=function(_,k)
        if k=="Bang" then return function(_,command,...)
            local a={...}
            -- Preserve the host adapter when the catalog selects a newer shared engine.
            if command=="!SetOption" and a[1]==SELF:GetName() and a[2]=="ScriptFile" then pendingEngine=a[3];return end
            return host:Bang(command,...)
        end end
        return function(_,...) return host[k](host,...) end
    end})
    -- Match Rainmeter's load lifecycle: SKIN/SELF are injected after the chunk loads.
    -- The catalog intentionally returns its module early when both are already present.
    local proxy=env.SKIN
    env.SKIN=false;env.SELF=false
    local chunk=assert(loadfile(path));setfenv(chunk,env);engine=chunk()
    env.SKIN=proxy;env.SELF=SELF
    assert(rawget(env,"Initialize"),"catalog runtime missing")
    for name,fn in pairs(env) do
        if type(fn)=="function" and name~="Initialize" then
            local n=name
            hostEnvironment[n]=function(...) return forward(n,...) end
        end
    end
    local connect=engine.connect
    local json=dofile(resources.."json.lua")
    local geo=dofile(resources.."geo-state.lua")
    engine.connect=function(data,avatar,profile,catalog)
        -- Geo reward levels are not defined yet: never inherit Buddy's local grants.
        local session=connect(data,avatar,profile,avatar=="formday-geo" and {} or catalog)
        if avatar~="formday-geo" then return session end
        local legacy=session.wallet
        function session:readWallet()
            local d=geo.read(host:GetVariable("SyncFolder").."\\",json)
            if d and geo.pin(data,d) then
                session.wallet={xp=d.balance.total_xp,powder=d.balance.powder,stones=d.balance.stones,
                    forms=d.balance.forms,sequence=d.revision}
                return true
            end
            -- Display the prior local record without mutating or spending it before migration.
            session.wallet=legacy
            return false
        end
        function session:earn() return false end
        local function request(kind,value)
            if host:GetVariable("GeoConnected")~="1" then return false end
            if not value:match("^[a-z0-9_-]+$") then return false end
            local folder=host:GetVariable("SyncFolder").."\\"
            local d=geo.read(folder,json)
            if not d or not geo.fresh(d) then return false end
            local target=folder.."geo-request.json"
            local exists=io.open(target,"rb")
            if exists then exists:close();return false end
            local id=tostring(os.time()).."-"..tostring({}):gsub("[^a-zA-Z0-9]","")
            local pending=target.."."..id..".tmp"
            local f=io.open(pending,"wb");if not f then return false end
            local written=f:write(json.encode({format=1,request_id=id,owner=d.owner,kind=kind,target=value}))
            local closed=f:close()
            if not written or not closed or not os.rename(pending,target) then os.remove(pending) end
            return false -- Commit only after an authenticated server snapshot arrives.
        end
        function session:craft(stone) return request("craft",stone) end
        function session:evolve(target) return request("evolve",target) end
        session:readWallet()
        return session
    end
end
function Initialize()
    resources=SELF:GetOption("ResourcePath")
    loadEngine(resources.."unlock-engine.lua")
    env.Initialize()
end
forward=function(name,...)
    if pendingEngine then local p=pendingEngine;pendingEngine=nil;loadEngine(p);env.Initialize() end
    if env and env[name] then return env[name](...) end
end
