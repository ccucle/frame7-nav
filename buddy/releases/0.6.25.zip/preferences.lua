-- Preferences belong to the skin's Data folder, shared by both update slots.
local M = {}
local fields = {Walk=true, Badge=true, Startup=true}
local prefs = {Walk="1", Badge="1", Startup="1"}
local path, busy, ready, status

local function display()
    SKIN:Bang("!SetVariable","PrefWalk",prefs.Walk)
    SKIN:Bang("!SetVariable","PrefBadge",prefs.Badge)
    SKIN:Bang("!SetVariable","PrefStartup",status or "WAIT")
    SKIN:Bang(prefs.Badge=="1" and "!ShowMeter" or "!HideMeter","Level")
    SKIN:Bang("!UpdateMeasureGroup","PreferenceLabels")
    SKIN:Bang("!UpdateMeterGroup","Settings")
    SKIN:Bang("!Redraw")
end

local function save(key,value)
    if not ready then return false end
    -- Rainmeter updates one key in place. Read it back before changing UI state.
    SKIN:Bang("!WriteKeyValue","Preferences",key,value,path)
    local f=io.open(path,"rb")
    if not f then return false end
    local saved=f:read("*a")
    f:close()
    if not saved:match("[\r\n]"..key.."="..value.."[\r\n]") then return false end
    prefs[key]=value
    return true
end

local function restoreAtLaunch(enabled)
    -- Rainmeter can start independently for the user's other skins. Keep only
    -- this config's restore flag in sync; the loaded skin stays visible now.
    local config=SKIN:GetVariable("CURRENTCONFIG")
    local active=enabled and (SKIN:GetVariable("ReleaseSlot")=="B" and 2 or 1) or 0
    local settings=SKIN:GetVariable("SETTINGSPATH").."Rainmeter.ini"
    SKIN:Bang("!WriteKeyValue",config,"Active",tostring(active),settings)
end

local function startup(value)
    if busy then return end
    busy=value
    status="WAIT"
    display()
    SKIN:Bang("!SetVariable","StartupMode",value=="1" and "Enable" or "Disable")
    SKIN:Bang("!UpdateMeasure","BuddyStartup")
    SKIN:Bang("!CommandMeasure","BuddyStartup","Run")
end

function M.init(data)
    path=data.."preferences.ini"
    local f=io.open(path,"rb")
    if not f then
        f=io.open(path,"wb")
        if f then
            local written=f:write("[Preferences]\r\nWalk=1\r\nBadge=1\r\nStartup=1\r\n")
            ready=f:close() and written~=nil
        end
    else
        local source=f:read("*a");f:close()
        for key,value in source:gmatch("(%a+)=([01])") do
            if fields[key] then prefs[key]=value end
        end
        ready=true
    end
    if not ready then SKIN:Bang("!SetVariable","PreferenceError","1") end
    status=ready and "WAIT" or "ERROR"
    display()
end

function M.sync()
    if ready and not busy and SKIN:GetMeasure("BuddyStartup") then startup(prefs.Startup) end
end

function M.finished()
    if not busy then return end
    local wanted=busy
    busy=nil
    local result=SKIN:GetMeasure("BuddyStartup"):GetStringValue():match("^%s*(%u+)%s*$")
    if (wanted=="1" and (result=="ON" or result=="BLOCKED")) or (wanted=="0" and result=="OFF") then
        if prefs.Startup==wanted or save("Startup",wanted) then
            restoreAtLaunch(wanted=="1")
            status=result
        else status="ERROR" end
    else status="ERROR" end
    display()
end

function M.toggle(key)
    if not ready or not fields[key] then return end
    local value=prefs[key]=="1" and "0" or "1"
    if key=="Startup" then
        if status=="ERROR" then value=prefs.Startup end
        startup(value)
    elseif save(key,value) then SKIN:Bang("!SetVariable","PreferenceError","0");display()
    else SKIN:Bang("!SetVariable","PreferenceError","1");display() end
end

function M.walks() return prefs.Walk=="1" end
return M
