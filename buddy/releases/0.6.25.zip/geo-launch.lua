-- One automatic launch per Windows logon, persisted across refresh / update / A-B / restart.
-- No browser profile, cookies or tab inventory is inspected or changed.
local M={}
local url="https://geo-xp-read-probe.ccucle.workers.dev/connect"
local function exists(p) local f=io.open(p,"rb");if f then f:close();return true end;return false end
function M.chrome(skin)
 for _,name in ipairs({"GeoChromeUser","GeoChromeMachine"}) do
  local measure=skin:GetMeasure(name);local p=measure and measure:GetStringValue()
  if p and not p:find('["\r\n]') and p:lower():match("chrome%.exe$") and exists(p) then return p end
 end
 for _,name in ipairs({"PROGRAMFILES","PROGRAMFILES(X86)","LOCALAPPDATA"}) do
  local root=os.getenv(name);local p=root and root.."\\Google\\Chrome\\Application\\chrome.exe"
  if p and exists(p) then return p end
 end
 return nil
end
function M.open(skin,data,snapshot,isAutomatic)
 local chrome=M.chrome(skin)
 if not chrome then skin:Bang("!SetVariable","GeoLaunchHint","Chrome 설치 확인 · 연결 탭 필요");return "CHROME_MISSING" end
 if isAutomatic then
  local measure,stamp=skin:GetMeasure("GeoLogonTime"),nil
  stamp=measure and tonumber(measure:GetValue())
  if not stamp or stamp<=0 then skin:Bang("!SetVariable","GeoLaunchHint","연결 탭을 직접 열어 주세요");return "SESSION_UNKNOWN" end
  local session=(os.getenv("COMPUTERNAME") or "PC"):gsub("[^%w_-]","").."|"..string.format("%.0f",stamp)
  local path,f=data.."geo-launch-v1.txt",io.open(data.."geo-launch-v1.txt","rb")
  if f then local prior=f:read(256);f:close();if prior==session then return "ALREADY_REQUESTED" end end
  f=io.open(path,"wb");if not f then return "MARKER_UNAVAILABLE" end
  local ok=f:write(session);local closed=f:close();if not ok or not closed then return "MARKER_UNAVAILABLE" end
  local age=snapshot and os.time()-(snapshot.client_received_at or snapshot.fetched_at)
  local success=snapshot and (snapshot.client_received_at or snapshot.fetched_at)
  if snapshot and snapshot.connection=="connected" and age and age>=-5 and age<=45 and success>=stamp-11644473600 then return "RECENT_HEARTBEAT" end
 end
 -- Chrome chooses the existing active/last-used profile; no profile flags or debug port.
 skin:Bang('["'..chrome..'" "'..url..'"]')
 skin:Bang("!SetVariable","GeoLaunchHint","연결 탭에서 이 PC 상태를 확인하세요")
 return "OPEN_REQUESTED"
end
return M
