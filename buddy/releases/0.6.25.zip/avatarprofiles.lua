-- Local game state only; Formday source data and the shared unlock module stay unchanged.
local A={}
local allowed={["formday-buddy"]=true,["formday-geo"]=true}
local default="formday-buddy"
local levelThresholds={["formday-geo"]=30}
local path, state
local function blank() return {id=default,buddy=0,geo=0,live=-1,localraw=-1} end
local function read()
    local file=io.open(path,"rb")
    if not file then return blank() end
    local last
    for line in file:lines() do
        local id,buddy,geo,live,localraw=line:match("^1|([a-z%-]+)|(%d+)|(%d+)|(%-?%d+)|(%-?%d+)%s*$")
        if allowed[id] then last={id=id,buddy=tonumber(buddy),geo=tonumber(geo),live=tonumber(live),localraw=tonumber(localraw)} end
    end
    file:close()
    return last or blank()
end
local function copy()
    return {id=state.id,buddy=state.buddy,geo=state.geo,live=state.live,localraw=state.localraw}
end
local function persist(next)
    local file=io.open(path,"ab")
    if not file then return false end
    local line=string.format("\n1|%s|%d|%d|%d|%d\n",next.id,next.buddy,next.geo,next.live,next.localraw)
    local written=file:write(line)
    local closed=file:close()
    if not written or not closed then return false end
    local checked=read()
    for k,v in pairs(next) do if checked[k]~=v then return false end end
    state=checked
    return true
end
function A.init(dataDir)
    path=dataDir.."avatar-progress-v1.txt"
    state=read()
end
function A.id() return state.id end
function A.threshold(fallback) return levelThresholds[state.id] or fallback end
function A.xp() return state.id==default and state.buddy or state.geo end
function A.select(id)
    if not allowed[id] then return false end
    if state.id==id then return true end
    local next=copy();next.id=id
    return persist(next)
end
function A.observe(source,value)
    if source~="live" and source~="localraw" then return false end
    if type(value)~="number" or value<0 or value>100000000 or value~=math.floor(value) then return false end
    if value==state[source] then return true end
    local next=copy()
    if state[source]==-1 then
        -- On the first documented source, keep all pre-upgrade XP on the existing character.
        -- On a later source change, seed only the watermark; do not double-count history.
        if state.live==-1 and state.localraw==-1 then next.buddy=math.max(next.buddy,value) end
    else
        -- Formday calendar progress belongs to Buddy even while Geo is selected.
        next.buddy=math.max(0,next.buddy+value-state[source])
    end
    next[source]=value
    return persist(next)
end
-- Geo is set from a validated server snapshot, never credited from the selected avatar.
-- The server imports the pre-link Geo balance once; reject any lossy migration.
function A.server(snapshot)
    if type(snapshot)~="table" or snapshot.total_xp<state.geo then return false end
    if snapshot.total_xp==state.geo then return true end
    local next=copy();next.geo=snapshot.total_xp
    return persist(next)
end
return A
