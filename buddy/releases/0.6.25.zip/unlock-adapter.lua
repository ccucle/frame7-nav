-- Compatibility entry point for skins that still reference unlock-adapter.lua.
function Initialize()
    SKIN:Bang("!SetOption",SELF:GetName(),"ScriptFile",SELF:GetOption("ResourcePath").."unlock-engine.lua")
end
function Update() return 0 end
