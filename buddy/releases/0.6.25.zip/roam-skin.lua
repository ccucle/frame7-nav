[Rainmeter]
Update=100
DynamicWindowSize=1
OnRefreshAction=[!ZPos -2][!ClickThrough 1][!KeepOnScreen 1][!SnapEdges 0]
[Motion]
Measure=Script
ScriptFile=#CURRENTPATH#..\roam.lua
[Sprite]
Meter=Image
DynamicVariables=1
