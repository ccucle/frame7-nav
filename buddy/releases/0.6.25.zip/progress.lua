-- Pure calculation for the Formday calendar v1 backup.
local P = {}
P.categories = {"strength", "cardio", "meal", "weight"}
P.points = {strength = 10, cardio = 8, meal = 3, weight = 2}
P.perLevel = 25

local function dayNumber(s)
    if type(s) ~= "string" then return nil end
    local y, m, d = s:match("^(%d%d%d%d)%-(%d%d)%-(%d%d)$")
    y, m, d = tonumber(y), tonumber(m), tonumber(d)
    if not y or y < 1 or m < 1 or m > 12 then return nil end
    local leap = y % 4 == 0 and (y % 100 ~= 0 or y % 400 == 0)
    local lengths = {31,leap and 29 or 28,31,30,31,30,31,31,30,31,30,31}
    if d < 1 or d > lengths[m] then return nil end
    local n = y - 1
    local days = 365*n + math.floor(n/4) - math.floor(n/100) + math.floor(n/400) + d
    for i = 1, m-1 do days = days + lengths[i] end
    return days
end

function P.calculate(doc, baseline)
    assert(type(doc) == "table" and doc.app == "formday" and doc.version == 1 and type(doc.events) == "table", "unsupported backup")
    for index in pairs(doc.events) do
        assert(type(index) == "number" and index >= 1 and index <= #doc.events and index % 1 == 0, "invalid events list")
    end
    local result = {xp=0, count=0, groups={}, keys={}}
    for _,k in ipairs(P.categories) do result.groups[k] = {count=0, xp=0, last="", detail={}} end
    for _,e in ipairs(doc.events) do
        assert(type(e) == "table", "invalid event")
        local group = result.groups[e.type]
        if group and e.isSample ~= true then
            local start = dayNumber(e.date)
            local repeatType = e["repeat"]
            assert(start and type(e.id) == "string" and #e.id > 0, "invalid event identity")
            assert(repeatType == "none" or repeatType == "weekly" or repeatType == "daily", "invalid recurrence")
            local dates
            if repeatType == "none" then
                dates = e.completed == true and {e.date} or {}
            else
                dates = e.doneDates or {}
                assert(type(dates) == "table", "invalid completion dates")
            end
            for _,day in ipairs(dates) do
                local n = dayNumber(day)
                if n and n >= start and (repeatType ~= "weekly" or (n-start)%7 == 0) then
                    local key = day .. ":" .. e.id
                    if not result.keys[key] then
                        result.keys[key] = true
                        group.count = group.count + 1
                        result.count = result.count + 1
                        if not baseline[key] then
                            group.xp = group.xp + P.points[e.type]
                            result.xp = result.xp + P.points[e.type]
                        end
                        local finish = type(e["end"]) == "string" and e["end"]:match("^%d%d:%d%d$") or ""
                        local stamp = day .. " " .. finish .. ":" .. e.id
                        if stamp > (group.stamp or "") then
                            group.stamp, group.last = stamp, day
                            group.detail = type(e.detail) == "table" and e.detail or {}
                        end
                    end
                end
            end
        end
    end
    return result
end

function P.dashboard(doc, today, foods)
    local t = assert(dayNumber(today))
    local d = {planned=0, done=0, strength=0, cardio=0, kcal=0, protein=0, meals=0, unknown=0, measured="-"}
    local seen = {}
    for _,e in ipairs(doc.events) do
        if e.isSample ~= true and P.points[e.type] then
            local start = dayNumber(e.date)
            local detail = type(e.detail) == "table" and e.detail or {}
            if start and start <= t then
                if e.type == "weight" and type(detail.weight) == "number" and detail.weight > 0 and e.date >= d.measured then
                    d.weight, d.bodyfat, d.measured = detail.weight, detail.bodyfat, e.date
                end
                local repeatType = e["repeat"]
                local occurs = start == t or repeatType == "daily" or (repeatType == "weekly" and (t-start)%7 == 0)
                if occurs and not seen[e.id] then
                    seen[e.id] = true
                    local done = repeatType == "none" and e.completed == true
                    if repeatType ~= "none" then
                        for _,date in ipairs(e.doneDates or {}) do if date == today then done = true; break end end
                    end
                    if e.type == "strength" or e.type == "cardio" then
                        d.planned = d.planned+1
                        if done then d.done=d.done+1; d[e.type]=d[e.type]+1 end
                    elseif e.type == "meal" and done then
                        d.meals = d.meals+1
                        local f = foods[detail.food]
                        if f and type(detail.grams)=="number" and detail.grams>0 then
                            d.kcal = d.kcal + f[1]*detail.grams/100
                            d.protein = d.protein + f[2]*detail.grams/100
                        else d.unknown=d.unknown+1 end
                    end
                end
            end
        end
    end
    return d
end
return P
