-- Host adapter. The independently updated catalog engine and its feed stay intact.
local env,engine,resources,pendingEngine
local forward
local hostEnvironment=getfenv(1)
local function loadEngine(path)
    local host=SKIN
    env=setmetatable({SELF=SELF}, {__index=getfenv(1)})
    env.SKIN=setmetatable({}, {__index=function(_,k)
        if k=="Bang" then return function(_,command,...)
            local a={...}
            -- Preserve the host adapter when the catalog selects a newer shared engine.
            if command=="!SetOption" and a[1]==SELF:GetName() and a[2]=="ScriptFile" then pendingEngine=a[3];return end
            return host:Bang(command,...)
        end end
        return function(_,...) return host[k](host,...) end
    end})
    -- Match Rainmeter's load lifecycle: SKIN/SELF are injected after the chunk loads.
    -- The catalog intentionally returns its module early when both are already present.
    local proxy=env.SKIN
    env.SKIN=false;env.SELF=false
    local chunk=assert(loadfile(path));setfenv(chunk,env);engine=chunk()
    env.SKIN=proxy;env.SELF=SELF
    assert(rawget(env,"Initialize"),"catalog runtime missing")
    for name,fn in pairs(env) do
        if type(fn)=="function" and name~="Initialize" then
            local n=name
            hostEnvironment[n]=function(...) return forward(n,...) end
        end
    end
    local baseCatalogFor=engine.catalogFor
    engine.catalogFor=function(avatar,items)
        if avatar~="formday-geo" then return baseCatalogFor(avatar,items) end
        local out,seen={},{}
        for _,item in ipairs(baseCatalogFor(avatar,{})) do out[#out+1]=item;seen[item.id]=true end
        for _,item in ipairs(baseCatalogFor("formday-buddy",items)) do
            if item.kind=="pokemon" and not seen[item.id] then out[#out+1]=item;seen[item.id]=true end
        end
        return out
    end
    local connect=engine.connect
    local json=dofile(resources.."json.lua")
    local geo=dofile(resources.."geo-state.lua")
    engine.connect=function(data,avatar,profile,catalog)
        -- Shared Pokémon rules, separate per-avatar receipts; never copy Buddy ownership.
        local session=connect(data,avatar,profile,catalog)
        if avatar~="formday-geo" then return session end
        local legacy=session.wallet
        function session:readWallet()
            local d=geo.read(host:GetVariable("SyncFolder").."\\",json)
            if d and geo.pin(data,d) then
                session.wallet={xp=d.balance.total_xp,powder=d.balance.powder,stones=d.balance.stones,
                    forms=d.balance.forms,sequence=d.revision}
                return true
            end
            -- Display the prior local record without mutating or spending it before migration.
            session.wallet=legacy
            return false
        end
        function session:earn() return false end
        local function request(kind,value)
            if host:GetVariable("GeoConnected")~="1" then return false end
            if not value:match("^[a-z0-9_-]+$") then return false end
            local folder=host:GetVariable("SyncFolder").."\\"
            local d=geo.read(folder,json)
            if not d or not geo.fresh(d) then return false end
            local target=folder.."geo-request.json"
            local exists=io.open(target,"rb")
            if exists then exists:close();return false end
            local id=tostring(os.time()).."-"..tostring({}):gsub("[^a-zA-Z0-9]","")
            local pending=target.."."..id..".tmp"
            local f=io.open(pending,"wb");if not f then return false end
            local written=f:write(json.encode({format=1,request_id=id,owner=d.owner,kind=kind,target=value}))
            local closed=f:close()
            if not written or not closed or not os.rename(pending,target) then os.remove(pending) end
            return false -- Commit only after an authenticated server snapshot arrives.
        end
        function session:craft(stone) return request("craft",stone) end
        function session:evolve(target) return request("evolve",target) end
        session:readWallet()
        return session
    end
    local baseGallery=engine.createGallery
    engine.createGallery=function()
        local g=baseGallery()
        local bind=g.bind
        g.bind=function(module,items,profile)
            if profile==nil then
                local avatar=host:GetVariable("UnlockAvatar")
                local owner=host:GetVariable("UnlockProfile")
                local path=host:GetVariable("UnlockDataPath") or host:GetVariable("CURRENTPATH")
                if (avatar=="formday-buddy" or avatar=="formday-geo") and owner and owner~="" and path then
                    local existing=engine.connect(path,avatar,owner,items)
                    profile={wallet=existing.wallet,owns=function(_,id)return existing:owns(id) end,
                        selected=function(_,kind)return existing:selected(kind) end,evolve=function()return false end}
                end
            end
            return bind(module,items,profile)
        end
        return g
    end
end
function Initialize()
    resources=SELF:GetOption("ResourcePath")
    loadEngine(resources.."unlock-engine.lua")
    env.Initialize()
end
forward=function(name,...)
    if pendingEngine then local p=pendingEngine;pendingEngine=nil;loadEngine(p);env.Initialize() end
    if env and env[name] then return env[name](...) end
end
